<html>
<head><link href="styles.css" rel="stylesheet" type="text/css">
<script type="text/javascript" src="Viewpub2.js"></script>
</head>
<body>
<form action="javascript:strt()" method="GET">
 <table width="100%" div align="center" border="0" cellspacing="0" cellpadding="5" class="main">  
<tr><td colspan="3">&nbsp;</td>  
</tr>  
<tr>
<td width="160" valign="top"><p>&nbsp;</p>
 <p>&nbsp; </p>
 <p>&nbsp;</p>      
<p>&nbsp;</p>      
<p>&nbsp;</p></td>    
<td width="732" valign="top"><p>   
</p>
<h3 class="titlehdr">VIEW PUBLICATION DETAILS FOR FACULTY</h3>
<p>Please Enter The faculty training Details Please note that fields marked <span class="required">*</span> are required.</p>                
<table width="95%" border="0" cellspacing="3" cellpadding="3" class="forms"><p> </p>
	
	<tr>
	<td>FACULTY NAME:<input type ="text" name="PUB_view2_fac_name" id="PUB_view2_fac_name" />
                   </td>        	
                    </tr>
                   <tr>
<p><tr><td align="center">
<p><tr><td align="center">	
<p><tr><td align="center">
<td colspan="2" align="center"><input type="submit" name="Submit" onclick=""  value="Submit"  align="center" /></td>
                   <p><tr><td>

	</tr>
	</table>	
	</form>
	
<div id="get_response"></div>	
</body>	
</html>