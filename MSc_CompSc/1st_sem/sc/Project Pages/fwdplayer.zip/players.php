<html>
<title>Players Page </title>
<head>
	<div style="border: 4px solid black" align= "center"><font size="10pt"> PLAYERS </font></div>
	<script type="text/javascript">
	
		var xmlhttp;
		var CONF;
		var p_id,p_name,team_id,age,dob;
		
		function insert_player()
		{
			
			xmlhttp=GetXmlHttpObject();
				if (xmlhttp==null)
				{
					alert ("Browser does not support HTTP Request");
					return;
				}
			connect_server();
		}
		
		function connect_server()
		{
			document.getElementById('insert_response').innerHTML = "Wait...";
			
			p_id=document.getElementById('p_id1').value;
			p_name=document.getElementById('p_name1').value;
			team_id=document.getElementById('team_id1').value;
			age=document.getElementById('age1').value;
			dob=document.getElementById('dob1').value;
			
			var url="insert_into_player.php";
				url=url+"?p_id="+p_id+"&p_name="+p_name+"&team_id="+team_id+"&age="+age+"&dob="+dob;
				url=url+"&sid="+Math.random();
				xmlhttp.open("GET",url,true);
				xmlhttp.onreadystatechange=stateChanged;
				xmlhttp.send(null);
		}
		
		function stateChanged()
		{
			if (xmlhttp.readyState==4)
			{
				document.getElementById("insert_response").innerHTML=xmlhttp.responseText;				
			}
		}

		function GetXmlHttpObject()
		{
			if (window.XMLHttpRequest)
			{
				// code for IE7+, Firefox, Chrome, Opera, Safari
				return new XMLHttpRequest();
			}
			if (window.ActiveXObject)
			{
				// code for IE6, IE5
				return new ActiveXObject("Microsoft.XMLHTTP");
			}
		return null;
		}
		
		function get_player()
			{
			 xmlhttp=GetXmlHttpObject();
				if (xmlhttp==null)
				{
					alert ("Browser does not support HTTP Request");
					return;
				}
			connect_server_get_player();
		}
		
		function connect_server_get_player()
		{
			p_id=document.getElementById('get_pid').value;
			var url="show_palyer.php";
			url=url+"?p_id="+p_id;
			url=url+"&sid="+Math.random();
			xmlhttp.open("GET",url,true);
			xmlhttp.onreadystatechange=stateChangedGetPlayer;
			xmlhttp.send(null);			
		} 
		
		function stateChangedGetPlayer()
		{
			if (xmlhttp.readyState==4)
			{
				document.getElementById("get_response").innerHTML=xmlhttp.responseText;
				//document.myForm.time.value = xmlhttp.responseText;	
			}
		}
		
	</script>	
</head>
<body bgcolor="aliceblue">
	<h2><u><center>Fill Players Details</center></u></h2>
	
	<!-- Form: the action="javascript:insert_player()"calls the javascript function "insert_player" into ajax_framework -->
	<form action="javascript:insert_player()" method="GET">
		<table align="center" border="1">
		<tr>
			<td>P_ID</td>
			<td><input name="p_id" type="text" id="p_id1" size="5" /></td>
		</tr>
		<tr>
			<td>P_NAME</td>
			<td><input name="p_name" type="text" id="p_name1" size="30" /></td>
		</tr>
		<tr>
			<td>TEAM_ID</td>
			<td><select name="team_id" type="text" id="team_id1">
				<option>t1</option>
				<option>t2</option>
				<option>t3</option>
				<option>t4</option>
			</select></td>
		</tr>	
		<tr>
			<td>AGE</td>
			<td><input name="age" type="text" id="age1" size="2" /></td>
		</tr>
		<tr>
			<td>DOB</td>
			<td><input name="dob" type="text" id="dob1" /></td>
		</tr>
		<tr>
		<td colspan="2" align="center"><input type="submit" name="Submit" value="INSERT" /></td>
		</tr>
	</table>	
	</form>
	<!-- Show Message for AJAX response -->
	<div id="insert_response"></div>
	<br /><br />
	<h2><u><center>Show player details</center></u></h2>
	
	<form>
	<table align="center" border="1">
	<tr>
	<td>Enter P_ID : <input type ="text" name="get_pid" id="get_pid" /></td>
	<td><input type="button" onclick="get_player()" value="Submit" /></td>
	</tr>
	</table>	
	</form>
	<div id="get_response"></div>
	
</body>	
</html>
	