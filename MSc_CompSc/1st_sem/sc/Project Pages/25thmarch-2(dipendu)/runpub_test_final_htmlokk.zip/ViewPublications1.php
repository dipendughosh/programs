<html>
<head><link href="styles.css" rel="stylesheet" type="text/css">
<script type="text/javascript" src="Viewpub1.js"></script>
</head>
<body>
<form action="javascript:strt()" method="GET">
 <table width="100%" div align="center" border="0" cellspacing="0" cellpadding="5" class="main">  
<tr><td colspan="3">&nbsp;</td>  
</tr>  
<tr>
<td width="160" valign="top"><p>&nbsp;</p>
 <p>&nbsp; </p>
 <p>&nbsp;</p>      
<p>&nbsp;</p>      
<p>&nbsp;</p></td>    
<td width="732" valign="top"><p>   
</p>
<h3 class="titlehdr">VIEW DETAILS OF PUBLICATIONS </h3>
<p>Please Enter The faculty training Details Please note that fields marked <span class="required">*</span> are required.</p>                
<table width="95%" border="0" cellspacing="3" cellpadding="3" class="forms"><p> </p>
	
	<tr>
	<td>FROM DATE: <input type ="text" name="PUB_view1_from_date" id="PUB_view1_from_date" />
                   </td>        	
                   <td>TO DATE: <input type ="text" name="PUB_view1_to_date" id="PUB_view1_to_date" />
                   </td>
                    </tr>
                   <tr>
<p><tr><td align="center">
<p><tr><td align="center">	
<p><tr><td align="center">
<td colspan="2" align="center"><input type="submit" name="Submit" onclick=""  value="New Publication Per Faculty "  align="center" /></td>
                   <p><tr><td>

	</tr>
	</table>	
	</form>
	<div id="insert_response"</div>
	
</body>	
</html>