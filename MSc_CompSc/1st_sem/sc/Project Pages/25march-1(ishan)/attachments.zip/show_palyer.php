<table width="70%" border="1" align="left">
  <tr bordercolor="#0821A5" bgcolor="#CCEEFF">
    <th width="2%"><b>P_ID</b></th>
    <th width="2%"><b>Name</b></th>
    <th width="2%"><b>Team_id</b></th>
    <th width="2%"><b>Age</b></th>
    <th width="2%"><b>Dob</b></th>
  </tr> 
<?php
$con = mysql_connect("localhost","root","");
if (!$con)
  {
  die('Could not connect: ' . mysql_error());
  }
mysql_select_db("softball", $con);
$pid=$_GET['p_id'];
$result = mysql_query("SELECT * FROM player where p_id='$pid';");
	// Insert a new row in the table for each person returned
while($row = mysql_fetch_array($result)){
	$p_id= stripslashes($row["p_id"]);
	$p_name= stripslashes($row["p_name"]);
	$team_id= stripslashes($row["team_id"]);
	$age= stripslashes($row["age"]);
	$dob= stripslashes($row["dob"]);
?>
<tr
    <td align="left" bordercolor="#0821A5"  width="9%"><p align="center"><?php echo "$p_id"; ?></p></td>
    <td bordercolor="#0821A5" width="33%"><center> 
<?php 
echo $p_name; 
?></center></td>
    <td bordercolor="#0821A5" width="9%" align="center"><?php echo "$team_id"; ?> 
    </td>
<td bordercolor="#0821A5" width="9%" align="center"><?php echo "$age"; ?> 
    </td>
<td bordercolor="#0821A5" width="9%" align="center"><?php echo "$dob"; ?> 
    </td>
</tr>

<?php
}
?>
</table>