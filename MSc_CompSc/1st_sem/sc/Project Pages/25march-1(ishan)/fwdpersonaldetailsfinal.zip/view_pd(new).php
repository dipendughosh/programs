<html>
<head>
<link href="styles.css" rel="stylesheet" type="text/css">

<script type="text/javascript" src="vpd.js"></script>
</head>

<body>
<form>

<center>
<table width="100%" div align="center" border="0" cellspacing="0" cellpadding="5" class="main">
  <tr> 
    <td colspan="3">&nbsp;</td>
  </tr>
  <tr> 
    <td width="160" valign="top"><p>&nbsp;</p>
      <p>&nbsp; </p>
      <p>&nbsp;</p>
      <p>&nbsp;</p>
      <p>&nbsp;</p></td>
    <td width="732" valign="top"><p>
    </p>
      <h3 class="titlehdr">VIEW PERSONAL DETAILS</h3>
      <p>Please Enter The Faculty Id:
        Please note that fields marked <span class="required">*</span> 
        are required.</p>                
<table width="95%" border="0" cellspacing="3" cellpadding="3" class="forms">

<p> </p>
<p> </p>
<p><tr><td>       
ID:</td><td>                                
<input name="PD_p_id" style="width: 312px" id="PD_p_id" type="text" />  
</td></tr></p>

<tr>
<td colspan="2" align="center">
<input type="button" onclick="strt()" value="SUBMIT" /></td>
</tr>
<p><tr><td></td><td>
</p></td></tr>
</TABLE>
</center>
</form>
<div id="get_response"></div>
</body>
</html>