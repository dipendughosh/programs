<?php
	echo "<p>I am the PHP page..</p>";
	$input=$_POST['text_Name'];
	echo "<p>Hello $input  ..welcome to my web page ..</p>";
?>
