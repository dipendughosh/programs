<?php
	echo "<h1>Welcome to my Home Page..</h1>"
	echo "<p>Today is: date("d/m/y")</p>"
?>