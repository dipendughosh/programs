
/*2. write a pgrm with colors,pixels,bar and cleardevice using random number gen. we hv a function random(no), 
it returns a random no btwn 0 and no.the effect is drwing random radius cirlcles with random color with sme centre and random pixels
kbhit() function is to be used. for looping purpose.*/

#include "graphics.h"
#include "conio.h"
#include "stdlib.h"

void main()
{
    int gd,gm;
    gd=DETECT;
    initgraph(&gd, &gm, "c:/tc/bgi");
	
    setcolor(3);
    setfillstyle(SOLID_FILL,RED);
    bar(50, 50, 590, 430);
   
    setfillstyle(1, 14);
    bar(100, 100, 540, 380);

    while(!kbhit())
    {
	putpixel(random(439)+101,  random(279)+101,random(16));
		delay(300);
	setcolor(random(16));
		delay(300);
	circle(320,240,random(100));
		delay(300);
    }
    getch();
    closegraph();
}