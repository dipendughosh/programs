/**
   * various mouse functions are accessed by setting AX register with diff values(service no)
     and issuing interrupt number 51.
      Functions are listed below
                1. reset mouse.
                2. hide mouse pointer.
                3. show mouse ptr.
				4. show mouse status.
    *
**/

#include<graphics.h>
#include<stdio.h>
#include<conio.h>
#include<dos.h>

       union REGS in,out;

			
		void ResetMouse()
       {
	      in.x.ax=0;
	      int86(51,&in,&out);	      
       }	
			
       int callmouse()
       {
	      in.x.ax=1;
	      int86(51,&in,&out);
	      return(1);
       }
	   
	void restrict (int x1,int y1,int x2, int y2)
	{
	  in.x.ax = 7;
	  in.x.cx = x1;
	  in.x.dx = x2;

	  int86 (51,&in,&out);

	  in.x.ax = 8;
	  in.x.cx = y1;
	  in.x.dx = y2;

	  int86 (51,&in,&out);
	}

       void mouseposi(int *xpos,int *ypos,int *click)
       {
	      in.x.ax=3;
	      int86(51,&in,&out);
	      *click=out.x.bx;
	      *xpos=out.x.cx;
	      *ypos=out.x.dx;
	}
       int mousehide()
       {
	      in.x.ax=2;
	      int86(51,&in,&out);
	      return 1;
       }
	   
      void setposi(int *xpos,int *ypos)
      {
		int g=DETECT,m;
		clrscr();
		initgraph(&g,&m,"c:/tc/bgi");
	     in.x.ax=1;
	     in.x.cx=*xpos;
	     in.x.dx=*ypos;
	     int86(51,&in,&out);
      }

     void mouse_setup()
     {
	int x,y,cl,a,b;
	a=100;
	b=400;
	restrict (50,50,600,450);
	setposi(&a,&b);
	callmouse();
	do
	 {
		    mouseposi(&x,&y,&cl);
		    gotoxy(1,1);
		    printf("Status Of The Mouse :");
		    gotoxy(1,3);
		    printf("COORDINATES :---- X: %d, Y: %d",x,y);printf("   ");

		    if(cl==1)
		    {
			gotoxy(1,4);
			printf("Left Click Occoured ");
			mousehide();
		    }
		    else if(cl==2)
		    {
		      gotoxy(1,4);
		      printf("Right Click Occoured ");
		      callmouse();
		    }
	   }while(!kbhit());
	   getch();
	   printf("\n\n\tPress any key to Exit");
     }

     int main()
      {
		char c;
		
		do
		{		
		 mouse_setup();
		 printf("\nPress E to Exit or R to Reset Mouse :");
		 c=getch();
		 if(c=='E')
		   {
		    break;
		   }
		else
			{
			 ResetMouse();
			}
		}while(1);
		
	     return 0;
      }