Unzip all files in Matlab current directory.
Type "test_main" on Matlab command window.

Requirements:
Matlab, Matlab Image Processing Toolbox


In order to obtain the complete source code please visit http://www.advancedsourcecode.com/imageregistration.asp
or email me luigi.rosa@tiscali.it
 
Luigi Rosa
Via Centrale 35
67042 Civita Di Bagno
L'Aquila - ITALY
mobile +39 3207214179
email luigi.rosa@tiscali.it
website http://www.advancedsourcecode.com