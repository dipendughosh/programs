Copyright (c), 2000, Trustees of Dartmouth College. All rights reserved.
------------------------------------------------------------------------
VERSION 0.2
-----------

This code registers 2-D images. The transformation between images is modeled as locally affine but globally smooth, and explicitly accounts for local and global variations in image intensities. The algorithm is built upon a differential multiscale framework.
The current version of the code supports the extension for missing
data using EM.

This software was written at the Department of Computer Science,
Dartmouth College, by Senthil Periaswamy under the direction of Hany Farid.

Contact information:
--------------------
Senthil Periaswamy (sp@cs.dartmouth.edu)    http://www.cs.dartmouth.edu/~sp
Hany Farid         (farid@cs.dartmouth.edu) http://www.cs.dartmouth.edu/farid

References:
-----------

1) S. Periaswamy and H. Farid.  "Elastic registration in the presence of 
   intensity variations", IEEE Transactions on Medical Imaging, in press, 2003.

2) S. Periaswamy. "General-purpose medical image registration", Ph.D.
   Dissertation, Department of Computer Science, Dartmouth College, 2003

3) S. Periaswamy, J.B. Weaver, D.M. Healy Jr., D. Rockmore, P.J. Kostelec, 
   and H.  Farid. "Differential Affine Motion Estimation for Medical Image 
   Registration" Proceedings of the SPIE - The International Society for 
   Optical Engineering, 4119, pp. 1066-1075, 2000. 


These papers can be downloaded at:
http://www.cs.dartmouth.edu/~sp/pub.htm
http://www.cs.dartmouth.edu/farid/publications/


Note: Tested using MatLab 6.x on linux platforms.
      Does not work on MatLab 5.x

Instructions
------------

1) In the currect directory, run the program 'init.m'
   This adds the subdirectories to matlab's path
   and compiles the C code. It needs to be run once for every
   session.

2) Run register_test to verify that the code is working properly.

3) For registration, use:

   [i1_warped, flow] = register2d(i1,i2);
   i1,i2 are the source and target images. The resultant flow field 
   is placed in the structure flow. 

    The parameters returned in the flow structure are as follows:

    flow.m1() = affine parameter 1 (scale in x)
    flow.m2() = affine parameter 2 (shear in x)
    flow.m3() = affine parameter 3 (shear in y)
    flow.m4() = affine parameter 4 (scale in y)
    flow.m5() = translation in x
    flow.m6() = translation in y
    flow.m7() = contrast map
    flow.m8() = brightness map

    Each field contains width x height elements, where width and height
    are the dimensions of the input image.


4) The default parameters are in:
     register/params_default.m

5) The display output consists of 9 panels (a)-(i):

    a b c
    d e f
    g h i

    a -> source image
    b -> target image
    c -> abs(source - target)
    d -> registered source
    e -> registered source with intensity corrections
    f -> abs(registed source with intensity corrections - target)
    g -> estimated contrast map
    h -> estimated brightness map
    i -> estimated geometric map (flow field)



misc utilitites:
----------------

To apply a flow-field to an image:
    img_warped = flow_warp(img,flow);

To view a flow-field:
    flow_disp(flow)

To apply an affine warp:
    out = aff_warp(img,M);
    (M is a 4x4 affine matrix).

To display the contrast map
    imagesc(flow.m7);

