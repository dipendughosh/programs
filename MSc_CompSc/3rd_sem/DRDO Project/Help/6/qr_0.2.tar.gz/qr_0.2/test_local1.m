
load data/vishum.mat

params=params_default;

params.main.dispFlag       = 0;
params.glob.dispFlag       = 0;
params.em.sigma_global     = 0.001;
params.em.sigma_local      = 0.1;
params.em.useEdgeMask      = 1;
params.em.applybcFlag      = 0;

[i1_warped,flowAcc] = register2dem(i1,i2,params);
dispimg([i1 i2 i1_warped],'source, target and registered source');
save test_local1;

