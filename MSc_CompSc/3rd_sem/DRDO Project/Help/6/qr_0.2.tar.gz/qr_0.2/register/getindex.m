%
% function [index,affFlag,bcFlag] = getindex(model)
%
% Date: March 12, 2004
% By  : Senthil Periaswamy (sp@cs.dartmouth.edu)
%
% Copyright (c), 2000, Trustees of Dartmouth College. All rights reserved.
%


function [index,affFlag,bcFlag] = getindex(model)

    affFlag = 0;
    bcFlag  = 0;

    switch model

        case 1; % Translation
            index = [5 6];

        case 2; % Translation + BC
            index=[5 6 7 8];
            bcFlag = 1;

        case 3; % Affine+Translation
            index=[1 2 3 4 5 6];
            affFlag = 1;

        case 4; % Affine+Translation + BC
            index=[1 2 3 4 5 6 7 8];
            affFlag = 1;
            bcFlag = 1;
    end

return;
