%
% function [M,b,c,r,pt,kt] = affbc_find_api(f,g,model);
%
% Date: March 12, 2004
% By  : Senthil Periaswamy (sp@cs.dartmouth.edu), Dartmouth College.
%
% Copyright (c), 2000, Trustees of Dartmouth College. All rights reserved.
%

function [M,b,c,r,pt,kt] = affbc_find_api(f,g,model,mask);

    global affbc_params;

    [h,w]               = size(f);
    [fx,fy,ft]          = diffxyt(f,g,[3 3]);
    [ind,afFlag,bcFlag] = getindex(model);

    if (~exist('mask','var'))
        mask = ones(h,w);
    end

    affbc_params.h      = h;
    affbc_params.w      = w;
    affbc_params.model  = model;
    affbc_params.index  = ind;
    affbc_params.afFlag = afFlag;
    affbc_params.bcFlag = bcFlag;
    affbc_params.nf     = -f(:)';
    affbc_params.fx     = fx(:)';
    affbc_params.fy     = fy(:)';
    affbc_params.ft     = ft(:)';
    affbc_params.mask   = mask(:)';
    affbc_params.frameSize = 1;

    if (~exist('lamdas','var'))
        lamdas   = ones(length(ind),1);
        deviants = zeros(length(ind),1);
    end


    if (model == 4)
        lamdas   = [1 1 1 1 1 1 1 1]'*10e11;
        deviants = [0 0 0 0 0 0 1 0]';
    end

    affbc_params.S = diag(lamdas);
    affbc_params.D = (lamdas .* deviants);


    %affbc_params.init = 1;
    affbc_find;
    mout = affbc_params.mout;

    M  = [mout(1) mout(2) mout(5); mout(3) mout(4) mout(6); 0 0 1];
    c  = mout(7);
    b  = mout(8);
    r  = mout(9);

    if (nargout > 4)
        pt = affbc_params.pt;
        kt = affbc_params.kt;
    end

return;

