%
% function affbc_iter
%   
% Date: March 12, 2004
% By  : Senthil Periaswamy (sp@cs.dartmouth.edu)
%   
% Copyright (c), 2000, Trustees of Dartmouth College. All rights reserved.
%   


function [M,b,c,W] = affbc_iter(i1,i2,iters,model,emFlag,dispFlag,sigma,useEdgeMask,applybcFlag)


    if (~exist('dispFlag','var'))
        dispFlag = 0;
    end
    if (~exist('emFlag','var'))
        emFlag = 0;
    end
    if (~exist('model','var'))
        model = 4;
    end
    if (~exist('iters','var'))
        iters = 20;
    end
    if (~exist('sigma','var'))
        sigma = 0.001;
    end
    if (~exist('useEdgeMask','var'))
        useEdgeMask = 0;
    end
    if (~exist('applybcFlag','var'))
        applybcFlag = 1;
    end

    %dispFlag = 1;

    if (dispFlag)
        set(gcf,'DoubleBuffer','on');
        set(gcf,'renderer','zbuffer');
        set(gca,'NextPlot','replace','Visible','off')
    end

    affbc_find_init;
    [h,w]   = size(i1);
    W       = ones(h,w);
    [index] = getindex(model);

    c   = 1;
    b   = 0;
    M   = [1 0 0; 0 1 0; 0 0 1];
    i1N = i1;

    if (emFlag)
        W = ones(size(i1));
        if (useEdgeMask)
            W = EdgeMask(i1,i2);  % Initial probability mask
        end
    end

    for i=1:iters

        if (dispFlag)
            fprintf('Iteration: %d\n',i);
            dispimg([i1 i2;i1N W],...
                sprintf('%dx%d Iteration: %d/%d\n',h,w,i,iters),0);

            %dispimgi(i1,i2,i1N,W,...
            %    sprintf('%dx%d Iteration: %d/%d\n',h,w,i,iters));
        end

        [dM db dc,r] = affbc_find_api(i1N,i2,model,W);

        M   = M*dM;
        b   = b+db;
        c   = c*dc;

        if (dispFlag)
            disp(M);
        end

        if (c < 0.1)
            c = 1;
        end

        i1N = aff_warp(i1,M,0);

        if (dispFlag)
            fprintf('c: %g, b: %g, mse: %g\n', c,b,mse(i1N,i2));
        end

        if (applybcFlag)
            i1N = i1N .* c + b;
        end

        if (emFlag)
            W = mask_compute(i1N,i2,sigma);
            if (useEdgeMask)
            W = W .* EdgeMask(i1N,i2);
            end
            button = 0;
            %[x,y,button] = ginput(1);
            if (button > 1)
                keyboard;
            end
        end

    end

return;

function dispimgi(i1,i2,i1N,W,tstr)
    imagesc([i1 i2;i1N W],[0 1]);
    colormap(gray);
    title(sprintf('%s %0.2f %0.2f',tstr,min(W(:)),max(W(:))));
    %h = colorbar('horiz');
    axis image off;
    drawnow;
    %waitforbuttonpress;
return;

 % Find initial mask

function W = EdgeMask(i1,i2)

    t = 0.001;
    W_i1 = edgedetect(i1);
    W_i2 = edgedetect(i2);

    M1  = ones(size(i1));
    ind  = find(W_i1 < t);
    M1(ind) = 0;

    M2  = ones(size(i2));
    ind  = find(W_i2 < t);
    M2(ind) = 0;

    W = M1 .* M2;

    W  = conv2([1 2 1]/4,[1 2 1]/4,W,'same');
    if (max(W(:)) ~= 0)
        W    = W / max(W(:));
    end

return;
