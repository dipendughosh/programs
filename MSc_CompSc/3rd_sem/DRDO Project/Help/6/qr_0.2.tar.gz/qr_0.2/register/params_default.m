%
% function [params] = params_default
%
% Date: March 12, 2004
% By  : Senthil Periaswamy (sp@cs.dartmouth.edu)
%
% Copyright (c), 2000, Trustees of Dartmouth College. All rights reserved.
%

function [params] = params_default

    params.main.boxW           = 5;
    params.main.boxH           = 5;
    params.main.model          = 4;
    params.main.minSize        = 32;
    params.main.dispFlag       = 1;
    params.main.padSize        = 2;

    params.smooth.loops_inner  = 40;
    params.smooth.loops_outer  = 5;
    params.smooth.lamda        = [1e11 1e11 1e11 1e11 1e11 1e11 1e11 1e11];
    params.smooth.deviant      = [0 0 0 0 0 0 1 0];
    params.smooth.dweight      = [0 0 0 0 0 0 0 0];

    params.glob.flag           = 1;
    params.glob.model          = 4;
    params.glob.iters          = 10;
    params.glob.numLevels      = 100;
    params.glob.dispFlag       = 1;
    params.glob.minSize        = 32;

    params.em.sigma_global     = 0.01;
    params.em.sigma_local      = 0.1;
    params.em.useEdgeMask      = 0;
    params.em.applybcFlag      = 0;
    params.em.flagSmooth       = 1;


return;

%    Explanation of parameters
%
%    params.main.boxW           = width of box used in least squares estimate
%    params.main.boxH           = height of box used in least squares estimate
%    params.main.model          = model used in estimation
%
%           4 -> affine + translations + contrast/brightness
%           3 -> affine + translation
%           2 -> translation + contrast/brightness
%           1 -> translation
%
%    params.main.minSize        = lowest scale of pyramid has this size
%    params.main.dispFlag       = display intermediate results
%    params.main.padSize        = padding at coarsest scale
%
%    params.smooth.loops_inner  = Smoothness iterations
%    params.smooth.loops_outer  = Taylor series iterations
%    params.smooth.lamda        = Lamda values on smoothness terms
%                    
%    params.smooth.deviant      = internal, ignore
%    params.smooth.dweight      = internal, ignore
%
%    params.glob.flag           = perform global registration also
%    params.glob.model          = model of global registration,
%                                 similar to local model.
%    params.glob.iters          = iterations used in global estimation
%    params.glob.numLevels      = internal, ignore
%
