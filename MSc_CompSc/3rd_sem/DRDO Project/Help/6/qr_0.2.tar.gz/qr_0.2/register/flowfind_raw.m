%
% function [out]=flowfind_raw(im1,im2,params);
%
% Date: March 12, 2004
% By  : Senthil Periaswamy (sp@cs.dartmouth.edu)
%
% Copyright (c), 2000, Trustees of Dartmouth College. All rights reserved.
%

function [out]=flowfind_raw(im1,im2,params);

    if (~exist('params','var'))
        params = params_default;
    end

    barFlag = 0;
    t0      = clock;

    %%%%%%%%%%%%% Parameters for aff_find
    frameSize = 0;
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    [h_org,w_org] = size(im1);

    %if (h_org == 32)
    %    boxW = 3;
    %    boxH = 3;
    %    model= 2;
    %    fprintf('flowfind_raw: Size: 32x32, setting model=2, box=4\n');
    %end

    boxW        = params.main.boxW;
    boxH        = params.main.boxH;
    model       = params.main.model;
    em_sigma    = params.em.sigma_local;
    mask_smooth = params.em.flagSmooth;


    boxW2 = floor(boxW/2);
    boxH2 = floor(boxH/2);
    im1 = mirror_extend(im1,boxW,boxH);
    im2 = mirror_extend(im2,boxW,boxH);

    [h,w] = size(im1);

    pcOrg = 0;

    if (barFlag)
        hw = waitbar(0,'Estimating flow...');
    end

    [fx,fy,ft]            = diffxyt(im1,im2,[3 3]);
    [index,afFlag,bcFlag] = getindex(model);

    clear  affbc_find;
    global affbc_params;

    affbc_params.model     = model;
    affbc_params.index     = index;
    affbc_params.frameSize = frameSize;
    affbc_params.w = boxW;
    affbc_params.h = boxH;
    affbc_params.afFlag = afFlag;
    affbc_params.bcFlag = bcFlag;

    mask     = ones(h,w);
    mask     = mask_compute(im1,im2,em_sigma,mask_smooth);

    q        =         zeros(5,h,w);
    q(1,:,:) =         -im1;
    q(2,:,:) =         fx;
    q(3,:,:) =         fy;
    q(4,:,:) =         ft;
    q(5,:,:) =         mask;

    mout = zeros(h,w,9);

    for y=boxH2+1:h-boxH2
        if (barFlag)
            pc = (y-boxH2-1)/(h-boxH);
            waitbar(pc,hw);
        end

        y1=y -boxH2;
        y2=y1+boxH -1;
        yind = y1:y2;

        for x=boxW2+1:w-boxW2

            x1=x -boxW2;
            x2=x1+boxW -1;
            xind = x1:x2;

            chunk              = q(:,yind,xind);
            affbc_params.nf    = chunk(1,:);
            affbc_params.fx    = chunk(2,:);
            affbc_params.fy    = chunk(3,:);
            affbc_params.ft    = chunk(4,:);
            affbc_params.mask  = chunk(5,:);

            
            affbc_find;

            mout(y,x,:) = affbc_params.mout;

        end
    end

    out.m1 = mout(:,:,1);
    out.m2 = mout(:,:,2);
    out.m3 = mout(:,:,3);
    out.m4 = mout(:,:,4);
    out.m5 = mout(:,:,5);
    out.m6 = mout(:,:,6);
    out.m7 = mout(:,:,7);
    out.m8 = mout(:,:,8);
    out.r =  mout(:,:,9);


    if (1)
        maxd    = boxW/2;
        ind     = find(abs(out.m5) >= maxd | abs(out.m6) >= maxd); 
        out.m1(ind) = 0;
        out.m2(ind) = 0;
        out.m3(ind) = 0;
        out.m4(ind) = 0;
        out.m5(ind) = 0;
        out.m6(ind) = 0;
        out.m7(ind) = 1;
        out.m8(ind) = 0;
        out.r(ind)  = 0;
        cnt         = length(ind);
        fprintf('out of bounds: %.2f%%\n',cnt/h/w*100);
    end


    out.fx = fx;
    out.fy = fy;
    out.ft = ft;
    out.f  = im1;
    out.g  = im2;
    out.model = model;
    out.index = index;

    out = flow_extract(out,h_org,w_org);

    %waitbar(1,hw);
    if (barFlag)
        close(hw);
    end

    t0=etime(clock,t0);
    fprintf('Elapsed time: %g\n',t0);

return;
