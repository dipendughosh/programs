%
% function [flowAC,img_warped] = flow_add(flowBC,flowAB,img_org)
%
% Date: March 12, 2004
% By  : Senthil Periaswamy (sp@cs.dartmouth.edu)
%
% Copyright (c), 2000, Trustees of Dartmouth College. All rights reserved.
%


function [flowAC,img_warped] = flow_add(flowBC,flowAB,img_org)


    [h,w]   = size(flowAB.m5);

    m5      = flow_warp(flowBC.m5,flowAB,'cubic',1);
    m6      = flow_warp(flowBC.m6,flowAB,'cubic',1);

    n = find(isnan(m5) | isnan(m6));
    m5(n) = 0;
    m6(n) = 0;

    flowAC.m5 = flowAB.m5 + m5;
    flowAC.m6 = flowAB.m6 + m6;


    if (nargin == 3)
        img_warped = flow_warp(img_org,flowAC,'cubic',0);
    end

return;
