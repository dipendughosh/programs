%
% function [i1_warped,flowAcc] = register2d(i1_in,i2_in,params)
%
% Date: March 12, 2004
% By  : Senthil Periaswamy (sp@cs.dartmouth.edu)
%
% Copyright (c), 2000, Trustees of Dartmouth College. All rights reserved.
%

function [i1_warped,flowAcc] = register2d(i1_in,i2_in,params)

    % First set default parameters
    if (~exist('params'))
        params = params_default;
    end

    [h,w]      = size(i1_in);

    % Global registration
    if (params.glob.flag)
       [M,ib,ic] = register2dem_global(i1_in,i2_in,params);
       i1 = aff_warp(i1_in,M);
    else
       i1 = i1_in;
    end

    i2   = i2_in;

    %--------------- Padding begin -----------------------------
    newH = nextpow2(h);
    newW = nextpow2(w);

    padHl = floor((newH-h) / 2);
    padHr = newH-h - padHl;

    padWl = floor((newW-w) / 2);
    padWr = newW-w - padWl;
    
    mind   = min(w,h);
    levels = floor(log2(mind/params.main.minSize)+1);

    padWl   = padWl + (params.main.padSize * 2^levels);
    padHl   = padHl + (params.main.padSize * 2^levels);
    padWr   = padWr + (params.main.padSize * 2^levels);
    padHr   = padHr + (params.main.padSize * 2^levels);

    padW = padWl + padWr;
    padH = padHl + padHr;


    i1 = pad2dlr(i1,padWl,padWr,padHl,padHr,0);
    i2 = pad2dlr(i2,padWl,padWr,padHl,padHr,0);
    [newH,newW] = size(i1);

    %--------------- Padding end -----------------------------

    pyr1(1).im   = i1;
    pyr2(1).im   = i2;

    [ht,wt] = size(pyr1(1).im);

    %--------------- Construct pyramid ----------------------
    fprintf('Pyramid level: %g size: %gx%g mse is: %g\n',...
        1,ht,wt,mse(pyr1(1).im,pyr2(1).im ));

    for i = 2:levels

        pyr1(i).im = reduce(pyr1(i-1).im);
        pyr2(i).im = reduce(pyr2(i-1).im);

        [ht,wt] = size(pyr1(i).im);
        fprintf('Pyramid level: %g size: %gx%g mse is: %g\n',...
            i,ht,wt,mse(pyr1(i).im,pyr2(i).im ));
    end
    fprintf('-----\n');
    %--------------- End construct pyramid ------------------


    [hs,ws] = size(pyr1(levels).im);
    flowAcc = flow_init(ws,hs);

    %--------------- Multiscale registration ------------------
    i1_w = pyr1(levels).im;
    for i=levels:-1:1 % (from coarse to fine)

        fprintf('Pyramid level: %g h: %g w: %g mse is: %g\n',...
                    i,size(pyr1(i).im),mse(pyr1(i).im,pyr2(i).im ));

        % in case we need to stop at a particular level
        if (params.glob.numLevels >= levels-i+1)
            flowAcc = flowfind_smooth(pyr1(i).im,pyr2(i).im,params,...
                          flowAcc,i,levels);
        end

        if (i ~= 1) %for all but the finest scale
                    %prepare for the next scale
            flowAcc  = flow_reduce(flowAcc,-1);
        end

    end
    %--------------- End Multiscale registration ------------------

    % Incorporate global registration map found in beginning
    flowGlob = flow_aff(M,newH,newW);
    flowAcc  = flow_add(flowGlob,flowAcc);

    %undo padding
    flowAcc    = flow_undopad(flowAcc,padWl,padWr,padHl,padHr);

    %warp image with the accumulated flow
    i1_warped = flow_warp(i1_in,flowAcc);

    fprintf('Pyramid level: %g mse is: %g\n',...
            1,mse(i1_warped,i2_in));
    
return;

