%
% function register2dem_global
%   
% Date: March 12, 2004
% By  : Senthil Periaswamy (sp@cs.dartmouth.edu)
%   
% Copyright (c), 2000, Trustees of Dartmouth College. All rights reserved.
%   

function [M,bnew,cnew] = register2dem_global(im1,im2,params)

    if (nargin == 2)
        params = params_default;
    end

    minBlkSize  = params.glob.minSize;
    noIters     = params.glob.iters;
    model       = params.glob.model;
    emFlag      = params.glob.flag;
    sigma       = params.em.sigma_global;
    emDispFlag  = params.glob.dispFlag;
    useEdgeMask = params.em.useEdgeMask;
    applybcFlag = params.em.applybcFlag;

    [h,w] = size(im1);
    steps = floor(log2(w/minBlkSize)+1);

    %steps = 3;
    pyr1(1).im = im1;
    pyr2(1).im = im2;

    %First build pyramids
    scale = 1;
    for i = 2:steps
        pyr1(i).im = reduce(pyr1(i-1).im);
        pyr2(i).im = reduce(pyr2(i-1).im);
        scale = scale * 2;
    end

    M    = eye(3);
    bnew = 0;
    cnew = 1;
    for i = steps:-1:1

        fprintf('Scale: %g\n',scale);
        im1S   = pyr1(i).im;
        im2S   = pyr2(i).im;

        if (i ~= steps)
            M1 = M;
            M1(1:2,3) = M1(1:2,3)/scale;
            im1S = aff_warp(im1S,M1);
        end

        %dispimg([im1S,im2S]);
        [Mnew,b,c]   = affbc_iter(im1S,im2S,noIters,model,emFlag,emDispFlag,sigma,useEdgeMask,applybcFlag);
        cnew = c * cnew;
        bnew = b + bnew;

        Mnew(1:2,3) = Mnew(1:2,3) * scale;
        M     = Mnew * M;
        %Mnew
        %M
        scale = scale/2;
    end


return;

