%
% function flow = flow_init(w,h)
%
% Date: March 12, 2004
% By  : Senthil Periaswamy (sp@cs.dartmouth.edu)
%
% Copyright (c), 2000, Trustees of Dartmouth College. All rights reserved.
%

function flow = flow_init(w,h)

    flow.m5 = zeros(h,w);
    flow.m6 = zeros(h,w);
    flow.m7 =  ones(h,w);
    flow.m8 = zeros(h,w);

return;
