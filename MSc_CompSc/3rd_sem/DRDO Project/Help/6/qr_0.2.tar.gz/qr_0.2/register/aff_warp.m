%
% function [out] = aff_warp(in,M,contFlag
%   
% Date: March 12, 2004
% By  : Senthil Periaswamy (sp@cs.dartmouth.edu)
%   
% Copyright (c), 2000, Trustees of Dartmouth College. All rights reserved.
%  

% function [out] = aff_warp(in,M)

function [out] = aff_warp(in,M,contFlag)

    if (nargin == 2)
        contFlag = 1;
    end

    m         = M(1:2,1:2);
    dx        = M(1,3);
    dy        = M(2,3);
    [h,w]     = size(in);
    a         = h*w;
    [mx,my]   = meshgrid([0:w-1]-w/2+0.5,-([0:h-1]-h/2+0.5));

    pnts      = m * [mx(:)';my(:)']; % order of pnts does not matter

    mx2       = pnts(1,:) + dx;
    my2       = pnts(2,:) + dy;

    mx2       = reshape(mx2,h,w);
    my2       = reshape(my2,h,w);

    out       = interp2(mx,my,in,mx2,my2,'cubic');
    out(isnan(out)) = 0;

    if (contFlag)
        out = out * det(M);
    end

return;
