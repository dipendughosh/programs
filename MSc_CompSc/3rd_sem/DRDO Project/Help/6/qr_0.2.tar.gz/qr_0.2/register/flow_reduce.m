%
% function flow = flow_reduce(flow,scale)
%
% Date: March 12, 2004
% By  : Senthil Periaswamy (sp@cs.dartmouth.edu)
%
% Copyright (c), 2000, Trustees of Dartmouth College. All rights reserved.
%

function flow = flow_reduce(flow,scale)
        scale   = -scale;
        flow.m5 = scaleby2(flow.m5,scale) .* (2^scale);
        flow.m6 = scaleby2(flow.m6,scale) .* (2^scale);

        if (isfield(flow,'m7'))
            flow.m7 = scaleby2(flow.m7,scale);
            flow.m8 = scaleby2(flow.m8,scale);
        end
return;

function out = scaleby2(in,scale)
    
    if (scale == 0)
        out = in;
        return;
    end

    [h,w]   = size(in);
    scale = 2^scale;

    [mx,my] = meshgrid(linspace(1,w,scale*w),linspace(1,h,scale*h));
    out     = interp2(in,mx,my,'linear');

return;
