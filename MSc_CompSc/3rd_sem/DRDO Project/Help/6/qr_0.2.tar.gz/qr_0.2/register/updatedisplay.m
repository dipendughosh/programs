%
% function updatedisplay(i1,i2,flowA,i1_warped,curIter,maxIter,level);
%
% Date: March 12, 2004
% By  : Senthil Periaswamy (sp@cs.dartmouth.edu)
%
% Copyright (c), 2000, Trustees of Dartmouth College. All rights reserved.
%

function updatedisplay(i1,i2,flowA,i1_warped,curIter,maxIter,level);

figure(1);

[h,w] = size(i1);

fprintf('Displaying...');

set(gcf,'DoubleBuffer','on');
set(gca,'NextPlot','replace','Visible','off')
set(gcf,'renderer','zbuffer');

grid        = grid2d(w,h,floor(16*h/256),1);
grid_warped = flow_warp(grid,flowA);

i1_warped_bc = i1_warped .* flowA.m7 + flowA.m8;

imgC = trunc(flowA.m7,0,1);
imgB = trunc(flowA.m8,0,1);

row1 = rowimg(i1,i2,abs(i1-i2));
row2 = rowimg(i1_warped,i1_warped_bc,abs(i1_warped_bc-i2));
row3 = rowimg(flowA.m7, flowA.m8,1-grid_warped);

myimg = [row1;row2;row3];

myimg = frameimg(myimg,1,0);

imagesc(myimg,[0 1]);
colormap(gray);
axis image;
%truesize;
axis off;

x = 2;
y = h*2+15;
dy = 20;

tstr = sprintf('%s [%d x %d] level: %d iter: %d/%d',...
                datestr(now),w,h,level,curIter,maxIter);

title({tstr},'HorizontalAlignment','left','fontname','courier','position',[0 0],'Interpreter','none','FontSize',8);

%set(gca,'position',[0 0 1 0.9]);
drawnow;
fprintf('Done!\n');


return;


function out = rowimg(varargin)

    out = varargin{1};
    out = frameimg(out,1,1);

    for i=2:nargin
       img = varargin{i};
       img = frameimg(img,1,1);
       out = [out img];

    end

return;


function out=trunc(in,minv,maxv)

    out         = in;
    ind         = find(out > maxv);
    out(ind)    = 1;
    ind         = find(out < 0);
    out(ind)    = 0;

return;

