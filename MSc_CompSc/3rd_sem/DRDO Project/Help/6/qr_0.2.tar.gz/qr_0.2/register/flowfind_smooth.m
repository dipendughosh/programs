%
% function flowA = flowfind_smooth(i1,i2,params,flowA,currLevel,totLevels)
%
% Date: March 12, 2004
% By  : Senthil Periaswamy (sp@cs.dartmouth.edu)
%
% Copyright (c), 2000, Trustees of Dartmouth College. All rights reserved.
%

%
% Note:
%
% The unwarped i1 is passed in as a parameter since all
% subsequent warpings are performed using the accumulated
% flow on the original image.

function flowA = flowfind_smooth(i1,i2,params,flowA,currLevel,totLevels)

    [h,w] = size(i1);

    if (~exist('flowA'))
        flowA = flow_init(w,h);
        i1_warped = i1;
    else
        i1_warped  = flow_warp(i1,flowA);
    end

    flow    = flowA;
    flow.m7 = ones(h,w);
    flow.m8 = zeros(h,w);

    dispFlag    = params.main.dispFlag;
    loops_outer = params.smooth.loops_outer;
    loops_inner = params.smooth.loops_inner;



    if (dispFlag)
        hw    = waitbar(0,'Finding Smooth Flow');
        updatedisplay(i1,i2,flowA,i1_warped,0, loops_outer,currLevel);
    end

    for j=1:loops_outer

        fprintf('Outer iteration: %d/%d\n',j,loops_outer);

        flow = flowfind_raw(i1_warped,i2,params);

        clear flow_smooth;
        for i=1:loops_inner
            fprintf('Level: %d/%d Iteration outer: %d/%d inner: %d/%d size: %dx%d\n', totLevels-currLevel+1,totLevels,j,loops_outer,i,loops_inner,w,h);
            if (dispFlag)
                waitbar(i/loops_inner*j/loops_outer,hw);
            end

            flow = flow_smooth(flow,params);

        end

        [flowA,i1_warped] = flow_add(flowA,flow,i1);
        flowA.m7 = flow.m7;
        flowA.m8 = flow.m8;

        if (dispFlag)
            waitbar(i/loops_inner*j/loops_outer,hw,...
            sprintf('iteration %g/%g' ,j,loops_outer));
            updatedisplay(i1,i2,flowA,i1_warped,j, loops_outer,currLevel);
        end

    end

    if (dispFlag)
        close(hw);
    end

return;
