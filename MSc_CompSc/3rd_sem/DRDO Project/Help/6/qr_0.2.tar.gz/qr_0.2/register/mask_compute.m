%
% function W = mask_compute(i1,i2,sigma_sq)
%   
% Date: March 12, 2004
% By  : Senthil Periaswamy (sp@cs.dartmouth.edu)
%   
% Copyright (c), 2000, Trustees of Dartmouth College. All rights reserved.
%   

function W = mask_compute(i1,i2,sigma_sq,flagSmooth)

    if (nargin == 3)
        flagSmooth = 1;
    end

    r1      = i1 - i2;
    r1_sq   = r1 .* r1;

    if (flagSmooth)
        r1_sq   = conv2([1 1 1]/3,[1 1 1]/3,r1_sq,'same');
    end

    r2_sq   = sigma_sq/10;

    er1     = exp(-r1_sq/sigma_sq);
    er2     = exp(-r2_sq/sigma_sq);

    W       = er1 ./ (er1 + er2);

    W       = W / max(W(:));

return

