%
% function flow_disp(flow,skip,color)
%
% Date: March 12, 2004
% By  : Senthil Periaswamy (sp@cs.dartmouth.edu)
%
% Copyright (c), 2000, Trustees of Dartmouth College. All rights reserved.
%

function flow_disp(flow,skip,color)

    if (nargin == 1)
        skip  = 8;
    end

    if (nargin < 3)
        color = 'b';
    end

    [h,w] = size(flow.m5);
    m5 = flow.m5(1:skip:h,1:skip:w);
    m6 = flow.m6(1:skip:h,1:skip:w);
    [flowx flowy] = meshgrid([0:skip:w-1]-w/2+0.5,-([0:skip:h-1]-h/2+0.5));

    %This little bit helps avoid displaying zero vectors
    ind = find(m5 | m6);
    m5 = m5(ind);
    m6 = m6(ind);
    flowx = flowx(ind);
    flowy = flowy(ind);

    quiver(flowx,-flowy,m5,-m6,0,color);
    axis image;
    grid on;
    axis ij;

return;
