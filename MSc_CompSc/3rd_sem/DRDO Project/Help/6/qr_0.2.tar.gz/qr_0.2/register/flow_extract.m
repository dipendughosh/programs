%
% function flow = flow_extract(flow,h,w)
%
% Date: March 12, 2004
% By  : Senthil Periaswamy (sp@cs.dartmouth.edu)
%
% Copyright (c), 2000, Trustees of Dartmouth College. All rights reserved.
%

function flow = flow_extract(flow,h,w)

    [oh,ow] = size(flow.m5);

    x1 = (ow-w)/2+1;
    y1 = (oh-h)/2+1;

    x1 = floor(x1);
    y1 = floor(y1);

    x2 = x1+w-1;
    y2 = y1+h-1;

    if (isfield(flow,'m1'))
        flow.m1 = flow.m1(y1:y2,x1:x2);
    end

    if (isfield(flow,'m2'))
        flow.m2 = flow.m2(y1:y2,x1:x2);
    end

    if (isfield(flow,'m3'))
        flow.m3 = flow.m3(y1:y2,x1:x2);
    end

    if (isfield(flow,'m4'))
        flow.m4 = flow.m4(y1:y2,x1:x2);
    end

    if (isfield(flow,'m5'))
        flow.m5 = flow.m5(y1:y2,x1:x2);
    end

    if (isfield(flow,'m6'))
        flow.m6 = flow.m6(y1:y2,x1:x2);
    end

    if (isfield(flow,'m7'))
        flow.m7 = flow.m7(y1:y2,x1:x2);
    end

    if (isfield(flow,'m8'))
        flow.m8 = flow.m8(y1:y2,x1:x2);
    end

    if (isfield(flow,'r'))
        flow.r = flow.r(y1:y2,x1:x2);
    end

    if (isfield(flow,'g'))
        flow.g = flow.g(y1:y2,x1:x2);
    end

    if (isfield(flow,'f'))
        flow.f = flow.f(y1:y2,x1:x2);
    end


    if (isfield(flow,'fx'))
        flow.fx = flow.fx(y1:y2,x1:x2);
    end

    if (isfield(flow,'fy'))
        flow.fy = flow.fy(y1:y2,x1:x2);
    end

return;
