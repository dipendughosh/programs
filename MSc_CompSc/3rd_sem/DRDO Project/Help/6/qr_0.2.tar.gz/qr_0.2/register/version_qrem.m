% QR_EM Version 0.1
fprintf('QR_EM Version 0.1\n');
