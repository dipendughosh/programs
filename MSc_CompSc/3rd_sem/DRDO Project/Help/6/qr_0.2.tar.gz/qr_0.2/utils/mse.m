%
% function err=mse(i1,i2,b)
%
% Date: March 12, 2004
% By  : Senthil Periaswamy (sp@cs.dartmouth.edu)
%
% Copyright (c), 2000, Trustees of Dartmouth College. All rights reserved.
%

function err=mse(i1,i2,b)

    if (nargin == 3)
        [h,w] = size(i1);
        nh = h - 2*b;
        nw = w - 2*b;
        i1 = cutc(i1,nw,nh);
        i2 = cutc(i2,nw,nh);
    end

    i1 = i1(:);
    i2 = i2(:);

    d  = (i1 - i2);
    d  = d.*d;

    err = sqrt(mean(d));

return
