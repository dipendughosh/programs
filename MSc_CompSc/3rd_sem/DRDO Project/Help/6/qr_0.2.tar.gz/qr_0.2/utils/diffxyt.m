%
% function [fdx,fdy,fdz] = diffxyt(frame1,frame2,filtsizes)
%
% Date: March 12, 2004
% By  : Senthil Periaswamy (sp@cs.dartmouth.edu)
%
% Filter details: 
%
% Copyright (c), 2000, Trustees of Dartmouth College. All rights reserved.
%
% Reference:
% Optimally Rotation-Equivariant Directional Derivative Kernels
%     H. Farid and E.P. Simoncelli
%     Computer Analysis of Images and Patterns (CAIP), Kiel, Germany, 1997 
% See also: http://www.cs.dartmouth.edu/~farid/research/derivative.html
%


function [fdx,fdy,fdz] = diffxyt(frame1,frame2,filtsizes)

    [fdx,fdy,fdz] = c_diffxyt(frame1,frame2);
    return;

    if (nargin == 2)
        filtsizes = [3 3];
    end

    persistent px dx py dy pz dz;

    if (isempty(px))
        [px,dx] = GetDerivPD(filtsizes(1));
        [py,dy] = GetDerivPD(filtsizes(2));
        [pz,dz] = GetDerivPD(2);
    end

    %Step 1: prefilter in t;
    %        dx = prefilter in y, differentiate in x
    %        dy = prefilter in x, differentiate in y
    %frame_pz = frame1 .* pz(1) + frame2 .* pz(2);
    frame_pz = (frame1 + frame2)/2;
    %fdx = conv2(py,dx',frame_pz,'same');
    %fdy = conv2(dy,px',frame_pz,'same');
    fdx = conv2mirr(frame_pz,dx,py);
    fdy = conv2mirr(frame_pz,px,-dy);

    %Step 2: differentiate in t;
    %        dz = prefilter in x and y

    %frame_dz = frame1 .* dz(1) + frame2 .* dz(2);
    frame_dz = frame1 - frame2;

    %fdz = conv2(py,px',frame_dz,'same');
    fdz  = conv2mirr(frame_dz,px,py);

return;

function [p,d] = GetDerivPD(noFrames)

    % Coefficients for smoothing filter p and
    % derivitive filter d provided by Hanny Farid
    % farid@cs.dartmouth.edu

    switch(noFrames)

        case 2
            p = [0.5 0.5];
            d = [-1 1];
        case 3
            p = [0.223755 0.552490 0.223755];
            d = [-0.453014 0.0 0.453014];
        case 4
            p = [0.092645 0.407355 0.407355 0.092645];
            d = [-0.236506 -0.267576 0.267576 0.236506];
        case 5
            p = [0.036420 0.248972 0.429217 0.248972 0.036420];
            d = [-0.108415 -0.280353 0.0 0.280353 0.108415];
        case 6
            p = [0.013846 0.135816 0.350337 0.350337 0.135816 0.01384];
            d = [-0.046266 -0.203121 -0.158152 0.158152 0.203121 0.046266];
        case 7
            p = [0.005165 0.068654 0.244794 0.362775 0.244794 0.068654 0.005165];
            d = [-0.018855 -0.123711 -0.195900 0.0 0.195900 0.123711 0.018855];
        otherwise
            p = 0;
            d = 0;
    end

return;
