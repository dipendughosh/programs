%
% function out = pad(img,bx,by,val)
%
% Date: March 12, 2004
% By  : Senthil Periaswamy (sp@cs.dartmouth.edu)
%
% Copyright (c), 2000, Trustees of Dartmouth College. All rights reserved.
%

function out = pad(img,bx,by,val)

    if (nargin == 3)
        val = 0;
    end

    [h,w] = size(img);
    out   = ones(h+2*by,w+2*bx) .* val;

    out(by+1:by+h,bx+1:bx+w) = img;

return;
