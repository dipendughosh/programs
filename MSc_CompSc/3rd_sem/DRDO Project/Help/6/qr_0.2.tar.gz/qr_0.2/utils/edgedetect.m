
%
% function out=edgedetect(frame1)
%
% Date: March 12, 2004
% By  : Senthil Periaswamy (sp@cs.dartmouth.edu)
%
% Copyright (c), 2000, Trustees of Dartmouth College. All rights reserved.
%

function out=edgedetect(frame1)

    p = [0.036420 0.248972 0.429217 0.248972 0.036420];
    d = [-0.108415 -0.280353 0.0 0.280353 0.108415];

    fdx = conv2mirr(frame1,d,p);
    fdy = conv2mirr(frame1,p,-d);

    out = sqrt(fdx .* fdx + fdy .* fdy);

return;
