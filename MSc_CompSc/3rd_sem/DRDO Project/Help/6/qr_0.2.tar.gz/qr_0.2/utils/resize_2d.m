%
% function out = resize_2d(in,w,h)
%
% Date: March 12, 2004
% By  : Senthil Periaswamy (sp@cs.dartmouth.edu)
%
% Copyright (c), 2000, Trustees of Dartmouth College. All rights reserved.
%

function out = resize_2d(in,w,h)

    [oh,ow] = size(in);
    [mx,my] = meshgrid(linspace(1,oh,h), linspace(1,ow,w));
    out     = interp2(in,mx,my,'cubic');
    
return;
