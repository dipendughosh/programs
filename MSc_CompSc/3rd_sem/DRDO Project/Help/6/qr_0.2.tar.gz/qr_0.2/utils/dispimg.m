%
% function dispimg(img,tStr,trueSizeFlag);
%   
% Date: March 12, 2004
% By  : Senthil Periaswamy (sp@cs.dartmouth.edu)
%   
% Copyright (c), 2000, Trustees of Dartmouth College. All rights reserved.
%  

function dispimg(img,tStr,trueSizeFlag);

    if (~exist('trueSizeFlag','var'))
        trueSizeFlag = 1;
    end

    imagesc(img,[0 1]);
    axis('image');
    colormap(gray);

    if (trueSizeFlag)
        truesize2(img);
    else
        title('');
        axis off;
    end
    
    %These routines require the image processing toolbox.
    %pixval on;
    %truesize;

    if (exist('tStr','var'))
        try
            % matlab versions <= 6.0 do not support backgroundcolor
            text(10,20,tStr,'backgroundcolor','white');
        catch
        end
    end

    refresh;
    drawnow;

return;


function truesize2(img)
    title('');
    axis off;
    pos = get(gcf,'position');
    glob    = get(gcf,'UserData');
    [h,w]   = size(img);
    set(gca,'position',[0 0 1 1]);
    pos = get(gcf,'position');
    set(gcf,'position',[pos(1) pos(2) w h]);
return;

