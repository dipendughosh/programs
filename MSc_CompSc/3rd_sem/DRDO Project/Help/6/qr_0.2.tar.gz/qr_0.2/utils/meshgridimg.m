%
% function [mx,my] = meshgridimg(w,h)
%
% Date: March 12, 2004
% By  : Senthil Periaswamy (sp@cs.dartmouth.edu)
%
% Copyright (c), 2000, Trustees of Dartmouth College. All rights reserved.
%

function [mx,my] = meshgridimg(w,h)

    [mx,my]   = meshgrid([0:w-1]-w/2+0.5,-([0:h-1]-h/2+0.5));

return;
