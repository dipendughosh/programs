
/*
   Date: April 19, 2003
   By  : Senthil Periaswamy (sp@cs.dartmouth.edu)
   Copyright (c), 2000, Trustees of Dartmouth College. All rights reserved.
*/


#include "mex.h"
#include <string.h>

void SmoothAvg(double *in, double mVal, long width, long height, double *out);
void FixBorders(double *img,long w, long h);

void mexFunction(int nlhs, mxArray *plhs[], int nrhs,const mxArray *prhs[])
{
    double *imgIn, *imgOut;
    long h,w;
    double mVal;

    if (nrhs != 2 || nlhs != 1)
    {
        mexErrMsgTxt("Usage: out=c_smoothavg(img)");
    }

    imgIn     = mxGetPr(prhs[0]);
    mVal      = mxGetScalar(prhs[1]);
    w         = (long)mxGetN(prhs[0]);
    h         = (long)mxGetM(prhs[0]);

    plhs[0]   = mxCreateDoubleMatrix(h,w,mxREAL);
    imgOut    = mxGetPr(plhs[0]);

    SmoothAvg(imgIn,mVal,w, h, imgOut);
    FixBorders(imgOut,w,h);
}



/*

1 4 1
4 0 4
1 4 1
*/

void SmoothAvg(double *i1, double mVal, long width, long height, double *out)
{

    double *ptr1 = i1;
    double *ptr2 = i1+height;
    double *ptr3 = i1+2*height;
    double *ptr0 = out+1+height;

    long w,h;

    w = width-3;
    do
    {
        h = height-3;
        do
        {
            /*
                *(ptr1  )   *(ptr2  )   *(ptr3  )
                *(ptr1+1)   *(ptr2+1)   *(ptr3+1)
                *(ptr1+2)   *(ptr2+2)   *(ptr3+2)
            */

            *(ptr0++) = (\
                (*(ptr1  ) + *(ptr1+2) + *(ptr3  ) + *(ptr3+2)) + \
                (*(ptr1+1) + *(ptr2  ) + *(ptr2+2) + *(ptr3+1))*4)*mVal;
                
            ptr1++;
            ptr2++;
            ptr3++;

        } while(h--);
        
        ptr1++;
        ptr2++;
        ptr3++;
        ptr0++;

        ptr1++;
        ptr2++;
        ptr3++;
        ptr0++;

    } while(w--);
}



void FixBorders(double *img,long w, long h)
{
    long x,y;

    for(x=0;x<w;x++)
    {
        *(img+x) = *(img+x+h);
        *(img+(h-1)*w+x) = *(img+(h-2)*w+x);
    }

    for(y=0;y<w*h;y+=w)
    {
        *(img+y) = *(img+y+1);
        *(img+w-1+y)=*(img+w-2+y) ;
    }

}
