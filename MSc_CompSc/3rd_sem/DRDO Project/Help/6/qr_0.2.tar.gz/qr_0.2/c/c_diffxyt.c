
/*
   Date: April 19, 2003
   By  : Senthil Periaswamy (sp@cs.dartmouth.edu)
   Copyright (c), 2000, Trustees of Dartmouth College. All rights reserved.
*/

#include "mex.h"
#include <string.h>


void Diffxyt(double *i1, long w, long h, double *out);
void Diffxyt_dp(double *in, long width, long height, double *out, double *t1, double *t2);
void Diffxyt_pd(double *in, long width, long height, double *out, double *t1, double *t2);
void Diffxyt_pp(double *in, long width, long height, double *out);
void Sett1t2(double *img, double *t1, double *t2,long area);
void compute_avg(double *img1,double *img2,double *imgP, long area);
void compute_dif(double *img1,double *img2,double *imgP, long area);
void FixBorders(double *img,long w, long h);

/* BUGFIXES
 *
 * June 7, 2002 : made it work for different w,h (changed Diffxyt_pp)
 * June 20,2002 : Added mxDestroyArrac calls - memory leak
 *
 *
 *
 *
 */


void mexFunction(int nlhs, mxArray *plhs[], int nrhs,const mxArray *prhs[])
{
    double *img1, *img2, *t1, *t2, *imgP;
    double *fx, *fy, *ft;
    double h,w;
    long area;
    mxArray *mxt1, *mxt2, *mxP;

    if (nrhs != 2 || nlhs != 3)
    {
        mexErrMsgTxt("Usage: [fx,fy,ft]=diff(img1,img2)");
    }

    img1      = mxGetPr(prhs[0]);
    img2      = mxGetPr(prhs[1]);
    w         = mxGetN(prhs[0]);
    h         = mxGetM(prhs[0]);

    plhs[0]   = mxCreateDoubleMatrix(h,w,mxREAL);
    plhs[1]   = mxCreateDoubleMatrix(h,w,mxREAL);
    plhs[2]   = mxCreateDoubleMatrix(h,w,mxREAL);
    fx        = mxGetPr(plhs[0]);
    fy        = mxGetPr(plhs[1]);
    ft        = mxGetPr(plhs[2]);

    mxt1   = mxCreateDoubleMatrix(h,w,mxREAL);
    mxt2   = mxCreateDoubleMatrix(h,w,mxREAL);
    mxP    = mxCreateDoubleMatrix(h,w,mxREAL);
    t1     = mxGetPr(mxt1);
    t2     = mxGetPr(mxt2);
    imgP   = mxGetPr(mxP);

    area = w*h;

    compute_avg(img1,img2,imgP,area);

    Sett1t2(imgP,t1,t2,w*h);

    Diffxyt_pd(imgP, w, h, fx,t1,t2);
    Diffxyt_dp(imgP, w, h, fy,t1,t2);

    compute_dif(img1,img2,imgP,area);
    Diffxyt_pp(imgP, w, h, ft);


    FixBorders(fx,w,h);
    FixBorders(fy,w,h);
    FixBorders(ft,w,h);

    mxDestroyArray(mxt1);
    mxDestroyArray(mxt2);
    mxDestroyArray(mxP);
}

void compute_avg(double *img1,double *img2,double *imgP, long area)
{
    do
    {
        *(imgP++) = (*(img1++) + *(img2++))/2;
    }while(--area);

}

void compute_dif(double *img1,double *img2,double *imgP, long area)
{
    do
    {
        *(imgP++) = (*(img1++) - *(img2++));
    }while(--area);

}

void Sett1t2(double *in, double *t1, double *t2,long area)
{
    memcpy(t1,in,area * sizeof(double));
    memcpy(t2,in,area * sizeof(double));

    do
    {
        *(t1++) *= 0.101364;
        *(t2++) *= 0.250286;
    }while(--area);
}

/*
Matlab stores arrays in column major format:

0 4 8
1 5 9 
2 6 10 
3 7 11

-0.1014 0 0.1014
-0.2503 0 0.2503
-0.1014 0 0.1014

*/



void Diffxyt_pd(double *in, long width, long height, double *out, double *t1, double *t2)
{
    long w,h;
    double *t1Ptr = t1;
    double *t2Ptr = t2;
    double *ptr0 = out+1+height;

    double *ker11 = t1Ptr;
    double *ker13 = t1Ptr+2*height;
    double *ker21 = t2Ptr+1;
    double *ker23 = t2Ptr+2*height+1;


#define KER11 ((*(ker11)))
#define KER21 ((*(ker21)))
#define KER31 ((*(ker11+2)))
#define KER13 (-(*(ker13)))
#define KER23 (-(*(ker23)))
#define KER33 (-(*(ker13+2)))
#define MOVEDOWN {ker11++;ker13++;ker21++;ker23++;}

    w = width-3;
    do
    {
        h = height-3;
        do
        {
            *(ptr0++) = KER11+KER21+KER31+KER13+KER23+KER33;
            MOVEDOWN;

        } while(h--);

        MOVEDOWN;
        MOVEDOWN;

        ptr0++;
        ptr0++;

    } while(w--);

}

/*
Matlab stores arrays in column major format:

0 4 8
1 5 9 
2 6 10 
3 7 11

    0.1014    0.2503    0.1014
         0         0         0
   -0.1014   -0.2503   -0.1014


*/
#undef KER11 
#undef KER12 
#undef KER13 
#undef KER31 
#undef KER32 
#undef KER33 
#undef MOVEDOWN



void Diffxyt_dp(double *in, long width, long height, double *out, double *t1, double *t2)
{
    long w,h;
    double *t1Ptr = t1;
    double *t2Ptr = t2;
    double *ptr0 = out+1+height;

    double *ker11 = t1Ptr;
    double *ker12 = t2Ptr+height;
    double *ker13 = t1Ptr+2*height;


#define KER11 (-(*(ker11)))
#define KER12 (-(*(ker12)))
#define KER13 (-(*(ker13)))
#define KER31 ((*(ker11+2)))
#define KER32 ((*(ker12+2)))
#define KER33 ((*(ker13+2)))

#define MOVEDOWN {ker11++;ker12++;ker13++;}

    w = width-3;
    do
    {
        h = height-3;
        do
        {
            *(ptr0++) = KER11+KER12+KER13+KER31+KER32+KER33;
            MOVEDOWN;

        } while(h--);

        MOVEDOWN;
        MOVEDOWN;

        ptr0++;
        ptr0++;

    } while(w--);

}


/*
0.0500663 0.123622 0.0500663 
0.123622  0.305245 0.123622 
0.0500663 0.123622 0.0500663 
*/



void Diffxyt_pp(double *i1, long width, long height, double *out)
{

    double *ptr1 = i1;
    double *ptr2 = i1+height;
    double *ptr3 = i1+2*height;
    double *ptr0 = out+1+height;

    long w,h;

    w = width-3;
    do
    {
        h = height-3;
        do
        {
            /*
                *(ptr1  )   *(ptr2  )   *(ptr3  )
                *(ptr1+1)   *(ptr2+1)   *(ptr3+1)
                *(ptr1+2)   *(ptr2+2)   *(ptr3+2)
            */

            *(ptr0++) = \
                (*(ptr1  ) + *(ptr1+2) + *(ptr3  ) + *(ptr3+2)) * 0.0500663 + \
                (*(ptr1+1) + *(ptr2  ) + *(ptr2+2) + *(ptr3+1)) * 0.1236223 + \
                (*(ptr2+1) * 0.305245);
                
            ptr1++;
            ptr2++;
            ptr3++;

        } while(h--);
        
        ptr1++;
        ptr2++;
        ptr3++;
        ptr0++;

        ptr1++;
        ptr2++;
        ptr3++;
        ptr0++;

    } while(w--);
}


#ifdef sdfsdf
void Diffxyt(double *i1, long width, long height, double *out)
{

    double *ptr1 = i1;
    double *ptr2 = i1+width;
    double *ptr3 = i1+2*width;
    double *ptr0 = out+1+width;

    long w,h;

    h = height-3;
    do
    {
        w = width-3;
        do
        {
            *ptr0 = *(ptr1  ) + *(ptr2  ) + *(ptr3  ) +\
                    *(ptr1+1) + *(ptr2+1) + *(ptr3+1) +\
                    *(ptr1+2) + *(ptr2+2) + *(ptr3+2);

            *ptr0 = *ptr0 / 9;

            ptr1++;
            ptr2++;
            ptr3++;
            ptr0++;

        } while(w--);

        ptr1 += 2;
        ptr2 += 2;
        ptr3 += 2;
        ptr0 += 2;

    } while(h--);
}
#endif

void FixBorders(double *img,long w, long h)
{
    long x,y;

    for(x=0;x<w;x++)
    {
        *(img+x) = *(img+x+h);
        *(img+(h-1)*w+x) = *(img+(h-2)*w+x);
    }

    for(y=0;y<w*h;y+=w)
    {
        *(img+y) = *(img+y+1);
        *(img+w-1+y)=*(img+w-2+y) ;
    }

}
