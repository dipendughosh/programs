
i1 = imread('data/sag1_noise.tif');
i1 = double(i1) / 256;

i2 = imread('data/sag2.tif');
i2 = double(i2) / 256;

params                  = params_default;
params.glob.dispFlag    = 0;
params.main.dispFlag    = 0;
params.em.sigma_global  = 0.1;
params.em.sigma_local   = 0.01;
params.em.useEdgeMask   = 1;
params.em.applybcFlag   = 0;
params.em.flagSmooth    = 0;


[i1_warped,flowAcc] = register2dem(i1,i2,params);
dispimg([i1 i2 i1_warped],'source, target and registered source');
save test_local2;

