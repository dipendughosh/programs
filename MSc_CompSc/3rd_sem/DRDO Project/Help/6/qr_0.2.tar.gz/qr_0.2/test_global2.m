%BLACK SQUARE + WHITE SQUARE
%Global example

i1 = imread('data/sag1.tif');
i1 = double(i1) / 256;
[h,w] = size(i1);

t= -10 * pi/180;
M=[cos(t) sin(t) 0; -sin(t) cos(t) 0; 0 0 1 ];
M_org = M*[1.3 0 1.5;0 1.3 -2.5;0 0 1]

i2 = aff_warp(i1,M_org) ;

dx = 1;
dy = 1;
dw = 128;
dh = 128;
i1([1:dh]+dy,[1:dw]+dx) = 0;

dx = 64;
dy = 120;
dw = 64;
dh = 64;
i2([1:dh]+dy,[1:dw]+dx) = 1;

params                  = params_default;
params.glob.dispFlag    = 1;
params.em.sigma_global  = 0.01;
params.em.useEdgeMask   = 0;
params.em.applybcFlag   = 0;


dispimg([i1 i2],'Original Images: source and target');

figure;
[M,ib,ic] = register2dem_global(i1,i2,params);
i1w = aff_warp(i1,M);
dispimg([i1 i2 i1w],'source, target and registered source');

M
M_org

