%PARTIAL IMAGE


i1 = imread('data/sag1.tif');
i1 = double(i1) / 256;
[h,w] = size(i1);


t= -10 * pi/180;
M=[cos(t) sin(t) 0; -sin(t) cos(t) 0; 0 0 1 ];
M_org = M*[1.3 0 1.5;0 1.3 -2.5;0 0 1]

i2 = i1;
i1 = aff_warp(i2,inv(M_org),1);

dx = 64;
dy = 64;
dw = 128;
dh = 128;

mask = zeros(h,w);
mask(dy:dy+dh-1,dx:dx+dw-1) = 1;
i2 = i2 .* mask ;

params                  = params_default;
params.glob.dispFlag    = 1;
params.em.sigma_global  = 0.001;
params.em.useEdgeMask   = 1;
params.em.applybcFlag   = 1;


dispimg([i1 i2]);
figure;

[M,ib,ic] = register2dem_global(i1,i2,params);
i1w = aff_warp(i1,M);
dispimg([i1 i2 i1w],'source, target and registered source');

M
M_org
