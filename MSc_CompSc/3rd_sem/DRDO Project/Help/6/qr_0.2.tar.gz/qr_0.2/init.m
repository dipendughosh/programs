
% Compile c code and initialize paths

addpath('.','./c','./register','./utils');

if (exist('c_diffxyt') ~= 3)
    fprintf('Compiling c/c_diffxyt.c\n');
    cd c
    mex c_diffxyt.c  
    cd ..
end

if (exist('c_smoothavg') ~= 3)
    fprintf('Compiling c/c_smoothavg.c\n');
    cd c
    mex c_smoothavg.c
    cd ..
end

