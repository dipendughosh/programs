
i1 = imread('data/sag1.tif');
i1 = double(i1) / 256;
i2 = imread('data/sag2.tif');
i2 = double(i2) / 256;
[h,w] = size(i1);

params                  = params_default;
params.glob.dispFlag    = 1;
params.em.sigma_global  = 0.01;
params.em.useEdgeMask   = 0;
params.em.applybcFlag   = 0;


dispimg([i1 i2],'Original Images: source and target');

figure;
[M,ib,ic] = register2dem_global(i1,i2,params);

i1w = aff_warp(i1,M);
dispimg([i1 i2 i1w],'source, target and registered source');

