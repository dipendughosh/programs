
init;

i1 = imread('data/sag1.tif');
i2 = imread('data/sag2.tif');
i1 = double(i1) / 255;
i2 = double(i2) / 255;

[i1_warped,flow]=register2d(i1,i2);

figure;
imagesc([i1 i2],[0,1]);colormap(gray);axis image;
title('source and target');

figure;
imagesc(i1_warped,[0,1]);colormap(gray);axis image;
title('registered source');

figure;
flow_disp(flow);
title('estimated geometric map');

figure;
imagesc([flow.m7 flow.m8],[0 1]);colormap(gray);axis image;
title('estimated contrast and brightness maps');

figure;
imagesc(i1_warped .* flow.m7 + flow.m8,[0 1]);colormap(gray);axis image;
title('registered source with intensity corrections');

