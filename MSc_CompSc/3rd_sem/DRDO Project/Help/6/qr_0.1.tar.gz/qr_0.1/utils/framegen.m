%
% function [H] = framegen(h,w,frameSize)
%
% Date: April 19, 2003
% By  : Senthil Periaswamy (sp@cs.dartmouth.edu)
%
% Copyright (c), 2000, Trustees of Dartmouth College. All rights reserved.
%

function [H] = framegen(h,w,frameSize)

    H = zeros(h,w); 
    H(frameSize+1:h-frameSize,frameSize+1:w-frameSize) = 1; 

return;
