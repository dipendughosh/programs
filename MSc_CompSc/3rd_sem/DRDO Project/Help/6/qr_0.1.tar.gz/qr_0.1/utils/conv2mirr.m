%USAGE: out = conv2mirr(in,fy,fx)
%
%       This function performs a 2D convolution
%       after mirroring the boundaries.
%       Since matlab's conv2 function processes
%       the columns first, we first mirror the rows.
%        
%       If the kernel is non-seperable, pass it
%       in parameter fx and ignore fy.
%
%
% Date: April 19, 2003
% By  : Senthil Periaswamy (sp@cs.dartmouth.edu)
%
% Copyright (c), 2000, Trustees of Dartmouth College. All rights reserved.
%

function out = conv2mirr(in,fx,fy)

    [h,w] = size(in);

    %Size of the borders to flip
    if (nargin == 3)
        nl = round((length(fx)-1)/2);
        nu = round((length(fy)-1)/2);
    else
        %non-seperable mask passed
        [lfy lfx] = size(fx);
        nl = round((lfx-1)/2);
        nu = round((lfy-1)/2);
    end

    nr = nl;
    nd = nu;

    %First flip up and down
    u = flipud(in([2:1+nu],:));
    d = flipud(in([h-nd:h-1],:));

    in2 = [u' in' d']';

    %Next flip left and right
    l = fliplr(in2(:, [2:1+nl]));
    r = fliplr(in2(:,[w-nr:w-1]));

    %set the 'mirrored' image to out.
    out = [l in2 r];

    if (nargin == 3)
        out = conv2(fy,fx,out,'valid');
    else
        out = conv2(out,fx,'valid');
    end

    out = out([1:h],[1:w]);

return;

%test
A = [1 2 3 4;5 6 7 8;9 10 11 12]
B = conv2mirr(A,[1 1 1],[1 1 1])
C = conv2mirr(A,[1 1 1;1 1 1;1 1 1])

