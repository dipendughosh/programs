%
% function out = cutc(img,newW,newH)
%
% Date: April 19, 2003
% By  : Senthil Periaswamy (sp@cs.dartmouth.edu)
%
% Copyright (c), 2000, Trustees of Dartmouth College. All rights reserved.
%

function out = cutc(img,newW,newH)

    if (nargin == 2)
        newH = newW;
    end

    [h,w] = size(img);
    y = round((h-newH)/2)+1;
    x = round((w-newW)/2)+1;
    
    out = img(y:y+newH-1,x:x+newW-1);
