%
% function pat = grid(w,h,t,v)
%
% Date: April 19, 2003
% By  : Senthil Periaswamy (sp@cs.dartmouth.edu)
%
% Copyright (c), 2000, Trustees of Dartmouth College. All rights reserved.
%

function pat = grid(w,h,t,v)

    pat = zeros(h,w);

    pat(1:t:h,1:w) = v;
    pat(1:h,1:t:w) = v;

    pat(h,1:w)     = v;
    pat(1:h,w)     = v;

return;

