%
% function out = mirror_extend(in,bx,by)
%
% Date: April 19, 2003
% By  : Senthil Periaswamy (sp@cs.dartmouth.edu)
%
% Copyright (c), 2000, Trustees of Dartmouth College. All rights reserved.
%

function out = mirror_extend(in,bx,by)

%Note: works for both even and odd bx/by!

    [h,w] = size(in);

    %First flip up and down
    u = flipud(in([2:1+by],:));
    d = flipud(in([h-by:h-1],:));

    in2 = [u' in' d']';

    %Next flip left and right
    l = fliplr(in2(:, [2:1+bx]));
    r = fliplr(in2(:,[w-bx:w-1]));

    %set the 'mirrored' image to out.
    out = [l in2 r];

return;

%test
A = [1 2 3 4;5 6 7 8;9 10 11 12]
B = mirror_extend(A,2,2)

