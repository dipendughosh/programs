%
% function imgOut = pad2dlr(imgIn,padWl,padWr,padHl,padHr,val,undoFlag)
%
% Date: April 19, 2003
% By  : Senthil Periaswamy (sp@cs.dartmouth.edu)
%
% Copyright (c), 2000, Trustees of Dartmouth College. All rights reserved.
%

function imgOut = pad2dlr(imgIn,padWl,padWr,padHl,padHr,val,undoFlag)

    if (~exist('val','var'))
        val = 0;
    end

    if (~exist('undoFlag','var'))
        undoFlag = 0;
    end

    [h,w] = size(imgIn);
    if (undoFlag == 0)
        imgOut= ones(h+padHl+padHr,w+padWl+padWr) .* val;
        imgOut(padHl+1:padHl+h,padWl+1:padWl+w) = imgIn;
    else
        h = h - padHl - padHr;
        w = w - padWl - padWr;
        imgOut = imgIn(padHl+1:padHl+h,padWl+1:padWl+w);
    end

return;

