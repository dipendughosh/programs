%
% function [out] = frameimg(in,b,val)
%
% Date: April 19, 2003
% By  : Senthil Periaswamy (sp@cs.dartmouth.edu)
%
% Copyright (c), 2000, Trustees of Dartmouth College. All rights reserved.
%

function [out] = frameimg(in,b,val)

    [h,w] = size(in);
    H1     = framegen(h,w,b);
    H2     = 1-H1;

    out = in .* H1 + H2 .* val;

return;
