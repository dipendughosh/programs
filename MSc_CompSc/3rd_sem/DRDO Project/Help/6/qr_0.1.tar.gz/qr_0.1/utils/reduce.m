%
% function out = reduce(in, cnt)
%
% Date: April 19, 2003
% By  : Senthil Periaswamy (sp@cs.dartmouth.edu)
%
% Copyright (c), 2000, Trustees of Dartmouth College. All rights reserved.
%
%
%USAGE: out = reduce(in, cnt);
%
%       This function blurrs img
%       with the seperable filter 
%       [.05 .25 .4 .25 .05] 
%       and then subsamples.
%       Process repeated cnt times.

function img = reduce(img,cnt)

    
    [h,w] = size(img);
    filt  = [.05 .25 .4 .25 .05];

    if (nargin == 1)
        cnt = 1;
    end

    if (cnt == 0)
        return;
    end

    for i = 1:cnt
        img  = conv2mirr(img,filt,filt);
        img  = img([1:2:h],[1:2:w]);
        h = h/2;
        w = w/2;
    end

return;
