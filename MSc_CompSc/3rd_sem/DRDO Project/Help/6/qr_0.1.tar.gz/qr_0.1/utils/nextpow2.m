%
% function v = nextpow2(v)
%
% Date: April 19, 2003
% By  : Senthil Periaswamy (sp@cs.dartmouth.edu)
%
% Copyright (c), 2000, Trustees of Dartmouth College. All rights reserved.
%

function v = nextpow2(v)

    l = log2(v);
    if (l == floor(l))
        return;
    end

    v = 2^round(log2(v)+0.5);

return;
