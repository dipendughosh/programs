% QR Version 0.1
fprintf('QR Version 0.1\n');
