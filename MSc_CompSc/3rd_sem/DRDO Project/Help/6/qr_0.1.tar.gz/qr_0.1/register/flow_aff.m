%
% function flow = flow_aff(M,w,h)
%
% Date: April 19, 2003
% By  : Senthil Periaswamy (sp@cs.dartmouth.edu)
%
% Copyright (c), 2000, Trustees of Dartmouth College. All rights reserved.
%


function flow = flow_aff(M,w,h)

    m         = M(1:2,1:2);
    dx        = M(1,3);
    dy        = M(2,3);

    [mx my]   = meshgridimg(w,h);
    pnts      = m * [mx(:)';my(:)'] ;
    vx        = pnts(1,:) + dx;
    vy        = pnts(2,:) + dy;
    vx        = reshape(vx,h,w);
    vy        = reshape(vy,h,w);
    vx        =  vx - mx;
    vy        =  vy - my;
    flow.m5   =  vx;
    flow.m6   =  vy;

return;
