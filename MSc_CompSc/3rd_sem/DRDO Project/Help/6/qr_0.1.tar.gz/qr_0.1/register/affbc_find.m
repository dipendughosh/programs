%
% function affbc_find
%
% Date: April 19, 2003
% By  : Senthil Periaswamy (sp@cs.dartmouth.edu)
%
% Copyright (c), 2000, Trustees of Dartmouth College. All rights reserved.
%

function affbc_find

    global affbc_params;

    persistent h w mx my H pt m minus_ones afFlag bcFlag iFlag rankE mout_def

    %if (isempty(mx) | affbc_params.init == 1)
    if (isempty(mx))
        [w,h,mx,my,H,rankE,afFlag,bcFlag,iFlag,minus_ones,mout_def]=...
                                           affbc_init(affbc_params);
        affbc_params.init = 0;
        affbc_params.mout = [mout_def 0];
    end

    % premultiply derivatives with box filter
    if (affbc_params.frameSize > 0)
        affbc_params.fx = affbc_params.fx .* H;
        affbc_params.fy = affbc_params.fy .* H;
        affbc_params.ft = affbc_params.ft .* H;
        affbc_params.nf = affbc_params.nf .* H;
        minus_ones  = minus_ones .* H;
    end

    %set entire p transpose
    p1 = affbc_params.fx .* mx;
    p2 = affbc_params.fx .* my;
    p3 = affbc_params.fy .* mx;
    p4 = affbc_params.fy .* my;


    affbc_params.pt = [p1;p2;p3;p4;...
                 affbc_params.fx;affbc_params.fy;affbc_params.nf; minus_ones];

    affbc_params.kt = affbc_params.ft;

    if (bcFlag)
        affbc_params.kt = affbc_params.kt + affbc_params.nf;
    end

    if (afFlag)
        affbc_params.kt = affbc_params.kt +  p1+ p4;
    end

    %choose only parameters needed
    if (iFlag)
        affbc_params.pt      = affbc_params.pt(affbc_params.index,:);
    end

    %Calculate P = p' * p
    P = (affbc_params.pt) * affbc_params.pt';
    K = (affbc_params.pt) * affbc_params.kt';

    if (rcond(P) > 10e-8)
    %if (rank(P) == rankE)
        m = inv(P) * K;
        %m = inv(P+affbc_params.S) * (K+affbc_params.D);
        r = 1;
    else
        m = mout_def;
        r = 0;
    end

    affbc_params.mout = [1 0 0 1 0 0 1 0 r];
    
    if (iFlag)
        affbc_params.mout(affbc_params.index) = m;
    else
        affbc_params.mout(1:8) = m;
    end

return;


function [w,h,mx,my,H,rankE,afFlag,bcFlag,iFlag, o,mout_def]=...
                                                   affbc_init(affbc_params)
    %Initialize things
    %fprintf('affbc_find Initializing...\n');
    w         = affbc_params.w;
    h         = affbc_params.h;
    [mx,my]   = meshgridimg(w,h);
    H         = framegen(w,h,affbc_params.frameSize); %box filter
    noFields  = length(affbc_params.index);
    rankE     = noFields;
    afFlag    = affbc_params.afFlag;
    bcFlag    = affbc_params.bcFlag;

    iFlag   = ~(afFlag & bcFlag);

    %Expected rank
    rankE   = noFields;
    o       = -ones(1,h*w);

    %linearize into rows
    mx = mx(:)';
    my = my(:)';
    H  =  H(:)';

    %default values for all parameters
    mout_def      = [1 0 0 1 0 0 1 0];
    %choose only parameters we need
    mout_def      = mout_def(affbc_params.index);
    %fprintf('affbc_find Done\n');

return;

