%
% function affbc_init
%
% Date: April 19, 2003
% By  : Senthil Periaswamy (sp@cs.dartmouth.edu), Dartmouth College.
%
% Copyright (c), 2000, Trustees of Dartmouth College. All rights reserved.
%

function affbc_init

    clear diffxyt affbc_find

return;
