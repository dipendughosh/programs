%
% function [i1_warped,flowAcc] = register2d(i1_in,i2_in,params)
%
% Date: April 19, 2003
% By  : Senthil Periaswamy (sp@cs.dartmouth.edu)
%
% Copyright (c), 2000, Trustees of Dartmouth College. All rights reserved.
%

function [i1_warped,flowAcc] = register2d(i1_in,i2_in,params)

    % First set default parameters
    if (~exist('params'))
        params = params_default;
    end

    [h,w]         = size(i1_in);

    if (~isfield(params.glob,'numLevels')) % Newly added field
        params.glob.numLevels      = 100;
    end

    i1      = i1_in;
    i2      = i2_in;
    [h,w]   = size(i1);

    %--------------- Padding begin -----------------------------
    newH = nextpow2(h);
    newW = nextpow2(w);

    padHl = floor((newH-h) / 2);
    padHr = newH-h - padHl;

    padWl = floor((newW-w) / 2);
    padWr = newW-w - padWl;
    
    mind   = min(w,h);
    levels = floor(log2(mind/params.main.minSize)+1);

    padWl   = padWl + (params.main.padSize * 2^levels);
    padHl   = padHl + (params.main.padSize * 2^levels);
    padWr   = padWr + (params.main.padSize * 2^levels);
    padHr   = padHr + (params.main.padSize * 2^levels);

    padW = padWl + padWr;
    padH = padHl + padHr;


    i1 = pad2dlr(i1,padWl,padWr,padHl,padHr,0);
    i2 = pad2dlr(i2,padWl,padWr,padHl,padHr,0);

    %--------------- Padding end -----------------------------

    pyr1(1).im   = i1;
    pyr2(1).im   = i2;

    [ht,wt] = size(pyr1(1).im);

    %--------------- Construct pyramid ----------------------
    fprintf('Pyramid level: %g size: %gx%g mse is: %g\n',...
        1,ht,wt,mse(pyr1(1).im,pyr2(1).im ));

    for i = 2:levels

        pyr1(i).im = reduce(pyr1(i-1).im);
        pyr2(i).im = reduce(pyr2(i-1).im);

        [ht,wt] = size(pyr1(i).im);
        fprintf('Pyramid level: %g size: %gx%g mse is: %g\n',...
            i,ht,wt,mse(pyr1(i).im,pyr2(i).im ));
    end
    fprintf('-----\n');
    %--------------- End construct pyramid ------------------


    [hs,ws] = size(pyr1(levels).im);
    flowAcc = flow_init(ws,hs);

    i1_w = pyr1(levels).im;
    for i=levels:-1:1 % (from coarse to fine)

        fprintf('Pyramid level: %g h: %g w: %g mse is: %g\n',...
                    i,size(pyr1(i).im),mse(pyr1(i).im,pyr2(i).im ));

        if (params.glob.flag)
            fprintf('Finding global affine fit\n');
            [flow_glob,M] = aff_find_flow(i1_w,pyr2(i).im, ...
                params.glob.model,params.glob.iters);
            flowAcc    = flow_add(flowAcc,flow_glob);
            flowAcc.m7 = flow_glob.m7;
            flowAcc.m8 = flow_glob.m8;
            fprintf('Done\n');
        end

        % Notes:
        %
        %   flowfind_smooth warps the image by flowAcc
        %   before it finds the flow field.
        %   This takes care of the global warp.
        %   It also accumulates the previous flowAcc.
        %
        %   The flow accumulation is also done in flowfind_smooth
        %   since it is this function that displays intermediate
        %   results.

        if (params.glob.numLevels >= levels-i+1)  % in case we need to stop at a particular level
            flowAcc = flowfind_smooth(pyr1(i).im,pyr2(i).im,params,...
                            flowAcc,i,levels);
        end
            

        if (i ~= 1) %for all but the finest scale
                    %prepare for the next scale
            flowAcc  = flow_reduce(flowAcc,-1);

            if (params.glob.flag)
                i1_w     = flow_warp(pyr1(i-1).im,flowAcc);
            end
        end

    end

    %undo padding
    flowAcc    = flow_undopad(flowAcc,padWl,padWr,padHl,padHr);

    %warp image in the finest scale
    i1_warped = flow_warp(i1_in,flowAcc);

    fprintf('Pyramid level: %g mse is: %g\n',...
            1,mse(i1_warped,i2_in));
    
    ftime = clock;

return;

function [flow_glob,M] = aff_find_flow(i1,i2,model,iters)

    [h,w]        = size(i1);
    [M,b,c]      = affbc_iter(i1,i2,iters,model);
    flow_glob    = flow_aff(M,w,h);
    flow_glob.m7 = ones(h,w) .* c;
    flow_glob.m8 = ones(h,w) .* b;
    M

return;
