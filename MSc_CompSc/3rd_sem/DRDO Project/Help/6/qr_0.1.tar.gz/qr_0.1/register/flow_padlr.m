%
% function flow_out = flow_padlr(flow,padWl,padWr,padHl,padHr)
%
% Date: April 19, 2003
% By  : Senthil Periaswamy (sp@cs.dartmouth.edu)
%
% Copyright (c), 2000, Trustees of Dartmouth College. All rights reserved.
%

function flow_out = flow_padlr(flow,padWl,padWr,padHl,padHr)

    flow_out.m5 = pad2dlr(flow.m5,padWl,padWr,padHl,padHr,0);
    flow_out.m6 = pad2dlr(flow.m6,padWl,padWr,padHl,padHr,0);
    flow_out.m7 = pad2dlr(flow.m7,padWl,padWr,padHl,padHr,1);
    flow_out.m8 = pad2dlr(flow.m8,padWl,padWr,padHl,padHr,0);

return;
