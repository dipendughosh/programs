%
% function [out] = flow_warp(in,flow,mtd,eflag)
%
% Date: April 19, 2003
% By  : Senthil Periaswamy (sp@cs.dartmouth.edu)
%
% Copyright (c), 2000, Trustees of Dartmouth College. All rights reserved.
%

function [out] = flow_warp(in,flow,mtd,eflag)


    if (nargin == 2)
        mtd = 'cubic';
    end

    if (nargin < 4)
        eflag = 0;
    end

    [h,w]   = size(in);
    b       = floor(h/4);

    if (eflag)
        in      = mirror_extend(in,b,b);
    else
        in      = pad(in,b,b);
    end

    flow.m5 = mirror_extend(flow.m5,b,b);
    flow.m6 = mirror_extend(flow.m6,b,b);

    [h,w]   = size(in);

    [mx,my] = meshgridimg(w,h);

    mx2     = mx + flow.m5;
    my2     = my + flow.m6;


    out     = interp2(mx,my,in,mx2,my2,mtd);
    out     = out(b+1:h-b,b+1:w-b);
    out(find(isnan(out))) = 0;

return;
