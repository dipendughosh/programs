%
% function [M,bnew,cnew,W] = affbc_mult(im1,im2,noIters,model,minBlkSize)
%
% Date: April 19, 2003
% By  : Senthil Periaswamy (sp@cs.dartmouth.edu)
%
% Copyright (c), 2000, Trustees of Dartmouth College. All rights reserved.
%

function [M,bnew,cnew] = affbc_mult(im1,im2,noIters,model,minBlkSize);

    if (nargin == 2)
        model  = 4;
        noIters = 50;
        minBlkSize = 32;
    end

    if (nargin < 6)
        minBlkSize = 32;
    end

    [h,w] = size(im1);
    steps = floor(log2(w/minBlkSize)+1);

    %steps = 3;
    pyr1(1).im = im1;
    pyr2(1).im = im2;

    %First build pyramids
    scale = 1;
    for i = 2:steps
        pyr1(i).im = reduce(pyr1(i-1).im);
        pyr2(i).im = reduce(pyr2(i-1).im);
        scale = scale * 2;
    end

    M = eye(3);
    bnew = 0;
    cnew = 1;
    for i = steps:-1:1

        im1S   = pyr1(i).im;
        im2S   = pyr2(i).im;

        fprintf('affbcmult: scale= %g h=%g w=%g\n',scale,size(im1S));

        if (i ~= steps)
            M1 = M;
            M1(1:2,3) = M1(1:2,3)/scale;
            im1S = aff_warp(im1S,M1);
        end

        %dispimg([im1S,im2S]);
        [Mnew,b,c]   = affbc_iter(im1S,im2S,noIters,model);
        cnew = c * cnew;
        bnew = b + bnew;

        Mnew(1:2,3) = Mnew(1:2,3) * scale;
        M     = Mnew * M
        %Mnew
        %M
        scale = scale/2;
    end


return;
