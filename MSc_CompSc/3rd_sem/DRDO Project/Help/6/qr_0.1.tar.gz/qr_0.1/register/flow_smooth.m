%
% function flow=flow_smooth(flow,params)
%
% Date: April 19, 2003
% By  : Senthil Periaswamy (sp@cs.dartmouth.edu)
%
% Copyright (c), 2000, Trustees of Dartmouth College. All rights reserved.
%

function flow=flow_smooth(flow,params)

    persistent index rankE PR KR h w blurr r_blurr sfile iFlag m_avg model;
    global lamda deviant dweight sfilt

    if (isempty(PR))

        fprintf('Smoothness: Initializing\n');

        lamda = params.smooth.lamda;
        deviant = params.smooth.deviant;
        dweight = params.smooth.dweight;
        model   = params.main.model;

        affbc_find_init;


        [h,w]             = size(flow.m1);

        if (h < 64 | w < 64)
            fprintf('flow_smooth: Size < 64 , setting model=2\n');
            model= 2;
        end

        [L,d,index,rankE,iFlag] = smooth_setC(lamda,deviant,dweight,model);
        [M,b,c,r,pt,kt]   = affbc_find_api(flow.f,flow.g,model);

        PR = zeros(h*w,8,8);
        KR = zeros(h*w,8);

        r   = [1:rankE];
        ir  = index(r);

        area = h*w;

        for i=1:area

            p = pt(:,i);

            P = p * p';
            K = p * kt(i);

            C = K +d;
            R = inv(P+L);

            if (iFlag)
                PR(i,ir,ir) = R(r,r);
                KR(i,ir)    = C(r)';
            else
                PR(i,:,:) = R(:,:);
                KR(i,:)    = C(:)';
            end

        end

         m_avg        = zeros(8,h*w);

        sfilt  = [1 4 1;4 0 4;1 4 1];

        for i=1:8
            blurr(i).filt = sfilt .* lamda(i);
        end

        fprintf('Smoothness: Initializing complete\n');
    end

    %r_blurr         = conv2mirr(flow.r,sfilt);
    r_blurr         = c_smoothavg(flow.r,1);
    r_zind          = find(r_blurr == 0);
    r_blurr(r_zind) = 1;

    flow.r          = ones(h,w);
    flow.r(r_zind)  = 0;

    %m_avg(1,:) = reshape(conv2mirr(flow.m1,blurr(1).filt) ./ r_blurr,1,h*w);
    %m_avg(2,:) = reshape(conv2mirr(flow.m2,blurr(2).filt) ./ r_blurr,1,h*w);
    %m_avg(3,:) = reshape(conv2mirr(flow.m3,blurr(3).filt) ./ r_blurr,1,h*w);
    %m_avg(4,:) = reshape(conv2mirr(flow.m4,blurr(4).filt) ./ r_blurr,1,h*w);
    %m_avg(5,:) = reshape(conv2mirr(flow.m5,blurr(5).filt) ./ r_blurr,1,h*w);
    %m_avg(6,:) = reshape(conv2mirr(flow.m6,blurr(6).filt) ./ r_blurr,1,h*w);
    %m_avg(7,:) = reshape(conv2mirr(flow.m7,blurr(7).filt/20),1,h*w);
    %m_avg(8,:) = reshape(conv2mirr(flow.m8,blurr(8).filt/20),1,h*w);

    m_avg(1,:) = reshape(c_smoothavg(flow.m1 , lamda(1)) ./ r_blurr,1,h*w);
    m_avg(2,:) = reshape(c_smoothavg(flow.m2 , lamda(2)) ./ r_blurr,1,h*w);
    m_avg(3,:) = reshape(c_smoothavg(flow.m3 , lamda(3)) ./ r_blurr,1,h*w);
    m_avg(4,:) = reshape(c_smoothavg(flow.m4 , lamda(4)) ./ r_blurr,1,h*w);
    m_avg(5,:) = reshape(c_smoothavg(flow.m5 , lamda(5)) ./ r_blurr,1,h*w);
    m_avg(6,:) = reshape(c_smoothavg(flow.m6 , lamda(6)) ./ r_blurr,1,h*w);
    m_avg(7,:) = reshape(c_smoothavg(flow.m7, lamda(7)/20),1,h*w) ;
    m_avg(8,:) = reshape(c_smoothavg(flow.m8, lamda(8)/20),1,h*w) ;

    KRA = KR + m_avg';


    m = zeros(h*w,8);

    for r = 1:8
        m(:,r) = sum( squeeze(PR(:,r,:)) .* KRA,2);
    end

    flow.m1(:) = m(:,1);
    flow.m2(:) = m(:,2);
    flow.m3(:) = m(:,3);
    flow.m4(:) = m(:,4);
    flow.m5(:) = m(:,5);
    flow.m6(:) = m(:,6);
    flow.m7(:) = m(:,7);
    flow.m8(:) = m(:,8);

    flow.m1(r_zind) = 1;
    flow.m2(r_zind) = 0;
    flow.m3(r_zind) = 0;
    flow.m4(r_zind) = 1;
    flow.m5(r_zind) = 0;
    flow.m6(r_zind) = 0;
    flow.m7(r_zind) = 1;
    flow.m8(r_zind) = 0;

return;

function [L,d,index,rankE,iFlag] = smooth_setC(lamda,deviant,dweight,model)

    [index,afFlag,bcFlag] = getindex(model);
    iFlag   = ~(afFlag & bcFlag);
    
    rankE = length(index);

    L = zeros(rankE,rankE);

    for i = 1:rankE
        ind    = index(i);
        L(i,i) = lamda(ind) + dweight(ind);
        d(i)   = deviant(ind) .* dweight(ind);
    end

    d = d';

return;

