%
% function flowOut = flow_undopad(flowIn,padWl,padWr,padHl,padHr)
%
% Date: April 19, 2003
% By  : Senthil Periaswamy (sp@cs.dartmouth.edu)
%
% Copyright (c), 2000, Trustees of Dartmouth College. All rights reserved.
%

function flowOut = flow_undopad(flowIn,padWl,padWr,padHl,padHr)

    flowOut.m5 = pad2dlr(flowIn.m5,padWl,padWr,padHl,padHr,0,1);
    flowOut.m6 = pad2dlr(flowIn.m6,padWl,padWr,padHl,padHr,0,1);

    if (isfield(flowIn,'m7'))
        flowOut.m7 = pad2dlr(flowIn.m7,padWl,padWr,padHl,padHr,0,1);
        flowOut.m8 = pad2dlr(flowIn.m8,padWl,padWr,padHl,padHr,0,1);
    end

return;

