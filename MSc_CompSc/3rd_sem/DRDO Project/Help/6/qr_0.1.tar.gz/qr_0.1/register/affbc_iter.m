%
% function affbc_iter(i1,i2,iters,model)
%
% Date: April 19, 2003
% By  : Senthil Periaswamy (sp@cs.dartmouth.edu)
%
% Copyright (c), 2000, Trustees of Dartmouth College. All rights reserved.
%

function [M,b,c,W] = affbc_iter(i1,i2,iters,model)

    if (~exist('model','var'))
        model = 4;
    end
    if (~exist('iters','var'))
        iters = 20;
    end

    txtFlag = 0;

    affbc_find_init;
    [h,w]   = size(i1);
    W       = ones(h,w);
    [index] = getindex(model);

    c   = 1;
    b   = 0;
    M   = [1 0 0; 0 1 0; 0 0 1];
    i1N = i1;


    for i=1:iters

        [dM db dc,r] = affbc_find_api(i1N,i2,model);

        M   = M*dM;
        b   = b+db;
        c   = c*dc;

        if (c < 0.1)
            c = 1;
        end

        i1N = aff_warp(i1,M,0);

        if (txtFlag)
            fprintf('Iteration: %d\n',i);
            M
            fprintf('c: %g, b: %g, mse: %g\n', c,b,mse(i1N,i2));
        end

        i1N = i1N .* c + b;


    end

return;

