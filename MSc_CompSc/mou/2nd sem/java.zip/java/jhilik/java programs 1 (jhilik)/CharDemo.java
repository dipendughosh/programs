//CharDemo.java
//Program to demonstrate the working of char

public class CharDemo
{
	public static void main(String args[])
	{
		char ch1='A',ch2=65;
		System.out.println("The charcter ch1 is :"+ch1);
		System.out.println("The charcter ch2 is :"+ch2);
		System.out.println("char variables behave like integers\n");
		ch1++;
		System.out.println("The character now has become :"+ch1);
	}
}
