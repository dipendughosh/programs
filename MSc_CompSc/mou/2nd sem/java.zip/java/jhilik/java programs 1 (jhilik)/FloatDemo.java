//FloatDemo.java
//Working of float

public class FloatDemo
{
	public static void main(String args[])
	{
		double r,pi,area,circumference;
		r=10.8;
		pi=3.14285714;
		area=pi*r*r;
		circumference=2*pi*r;
		System.out.println("The area of the circle is"+area);
		System.out.println("The circumference of the circle is"+circumference);
	}
}