public class PrintDemo
{
	public static void main(String args[])
	{
		System.out.println("I am Swarnali Mukherjee");
		System.out.print("I am doing Msc");
		System.out.printf("I study in BRSNC");
	}
}