//MixedModeArithmetic.java

public class MixedModeArithmetic
{
	public static void main(String args[])
	{
		int x=15,y=10;
		float z=10F;
		System.out.println("Integer Arithmetic x/y = 15/10 produces :"+(x/y));
		System.out.println("Mixed Mode Arithmetic x/z = 15/10 produces :"+(x/z));
	}
}