//Welcome1.java
//Text-Printing Program

public class Welcome1

	{     //main method begins execution of Java application
		
		public static void main(String args[])
		{
			System.out.println("Welcome to Java programming!!");
			System.out.println("having fun???");
		}
	//end of method main
	}	//end of class Welcome1