//To demonstrate all the Float(float,double) types available in JAVA
class flot
{
	public static void main(String args[])
	{
		float a1,a2;
		double b1,b2;
		a1=5e+17f;
		a2=6e+20f;
		System.out.println("FLOAT\na1 = "+a1+"\na2="+a2+"\na1 * a2 = "+a1*a2);
		b1=3e+150;
		b2=4e+157;
		System.out.println("DOUBLE\nb1 = "+b1+"\nb2="+b2+"\nb1 * b2 = "+b1*b2);
	}
}