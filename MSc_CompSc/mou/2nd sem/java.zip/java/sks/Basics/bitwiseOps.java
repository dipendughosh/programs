//Write a program that will use bitwise & operator to perform bitwise AND operation,bitwise | operator to perform bitwise inclusive OR operation ans bitwise ^ operator to perform bitwise exclusive OR operation
class bitwiseOps
{
	public static void main(String argv[])
	{
		int a=13,b=25;
		System.out.println("a = "+a);
		System.out.println("b = "+b);
		System.out.println("(a & b) = "+(a&b));
		System.out.println("(a | b) = "+(a|b));
		System.out.println("(a ^ b) = "+(a^b));
	}
}