//Write a program to demonstrate the working of relational operators and their evaluation as Boolean in JAVA
class relationalOp
{
	public static void main(String args[])
	{
		double a=19e199,b=48e150,c=19e199;
		System.out.println("a = "+a+"\nb = "+b+"\nc = "+c);
		System.out.println("a < b = "+(a<b));
		System.out.println("c > b = "+(c>b));
		System.out.println("a == c = "+(a==c));
		System.out.println("a >= c = "+(a>=c));
		System.out.println("a <= b = "+(a<=b));
		System.out.println("a != c = "+(a!=c));
	}
}