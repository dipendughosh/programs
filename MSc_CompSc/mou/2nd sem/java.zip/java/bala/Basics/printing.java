//Write a program to demonstrate the printing facility provided by JAVA(use of print,printf,println)
class printing
{	public static void main(String args[])
	{
		System.out.println("----------This line is printed using PRINTLN-----------");
		System.out.print("****************This line is printed using PRINT***************");
		System.out.printf("===============This line is printed using PRINTF==============");
		System.out.println("----------This line is printed using 2nd PRINTLN-----------");
	}
}
