//To demonstrate all the Integer(short,int,long,byte) types available in JAVA
class integr
{
	public static void main(String args[])
	{
		int a1,a2;
		long b1,b2;
		short c1,c2;
		byte d1,d2;
		a1=46340;
		a2=46341;
		System.out.println("INT\na1 = "+a1+"\na2="+a2+"\na1 * a2 = "+a1*a2);
		b1=303700049;
		b2=303700050;
		System.out.println("LONG\nb1 = "+b1+"\nb2="+b2+"\nb1 * b2 = "+b1*b2);
		c1=181;
		c2=182;
		System.out.println("SHORT\nc1 = "+c1+"\nc2="+c2+"\nc1 * c2 = "+c1*c2);
		d1=11;
		d2=11;
		System.out.println("BYTE\nd1 = "+d1+"\nd2="+d2+"\nd1 * d2 = "+d1*d2);
	}
}