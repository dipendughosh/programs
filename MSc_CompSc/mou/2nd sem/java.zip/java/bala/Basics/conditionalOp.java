//Write a program to to demonstrate the working of conditional operators in JAVA
class conditionalOp
{
	public static void main(String argv[])
    {
		int a,b;
		a=98786;
		b=756757;
		System.out.println("a = "+a+"\nb = "+b);
		System.out.println("a > b ? (True = a) ? (False = b) :---------> "+(a>b?a:b));	
		System.out.println("a < b ? (True = a) ? (False = b) :---------> "+(a<b?a:b));	
	}
}
