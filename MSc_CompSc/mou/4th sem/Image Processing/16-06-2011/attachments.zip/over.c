// Initialization
#include<stdio.h>
FILE *fptr1,*fptr2,*fptw;

readheader(int *w,int *h)
{
     char bm[2];
     fread(bm,2,1,fptr);
     fwrite(bm,2,1,fptw);

     int filesz;
     fread(&filesz,4,1,fptr);
     fwrite(&filesz,4,1,fptw);
     
     short int creat1;
     fread(&creat1,2,1,fptr);
     fwrite(&creat1,2,1,fptw);
    
     short int creat2;
     fread(&creat2,2,1,fptr);
     fwrite(&creat2,2,1,fptw);
    
     int offset;
     fread(&offset,4,1,fptr);
     fwrite(&offset,4,1,fptw);
    
     int header_sz;
     fread(&header_sz,4,1,fptr);
     fwrite(&header_sz,4,1,fptw);
    
     int hight;
     fread(&hight,4,1,fptr);
     fwrite(&hight,4,1,fptw);
    
     int width;
     fread(&width,4,1,fptr);
     fwrite(&width,4,1,fptw);
    
     short int  clo_plane;
     fread(&clo_plane,2,1,fptr);
     fwrite(&clo_plane,2,1,fptw);
    
     short int bitspp;
     fread(&bitspp,2,1,fptr);
     fwrite(&bitspp,2,1,fptw);
    
     int comp_width;
     fread(&comp_width,4,1,fptr);
     fwrite(&comp_width,4,1,fptw);
    
     int bmp_bytesz;
     fread(&bmp_bytesz,4,1,fptr);
     fwrite(&bmp_bytesz,4,1,fptw);
    
     int hres;
     fread(&hres,4,1,fptr);
     fwrite(&hres,4,1,fptw);
    
     int vres;
     fread(&vres,4,1,fptr);
     fwrite(&vres,4,1,fptw);
    
     int ncol_palette;
     fread(&ncol_palette,4,1,fptr);
     fwrite(&ncol_palette,4,1,fptw);
    
     int mean_col;
     fread(&mean_col,4,1,fptr);
     fwrite(&mean_col,4,1,fptw);
    
     *w=width;
     *h=hight;
      printf("%d,%d\n",width,hight);
}




main()
{	
	char oneb,oneb1,;
	
	
      	long int i,j;
      	int width,hight;
	fptr1=fopen("moon2.bmp","rb"); 
	readheader(&width,&hight);
	//unsigned char data[width][hight][3];
	fptr2=fopen("rmoon2.bmp","rb");
	readheader(&width,&hight);
	fptw=fopen("rmoon3.bmp","wb");
	//array corresponds to the original image
	for(i=0;i<width;i++)
	{
		for(j=0;j<hight;j++)
		{
			fread(&oneb,1,1,fptr1);
			//data[i][j][0]=oneb;
			fread(&oneb,1,1,fptr1);
			//data[i][j][1]=oneb;
			fread(&oneb,1,1,fptr1);
			//data[i][j][2]=oneb;
			fread(&oneb1,1,1,fptr2);
			fread(&oneb1,1,1,fptr2);
			fread(&oneb1,1,1,fptr2);
			if(oneb1==0)
			{
				fwrite(&oneb,1,255,fptw);
				fwrite(&oneb,1,1,fptw);
				fwrite(&oneb,1,1,fptw);
			}
			
		}
	}
}
	/*fclose(fptr);
	fptr=fopen("rmoon2.bmp","rb");
	readheader(&width,&hight);
	unsigned char r[width][hight];
	//array corresponds to the region image
	for(i=0;i<width;i++)
	{
		for(j=0;j<hight;j++)
		{
			fread(&oneb,1,1,fptr);
			fread(&oneb,1,1,fptr);
			fread(&oneb,1,1,fptr);
			if(oneb==0)
				r[i][j]=0;
			else	
				r[i][j]=255;
			
		}
	}
	fclose(fptr);
	fptw=fopen("rmoon3.bmp","wb");
	//overlapping
	for(i=0; i<width;i++)
     {
		for(j=0;j<hight;j++)
		{
			if(r[i][j]==0)
			{
				data[i][j][0]=255;
				data[i][j][1]=255;
				data[i][j][2]=255;	
			}
		}
	}
	for(i=0; i<width; i++)
	{
		for(j=0;j<hight;j++)
		{
			oneb= data[i][j][0];
			fwrite(&oneb,1,1,fptw);
			oneb= data[i][j][1];
			fwrite(&oneb,1,1,fptw);
			oneb= data[i][j][2];
			fwrite(&oneb,1,1,fptw);
		}
	}
	fclose(fptw);
	
}
