package com;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileInputStream;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import sun.audio.AudioData;
import sun.audio.AudioDataStream;
import sun.audio.AudioPlayer;
import sun.audio.AudioStream;
import sun.audio.ContinuousAudioDataStream;

public class AudioTest extends JFrame{
	JCheckBox loopCkb;
	JComboBox fileNameCmb;
	AudioDataStream ads = null;
	
	public void init(){
		setTitle("Audio Test...");
		setSize(350,63);
		setResizable(false);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		
		JPanel msgPanel = new JPanel();
		fileNameCmb = new JComboBox();		
		File audio_dir = new File("audio");
		for(String audio_name : audio_dir.list()){
			fileNameCmb.addItem(audio_name);
		}
		msgPanel.add(new JLabel("File "));
		msgPanel.add(fileNameCmb);
		
		loopCkb = new JCheckBox();
		msgPanel.add(new JLabel("Loop?"));
		msgPanel.add(loopCkb);
		final JButton cBtn = new JButton("Start");
		cBtn.addActionListener(new ActionListener(){

			@Override
			public void actionPerformed(ActionEvent ae) {
				if(ae.getActionCommand().equals("Start")){
					((JButton)ae.getSource()).setText("Stop");
					fileNameCmb.setEnabled(false);
					loopCkb.setEnabled(false);					
					try {						
						AudioStream as = new AudioStream(new FileInputStream("audio\\"+fileNameCmb.getSelectedItem()));						
						AudioData ad = as.getData();						
						if(loopCkb.isSelected()){
							ads= new ContinuousAudioDataStream(ad);
						}else{
							ads = new AudioDataStream(ad);
						}
						AudioPlayer.player.start(ads);																		
					} catch (Exception e) {						
						e.printStackTrace();
					} 
				}else{
					((JButton)ae.getSource()).setText("Start");
					fileNameCmb.setEnabled(true);
					loopCkb.setEnabled(true);					
					AudioPlayer.player.stop(ads);					
				}				
			}
			
		});
		
		msgPanel.add(cBtn);						
		add(msgPanel,BorderLayout.NORTH);						
		setVisible(true);
	}

	public static void main(String[] args) {
		AudioTest frame = new AudioTest();
		frame.init();		
	}

}
