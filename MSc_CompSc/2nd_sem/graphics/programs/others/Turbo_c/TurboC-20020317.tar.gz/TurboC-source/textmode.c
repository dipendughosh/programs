/*
  TurboC, a library for porting Borland Turbo C to GNU gcc.
  Copyright 2002 Ronald S. Burkey
 
  This library is free software; you can redistribute it and/or
  modify it under the terms of the GNU Lesser General Public
  License as published by the Free Software Foundation; either
  version 2.1 of the License, or (at your option) any later version.

  This library is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
  Lesser General Public License for more details.

  You should have received a copy of the GNU Lesser General Public
  License along with this library; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
  
  Contact Ron Burkey at info@birdsproject.org.

  Filename:	textmode.c
  Purpose:	conio.h is emulated using ncurses.  textmode is used to
  		initialize ncurses.  It is not optional as it is in 
		Turbo C.  Also, it must be called at the end of the program,
		as textmode(EXITMODE).
  Mod history:	01/27/02 RSB	Created.
  		03/02/02 RSB	Reordered header files.
		03/16/02 RSB	Now can automatically resize the physical 
				console if the xterm is running.
		03/17/02 RSB	Added initialization of the display-character
				translation table.				
*/

#include <stdlib.h>

#define ORIGINAL_TEXTMODE_C
#include "conio.h"

char BypassResizeXterm = 0;
static uint32_t LastMode = C80;
#define NUM_VIDEO_MODES 65
static struct
{
  int Columns;
  int Rows;
}
VideoModes[NUM_VIDEO_MODES] =
{
  {
  40, 25}
  ,				// BW40
  {
  40, 25}
  ,				// C40
  {
  80, 25}
  ,				// BW80
  {
  80, 25}
  ,				// C80
  {
  80, 25}
  ,				// not used (4).
  {
  80, 25}
  ,				// not used (5);
  {
  80, 25}
  ,				// not used (6);
  {
  80, 25}
  ,				// MONO
  {
  40, 14}
  ,				// C40X14, C40X21, etc.
  {
  40, 21}
  ,
  {
  40, 28}
  ,
  {
  40, 43}
  ,
  {
  40, 50}
  ,
  {
  40, 60}
  ,
  {
  80, 14}
  ,
  {
  80, 21}
  ,
  {
  80, 28}
  ,
  {
  80, 43}
  ,
  {
  80, 50}
  ,
  {
  80, 60}
  ,
  {
  40, 14}
  ,
  {
  40, 21}
  ,
  {
  40, 28}
  ,
  {
  40, 43}
  ,
  {
  40, 50}
  ,
  {
  40, 60}
  ,
  {
  80, 14}
  ,
  {
  80, 21}
  ,
  {
  80, 28}
  ,
  {
  80, 43}
  ,
  {
  80, 50}
  ,
  {
  80, 60}
  ,
  {
  80, 14}
  ,
  {
  80, 21}
  ,
  {
  80, 28}
  ,
  {
  80, 43}
  ,
  {
  80, 50}
  ,
  {
  80, 60}
  ,
  {
  80, 25}
  ,				// not used (38-63)
  {
  80, 25}
  ,
  {
  80, 25}
  ,
  {
  80, 25}
  ,
  {
  80, 25}
  ,
  {
  80, 25}
  ,
  {
  80, 25}
  ,
  {
  80, 25}
  ,
  {
  80, 25}
  ,
  {
  80, 25}
  ,
  {
  80, 25}
  ,
  {
  80, 25}
  ,
  {
  80, 25}
  ,
  {
  80, 25}
  ,
  {
  80, 25}
  ,
  {
  80, 25}
  ,
  {
  80, 25}
  ,
  {
  80, 25}
  ,
  {
  80, 25}
  ,
  {
  80, 25}
  ,
  {
  80, 25}
  ,
  {
  80, 25}
  ,
  {
  80, 25}
  ,
  {
  80, 25}
  ,
  {
  80, 25}
  ,
  {
  80, 25}
  ,
  {
  80, 50}			// C4350 (64)
};

//------------------------------------------------------------------------------------
// Translation table for the displayed characters.  Change DefaultChar prior to the 
// first use of any conio function, or else it won't take effect.

gint DefaultChar = '.';
gint TranslatedChar[256];

// We initialize the translation table via a function rather than through a 
// static intializer because ACS_xxxxx aren't really constants.
static void
InitializeTranslatedChar (void)
{
  int i;
  // Hit most of the characters first with some simple defaults.
  for (i = 0; i < 0x20; i++)
    TranslatedChar[i] = DefaultChar;
  for (; i < 0x7f; i++)
    TranslatedChar[i] = i;
  for (; i <= 0xff; i++)
    TranslatedChar[i] = DefaultChar;
  // Now fix the ones that are different from the simple defaults.
  // Many of these are not exact matches, but they're the best that can be 
  // done under the circumstances.  At least, it should be possible to 
  // make a decent line-drawing, except that all double-lines have been
  // replaced by single-lines.
  TranslatedChar[(int) '\r'] = '\r';
  TranslatedChar[(int) '\n'] = '\n';
  TranslatedChar[0x10] = ACS_RARROW;
  TranslatedChar[0x11] = ACS_LARROW;
  TranslatedChar[0x18] = ACS_UARROW;
  TranslatedChar[0x19] = ACS_DARROW;
  TranslatedChar[0x1a] = ACS_RARROW;
  TranslatedChar[0x1b] = ACS_LARROW;
  TranslatedChar[0x1e] = ACS_UARROW;
  TranslatedChar[0x1f] = ACS_DARROW;
  TranslatedChar[0x04] = ACS_DIAMOND;
  TranslatedChar[0x9c] = ACS_STERLING;
  TranslatedChar[0xb0] = ACS_CKBOARD;
  TranslatedChar[0xb1] = ACS_CKBOARD;
  TranslatedChar[0xb2] = ACS_CKBOARD;
  TranslatedChar[0xb3] = ACS_VLINE;
  TranslatedChar[0xb4] = ACS_RTEE;
  TranslatedChar[0xb5] = ACS_RTEE;
  TranslatedChar[0xb6] = ACS_RTEE;
  TranslatedChar[0xb7] = ACS_URCORNER;
  TranslatedChar[0xb8] = ACS_URCORNER;
  TranslatedChar[0xb9] = ACS_RTEE;
  TranslatedChar[0xba] = ACS_VLINE;
  TranslatedChar[0xbb] = ACS_URCORNER;
  TranslatedChar[0xbc] = ACS_LRCORNER;
  TranslatedChar[0xbd] = ACS_LRCORNER;
  TranslatedChar[0xbe] = ACS_LRCORNER;
  TranslatedChar[0xbf] = ACS_URCORNER;
  TranslatedChar[0xc0] = ACS_LLCORNER;
  TranslatedChar[0xc1] = ACS_BTEE;
  TranslatedChar[0xc2] = ACS_TTEE;
  TranslatedChar[0xc3] = ACS_LTEE;
  TranslatedChar[0xc4] = ACS_HLINE;
  TranslatedChar[0xc5] = ACS_PLUS;
  TranslatedChar[0xc6] = ACS_LTEE;
  TranslatedChar[0xc7] = ACS_LTEE;
  TranslatedChar[0xc8] = ACS_LLCORNER;
  TranslatedChar[0xc9] = ACS_ULCORNER;
  TranslatedChar[0xca] = ACS_BTEE;
  TranslatedChar[0xcb] = ACS_TTEE;
  TranslatedChar[0xcc] = ACS_LTEE;
  TranslatedChar[0xcd] = ACS_HLINE;
  TranslatedChar[0xce] = ACS_PLUS;
  TranslatedChar[0xcf] = ACS_BTEE;
  TranslatedChar[0xd0] = ACS_BTEE;
  TranslatedChar[0xd1] = ACS_TTEE;
  TranslatedChar[0xd2] = ACS_TTEE;
  TranslatedChar[0xd3] = ACS_LLCORNER;
  TranslatedChar[0xd4] = ACS_LLCORNER;
  TranslatedChar[0xd5] = ACS_ULCORNER;
  TranslatedChar[0xd6] = ACS_ULCORNER;
  TranslatedChar[0xd7] = ACS_PLUS;
  TranslatedChar[0xd8] = ACS_PLUS;
  TranslatedChar[0xd9] = ACS_LRCORNER;
  TranslatedChar[0xda] = ACS_ULCORNER;
  TranslatedChar[0xdb] = ACS_CKBOARD;
  TranslatedChar[0xe3] = ACS_PI;
  TranslatedChar[0xf1] = ACS_PLMINUS;
  TranslatedChar[0xf2] = ACS_GEQUAL;
  TranslatedChar[0xf3] = ACS_LEQUAL;
  TranslatedChar[0xf8] = ACS_DEGREE;
  TranslatedChar[0xf9] = ACS_BULLET;
};

//------------------------------------------------------------------------------------

void
textmode (uint32_t newmode)
{
  char s[32];
  int32_t Rows, Columns;
  // Parse the current and desired modes.
  if (ConioInitialized)
    {
      if (CurrentWindow != NULL)
	{
	  if (CurrentWindow != stdscr)
	    delwin (CurrentWindow);
	  CurrentWindow = NULL;
	}
      endwin ();
      // Reset the terminal type.
      //system ("reset");
      ConioInitialized = 0;
    }
  if (newmode == EXITMODE)
    {
      return;
    }
  if (newmode == LASTMODE)
    newmode = LastMode;
  if (0xffff == (newmode & 0xffff))
    {
      Rows = 0xff & (newmode >> 24);
      Columns = 0xff & (newmode >> 16);
    }
  else
    {
      if (newmode < 0 || newmode >= NUM_VIDEO_MODES)
	newmode = C80;
      Rows = VideoModes[newmode].Rows;
      Columns = VideoModes[newmode].Columns;
    }

  if (BypassResizeXterm == 0)
    {
      // The following resizes the physical console, but it only works on
      // xterm (not on KDE Konsole, for example).  If xterm is not being 
      // run it causes a fairly chunky delay until it times out.
      sprintf (s, "resize -s %d %d", Rows, Columns);
      system (s);
    }

  // ncurses initialization.
  //sprintf (s, "LINES=%d", Rows);
  //putenv (s);
  //sprintf (s, "COLUMNS=%d", Columns);
  //putenv (s);
  //use_env (TRUE);
  //system ("tset pcmw");
  initscr ();
  start_color ();
  nodelay (stdscr, TRUE);
  scrollok (stdscr, TRUE);
  // cbreak (); 
  raw ();
  noecho ();
  nonl ();
  intrflush (stdscr, FALSE);
  keypad (stdscr, TRUE);
  wresize (stdscr, Rows, Columns);
  // Initialize the translation table.
  if (TranslatedChar[(int) ' '] == 0)
    InitializeTranslatedChar ();

  // conio initialization.
  CurrentAttributes.currmode = LastMode = newmode;
  CurrentAttributes.winleft = CurrentAttributes.curx = 1;
  CurrentAttributes.winright = CurrentAttributes.screenwidth = Columns;
  CurrentAttributes.wintop = CurrentAttributes.cury = 1;
  CurrentAttributes.winbottom = CurrentAttributes.screenheight = Rows;
  CurrentAttributes.attribute = CurrentAttributes.normattr = WHITE;
  clear ();

  CurrentWindow = stdscr;
  ColorPairsUsed = 1;
  ConioInitialized = 1;
}
