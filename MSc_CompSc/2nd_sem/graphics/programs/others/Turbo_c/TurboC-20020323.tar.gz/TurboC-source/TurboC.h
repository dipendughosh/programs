/*
  TurboC, a library for porting Borland Turbo C to GNU gcc.
  Copyright 2002 Ronald S. Burkey
 
  This library is free software; you can redistribute it and/or
  modify it under the terms of the GNU Lesser General Public
  License as published by the Free Software Foundation; either
  version 2.1 of the License, or (at your option) any later version.

  This library is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
  Lesser General Public License for more details.

  You should have received a copy of the GNU Lesser General Public
  License along with this library; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
  
  Contact Ron Burkey at info@birdsproject.org.

  Filename:	TurboC.h
  Purpose:	TurboC is a useful little kit of stuff that can be used for
  		converting a Borland Turbo C application to a GNU gcc
		console program.  It doesn't do the whole job, but it does
		provide various library functions present in Turbo C but not
		in gcc libraries. 
  Mod history:	01/27/02 RSB	Created.
  		01/31/02 RSB	Continued, defining the conio.h subset used.
		02/03/02 RSB	Split off the conio.h and alloc.h stuff into
				separate headers.
		03/02/02 RSB	Added integer datatype conversions.
				Added random.				
		03/18/02 RSB	Modified for C++.		

  Not that anybody's likely to care, but constants, datatypes, and function
  prototypes have been taken from the Turbo C Reference Guide, version 2.0,
  and not from any Borland source files.  I imagine that I might have been
  able to just abridge conio.h, alloc.h, etc., but in fact I didn't even look
  at them.
*/

#ifndef _INCLUDED_TURBOC_H
#define _INCLUDED_TURBOC_H

// Note that all system headers required by *any* TurboC header (even those
// included *after* this one) need to be included before integer datatypes
// are redefined.
#include <sys/cdefs.h>
#include <ncurses.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <time.h>
#include <fcntl.h>
#include <unistd.h>
#if defined(linux)
#include <endian.h>
#include <stdint.h>
#elif defined(__FreeBSD__)
#include <machine/endian.h>
#include <inttypes.h>
#elif
#error Need header files for endian type and integer datatypes.
#endif
#include <sys/stat.h>		// Needed by dir.h.

//----------------------------------------------------------------------------
// Constants.

#define __libTurboC__

// Integer-type stuff that differs depending on whether the original
// source code was for a 16-bit compiler (default) or 32-bit.
typedef char gchar;
typedef signed char gschar;
typedef unsigned char guchar;
typedef short gshort;
typedef unsigned short gushort;
typedef int gint;
typedef unsigned int guint;
typedef long glong;
typedef unsigned long gulong;

#ifndef DoNotFixIntegers

// Various ctype.h macros are broken by the integer datatype conversions 
// below.  This fixes them.
//#include <ctype.h>
#ifdef isupper
#undef isupper
#define isupper isupperTurbo
#undef islower
#define islower islowerTurbo
#undef isalpha
#define isalpha isalphaTurbo
#undef isdigit
#define isdigit isdigitTurbo
#undef isxdigit
#define isxdigit isxdigitTurbo
#undef isspace
#define isspace isspaceTurbo
#undef isprint
#define isprint isprintTurbo
#undef isgraph
#define isgraph isgraphTurbo
#undef iscntrl
#define iscntrl iscntrlTurbo
#undef ispunct
#define ispunct ispunctTurbo
#undef isalnum
#define isalnum isalnumTurbo
#endif // isupper

// Integer datatype conversions.  This particular choice of macros has the
// happy property of handling the most commonly used integer datatype 
// specifications (except "unsigned char"), while generating a compiler
// error for all other combinations.
#define short int16_t
#define int int16_t
#define unsigned uint16_t
#define long int32_t

#endif // Compiler32

// String functions that have been renamed.
#define strcmpi strcasecmp
#define stricmp strcasecmp
#define strncmpi strncasecmp

// Pointer modifiers that aren't needed.
#define far
#define huge

//----------------------------------------------------------------------------
// Data types.

//----------------------------------------------------------------------------
// Function prototypes.

__BEGIN_DECLS
// From string.h.
extern char *strupr (char *);
extern char *strlwr (char *);
extern int fcloseall (void);

// Wrappers for ctype.h macros.
extern int isupperTurbo (int c);
extern int islowerTurbo (int c);
extern int isalphaTurbo (int c);
extern int isdigitTurbo (int c);
extern int isxdigitTurbo (int c);
extern int isspaceTurbo (int c);
extern int isprintTurbo (int c);
extern int isgraphTurbo (int c);
extern int iscntrlTurbo (int c);
extern int ispunctTurbo (int c);
extern int isalnumTurbo (int c);

#define random(n) randomTurbo(n)
extern int16_t randomTurbo (int16_t num);
extern void randomize (void);

// Endian conversion functions.
extern void FixLittle16 (uint16_t *);
extern void FixLittle32 (uint32_t *);
extern void FixBig16 (uint16_t *);
extern void FixBig32 (uint32_t *);

// Endian file read/write functions.
extern int ReadLittle16 (FILE * fp, uint16_t * Value);
extern int ReadBig16 (FILE * fp, uint16_t * Value);
extern int ReadLittle32 (FILE * fp, uint32_t * Value);
extern int ReadBig32 (FILE * fp, uint32_t * Value);
extern int WriteLittle16 (FILE * fp, uint16_t Value);
extern int WriteBig16 (FILE * fp, uint16_t Value);
extern int WriteLittle32 (FILE * fp, uint32_t Value);
extern int WriteBig32 (FILE * fp, uint32_t Value);

__END_DECLS
//--------------------------------------------------------------------------
// Variables.
#endif // _INCLUDED_TURBO_H
