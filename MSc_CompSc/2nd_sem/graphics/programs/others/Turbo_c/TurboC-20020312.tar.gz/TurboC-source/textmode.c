/*
  TurboC, a library for porting Borland Turbo C to GNU gcc.
  Copyright 2002 Ronald S. Burkey
 
  This library is free software; you can redistribute it and/or
  modify it under the terms of the GNU Lesser General Public
  License as published by the Free Software Foundation; either
  version 2.1 of the License, or (at your option) any later version.

  This library is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
  Lesser General Public License for more details.

  You should have received a copy of the GNU Lesser General Public
  License along with this library; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
  
  Contact Ron Burkey at info@birdsproject.org.

  Filename:	textmode.c
  Purpose:	conio.h is emulated using ncurses.  textmode is used to
  		initialize ncurses.  It is not optional as it is in 
		Turbo C.  Also, it must be called at the end of the program,
		as textmode(EXITMODE).
  Mod history:	01/27/02 RSB	Created.
  		03/02/02 RSB	Reordered header files.
*/

#include <stdlib.h>

#define ORIGINAL_TEXTMODE_C
#include "conio.h"

static uint32_t LastMode = C80;
#define NUM_VIDEO_MODES 65
static struct
{
  int Columns;
  int Rows;
}
VideoModes[NUM_VIDEO_MODES] =
{
  {
  40, 25}
  ,				// BW40
  {
  40, 25}
  ,				// C40
  {
  80, 25}
  ,				// BW80
  {
  80, 25}
  ,				// C80
  {
  80, 25}
  ,				// not used (4).
  {
  80, 25}
  ,				// not used (5);
  {
  80, 25}
  ,				// not used (6);
  {
  80, 25}
  ,				// MONO
  {
  40, 14}
  ,				// C40X14, C40X21, etc.
  {
  40, 21}
  ,
  {
  40, 28}
  ,
  {
  40, 43}
  ,
  {
  40, 50}
  ,
  {
  40, 60}
  ,
  {
  80, 14}
  ,
  {
  80, 21}
  ,
  {
  80, 28}
  ,
  {
  80, 43}
  ,
  {
  80, 50}
  ,
  {
  80, 60}
  ,
  {
  40, 14}
  ,
  {
  40, 21}
  ,
  {
  40, 28}
  ,
  {
  40, 43}
  ,
  {
  40, 50}
  ,
  {
  40, 60}
  ,
  {
  80, 14}
  ,
  {
  80, 21}
  ,
  {
  80, 28}
  ,
  {
  80, 43}
  ,
  {
  80, 50}
  ,
  {
  80, 60}
  ,
  {
  80, 14}
  ,
  {
  80, 21}
  ,
  {
  80, 28}
  ,
  {
  80, 43}
  ,
  {
  80, 50}
  ,
  {
  80, 60}
  ,
  {
  80, 25}
  ,				// not used (38-63)
  {
  80, 25}
  ,
  {
  80, 25}
  ,
  {
  80, 25}
  ,
  {
  80, 25}
  ,
  {
  80, 25}
  ,
  {
  80, 25}
  ,
  {
  80, 25}
  ,
  {
  80, 25}
  ,
  {
  80, 25}
  ,
  {
  80, 25}
  ,
  {
  80, 25}
  ,
  {
  80, 25}
  ,
  {
  80, 25}
  ,
  {
  80, 25}
  ,
  {
  80, 25}
  ,
  {
  80, 25}
  ,
  {
  80, 25}
  ,
  {
  80, 25}
  ,
  {
  80, 25}
  ,
  {
  80, 25}
  ,
  {
  80, 25}
  ,
  {
  80, 25}
  ,
  {
  80, 25}
  ,
  {
  80, 25}
  ,
  {
  80, 25}
  ,
  {
  80, 50}			// C4350 (64)
};

void
textmode (uint32_t newmode)
{
  char s[32];
  int32_t Rows, Columns;
  // Parse the current and desired modes.
  if (ConioInitialized)
    {
      if (CurrentWindow != NULL)
	{
	  if (CurrentWindow != stdscr)
	    delwin (CurrentWindow);
	  CurrentWindow = NULL;
	}
      endwin ();
      ConioInitialized = 0;
    }
  if (newmode == EXITMODE)
    return;
  if (newmode == LASTMODE)
    newmode = LastMode;
  if (0xffff == (newmode & 0xffff))
    {
      Rows = 0xff & (newmode >> 24);
      Columns = 0xff & (newmode >> 16);
    }
  else
    {
      if (newmode < 0 || newmode >= NUM_VIDEO_MODES)
	newmode = C80;
      Rows = VideoModes[newmode].Rows;
      Columns = VideoModes[newmode].Columns;
    }

  // ncurses initialization.
  sprintf (s, "LINES=%d", Rows);
  putenv (s);
  sprintf (s, "COLUMNS=%d", Columns);
  putenv (s);
  use_env (TRUE);
  initscr ();
  start_color ();
  nodelay (stdscr, TRUE);
  scrollok (stdscr, TRUE);
  // cbreak (); 
  raw ();
  noecho ();
  nonl ();
  intrflush (stdscr, FALSE);
  keypad (stdscr, TRUE);
  wresize (stdscr, Rows, Columns);

#if 0
  // ANSI escape sequences to redefine the special keys the same as in MS-DOS.
  addstr ("/x1b109;0;3bp");	// F1
  addstr ("/x1b10a;0;3cp");	// F2
  addstr ("/x1b10b;0;3dp");	// F3
  addstr ("/x1b10c;0;3ep");	// F4
  addstr ("/x1b10d;0;3fp");	// F5
  addstr ("/x1b10e;0;40p");	// F6
  addstr ("/x1b10f;0;41p");	// F7
  addstr ("/x1b110;0;42p");	// F8
  addstr ("/x1b111;0;43p");	// F9
  addstr ("/x1b112;0;44p");	// F10
  addstr ("/x1b14b;0;52p");	// ins
  addstr ("/x1b14a;0;53p");	// del
  addstr ("/x1b16a;0;47p");	// home
  addstr ("/x1b181;0;4fp");	// end
  addstr ("/x1b153;0;49p");	// pgup
  addstr ("/x1b152;0;51p");	// pgdn
  addstr ("/x1b104;0;4bp");	// left
  addstr ("/x1b105;0;4dp");	// right
  addstr ("/x1b103;0;48p");	// up
  addstr ("/x1b102;0;50p");	// down
#endif

  // conio initialization.
  CurrentAttributes.currmode = LastMode = newmode;
  CurrentAttributes.winleft = CurrentAttributes.curx = 1;
  CurrentAttributes.winright = CurrentAttributes.screenwidth = Columns;
  CurrentAttributes.wintop = CurrentAttributes.cury = 1;
  CurrentAttributes.winbottom = CurrentAttributes.screenheight = Rows;
  CurrentAttributes.attribute = CurrentAttributes.normattr = WHITE;
  clear ();

  CurrentWindow = stdscr;
  ColorPairsUsed = 1;
  ConioInitialized = 1;
}
