/*
  TurboC, a library for porting Borland Turbo C to GNU gcc.
  Copyright 2002 Ronald S. Burkey
 
  This library is free software; you can redistribute it and/or
  modify it under the terms of the GNU Lesser General Public
  License as published by the Free Software Foundation; either
  version 2.1 of the License, or (at your option) any later version.

  This library is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
  Lesser General Public License for more details.

  You should have received a copy of the GNU Lesser General Public
  License along with this library; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
  
  Contact Ron Burkey at info@birdsproject.org.

  Filename:	Test.c
  Purpose:	A test program for TurboC.
  Mod history:	01/31/02 RSB	Created.
*/

#ifdef TEST_TURBOC

#include "conio.h"

gint
main (void)
{
  int i, j;
  short sRed, sGreen, sBlue, sFore, sBack;
  textmode (C80X50);
  for (i = 0; i < 50; i++)
    cprintf ("My name is Sam, and this is line #%d.\r\n", i);
  textcolor (LIGHTGREEN);
  gotoxy (10, 10);
  cputs ("Sam I am");
  window (20, 20, 50, 40);
  for (i = 0; i < 21; i++)
    cprintf ("%d:  Hello, chum!\r\n", i);
  window (40, 1, 80, 30);
  textbackground (GREEN);
  clrscr ();
  for (j = 0; j < 16; j++)
    {
      textbackground (j);
      for (i = 0; i < 16; i++)
	{
	  textcolor (i);
	  clreol ();
	  cprintf ("%d,%d: Hello, you evil scumbag from hell!\r\n", j, i);
	}
      //getchar ();  
    }
  window (1, 1, 80, 43);
  textcolor (BLACK);
  textbackground (LIGHTGRAY);
  for (i = 0; i != 'X';)
    {
      i = getchNcurses ();
      if (i != ERR)
	cprintf ("%08X  ", i);
    }
  textmode (EXITMODE);
  return (0);
}

#endif	/* TEST_TURBOC */
