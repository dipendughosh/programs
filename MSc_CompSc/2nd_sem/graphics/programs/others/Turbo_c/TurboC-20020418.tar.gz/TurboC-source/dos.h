/*
  TurboC, a library for porting Borland Turbo C to GNU gcc.
  Copyright 2002 Ronald S. Burkey
 
  This library is free software; you can redistribute it and/or
  modify it under the terms of the GNU Lesser General Public
  License as published by the Free Software Foundation; either
  version 2.1 of the License, or (at your option) any later version.

  This library is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
  Lesser General Public License for more details.

  You should have received a copy of the GNU Lesser General Public
  License along with this library; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
  
  Contact Ron Burkey at info@birdsproject.org.

  Filename:	dos.h
  Purpose:	A header file for TurboC. 
  Mod history:	03/02/02 RSB	Created.
  		03/18/02 RSB	Modified for C++.
		03/19/02 RSB	Added file-attribute constants.
*/

#ifndef _INCLUDED_DOS_H
#define _INCLUDED_DOS_H

#include <sys/cdefs.h>
#include "TurboC.h"

//----------------------------------------------------------------------------
// Constants.

#define FA_RDONLY	0x01	/* Read only attribute */
#define FA_HIDDEN	0x02	/* Hidden file */
#define FA_SYSTEM	0x04	/* System file */
#define FA_LABEL	0x08	/* Volume label */
#define FA_DIREC	0x10	/* Directory */
#define FA_ARCH		0x20	/* Archive */

//----------------------------------------------------------------------------
// Data types.

struct time
{
  uint8_t ti_min;
  uint8_t ti_hour;
  uint8_t ti_hund;
  uint8_t ti_sec;
};

//----------------------------------------------------------------------------
// Function prototypes.

__BEGIN_DECLS extern void gettime (struct time *timep);

__END_DECLS
//--------------------------------------------------------------------------
// Variables.
#endif // _INCLUDED_DOS_H
