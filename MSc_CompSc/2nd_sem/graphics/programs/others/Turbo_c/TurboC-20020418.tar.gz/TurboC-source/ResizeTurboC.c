/*
  TurboC, a library for porting Borland Turbo C to GNU gcc.
  Copyright 2002 Ronald S. Burkey
 
  This library is free software; you can redistribute it and/or
  modify it under the terms of the GNU Lesser General Public
  License as published by the Free Software Foundation; either
  version 2.1 of the License, or (at your option) any later version.

  This library is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
  Lesser General Public License for more details.

  You should have received a copy of the GNU Lesser General Public
  License along with this library; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
  
  Contact Ron Burkey at info@birdsproject.org.

  Filename:	ResizeTurboC.c
  Purpose:	A function to physically resize the text console.
  Mod history:	04/18/02 RSB	Created.
												
*/

#include <stdlib.h>
#include <signal.h>
#include <sys/ioctl.h>
#include "conio.h"

extern char BypassResizeXterm;

//-------------------------------------------------------------------
// This function is activated under various conditions, of which the
// most interesting is if the console is resized.

void
ResizeTurboC (gint Code)
{
  if (BypassResizeXterm)
    {
      // What this code does is essentially just to *accept* the fact
      // that the screen has resized, to adjust the variables that
      // track this as best it can, and to call ConioResizeCallback
      // to allow the user program to redraw the screen (or whatever)
      // as best it can.  This code was written before I figured out
      // how to physically resize the text console effectively, but 
      // it's still a reasonable approach.
      struct winsize winsz;
      ioctl (0, TIOCGWINSZ, &winsz);
      resizeterm (winsz.ws_row, winsz.ws_col);
      CurrentAttributes.screenwidth = COLS;
      CurrentAttributes.screenheight = LINES;
      ConioResizeCallback ();
    }
  else
    {  
      // What this code does is to undo the manual resizing which the
      // user has performed, and to restore the physical terminal
      // size to what textmode has set it at.  Unfortunately, this 
      // only works if the ANSI sequence for resizing the screen works.
      // Fortunately, this works in xterm.
      struct winsize winsz;
      ioctl (0, TIOCGWINSZ, &winsz);
      if (CurrentAttributes.screenwidth != winsz.ws_col || 
	  CurrentAttributes.screenheight != winsz.ws_row)
	{
	  printf ("\033[8;%d;%dt", CurrentAttributes.screenheight, 
		  CurrentAttributes.screenwidth);
	  fflush (stdout);	  
	  redrawwin (stdscr);	       
	  if (stdscr != CurrentWindow)
	    redrawwin (CurrentWindow);
	  wrefresh (stdscr);
	  wrefresh (CurrentWindow);	      
	}
    }
}

