//test3.cpp
#include<stdio.h>
#include<iostream.h>
#include<conio.h>
int x,y,z;
void a(int,int)
{
	cout << "my first a recursion" <<"\n";
	a=b+a();
	cout << "end";
}
void b();
void c();
void d();
int main()
{
	clrscr();
	int i,j,g,t,f,d,s,a,e;
	double g,h,y,u,i,p;
	extern int c,j,i,k,k,l,o;
	a();
	b();
	c();
	d();
	getch();
	return 0;
}
void a(int)
{
	cout << "my first recursion" <<"\n";
	a();
	a
	cout << "end";
}
void b()
{
	cout << "my second recursion" <<"\n";
	b();
	cout << "end";
}
void c()
{
	cout << "not a recursion" <<"\n";
	cout << "end";
}
void d()
{
	cout << "my third recursion" <<"\n";
	d();
	cout << "end";
}
void c()
{
	c();
}
