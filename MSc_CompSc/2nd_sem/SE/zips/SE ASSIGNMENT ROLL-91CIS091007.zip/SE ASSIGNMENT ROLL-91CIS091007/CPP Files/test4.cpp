//test4.cpp
#include<stdio.h>
#include<conio.h>
#include<iostream.h>
int main()
{
	int i=1,j;
	clrscr();
	for(j=1;j<=10;j++)
	{
		while(i!=5)
		{
			cout << "testing";
			i++;
		}
	}
	while(i!=10)
	{
		cout << "testing";
		}
	getch();
	return 0;
}
