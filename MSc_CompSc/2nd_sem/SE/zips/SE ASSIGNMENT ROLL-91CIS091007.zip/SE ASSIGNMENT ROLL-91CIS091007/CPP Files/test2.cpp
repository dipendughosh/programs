//test2.cpp
#include<stdio.h>
#include<conio.h>
int a,b,k;
float p;
void main()
{
int c,d,e,i;
extern int m,n,s;
clrscr();
getch();
}
