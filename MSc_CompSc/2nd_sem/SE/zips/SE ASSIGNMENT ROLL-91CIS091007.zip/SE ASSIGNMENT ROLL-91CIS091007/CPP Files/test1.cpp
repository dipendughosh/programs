//test1.cpp
#include<stdio.h>
#include<conio.h>
void main()
{
int a,b;float c,d;

printf("Helloooooooooooooooooooooooooooooooo\
world");
getch();
}
