

#include<iostream.h>
#include<fstream.h>
#include<string.h>
#include<stdio.h>
#include<conio.h>
class findcount
{
	private:
		ifstream fin;
		int globalVar;
		int externVar;
		int localVar;
		int stop;
	public:
		findcount()
		{
			globalVar = 0;
			externVar = 0;
			localVar = 0;
			stop=0;
		}

		void openFiles();
		void readwrite();
		void closeFiles();
		void check(char [],int,int);
		void output();

		~findcount()
		{
		}
};

void findcount::openFiles()
{
	fin.open("test6.cpp",ios::in);
}

void findcount::readwrite()
{
	int len = 0;
	char str[200];
	int i;

	cout<<"input file test6.cpp\n";

	while(fin)
	{
		fin.getline(str,200);
		len=strlen(str);

		i=0;
		for(i;i<len;i++)
		{
			if(str[i]=='\t' || str[i]==' ')
				continue;
			else
				break;
		}

		if(i<len && len!=0)
		{
			if(str[i]=='i' || str[i]=='c' || str[i]=='d' || str[i]=='f' || str[i]=='v' || str[i]=='b' || str[i]=='e')
			{
				check(str,len,i);
			}
		}
		if(str[i]=='{')
			stop++;
		if(str[i]=='}')
			stop--;
	}


}

void findcount::closeFiles()
{
	fin.close();
}

void findcount::check(char temp[],int len,int i)
{
	int flag1=0;
	int cma;
	int j;

	if(temp[i]=='i' && temp[++i]=='n' && temp[++i]=='t' && temp[++i]==' ' && temp[len-2]!=')' && temp[len-1]!=')')
		flag1 =1;
	else if(temp[i]=='c' && temp[++i]=='h' && temp[++i]=='a' && temp[++i]=='r' && temp[++i]==' ' && temp[len-2]!=')' && temp[len-1]!=')')
		flag1 =1;
	else if(temp[i]=='v' && temp[++i]=='o' && temp[++i]=='i' && temp[++i]=='d' && temp[++i]==' ' && temp[len-2]!=')' && temp[len-1]!=')')
		flag1 =1;
	else if(temp[i]=='b' && temp[++i]=='o' && temp[++i]=='o' && temp[++i]=='l' && temp[++i]==' ' && temp[len-2]!=')' && temp[len-1]!=')')
		flag1 =1;
	else if(temp[i]=='f' && temp[++i]=='l' && temp[++i]=='o' && temp[++i]=='a' && temp[++i]=='t' && temp[++i]==' ' && temp[len-2]!=')' && temp[len-1]!=')')
		flag1 =1;
	else if(temp[i]=='d' && temp[++i]=='o' && temp[++i]=='u' && temp[++i]=='b' && temp[++i]=='l' && temp[++i]=='e' && temp[++i]==' ' && temp[len-2]!=')' && temp[len-1]!=')')
		flag1 =1;
	else flag1=0;

	if(flag1==1)
	{
		cma=0;
		for(j=i;j<len;j++)
		{
			if(temp[j]==',')
				cma++;
		}
		if(stop>0)
		{
			localVar++;
			localVar+=cma;
		}
		else
		{
			globalVar++;
			globalVar+=cma;
		}
	}
	else
	{
		if(temp[i]=='e' && temp[++i]=='x' && temp[++i]=='t' && temp[++i]=='e' && temp[++i]=='r' && temp[++i]=='n' && temp[++i]==' ')
		{
			cma=0;
			for(j=i;j<len;j++)
			{
				if(temp[j]==',')
				cma++;
			}
			externVar++;
			externVar+=cma;
		}
	}
}

void findcount::output()
{
	cout<<"\nNumber of Global variables :- "<<globalVar;
	cout<<"\nNumber of Local variables :- "<<localVar;
	cout<<"\nNumber of Extern variables :- "<<externVar;
	cout<<"\n";
}

void main()
{
	clrscr();
	findcount ob;
	ob.openFiles();
	ob.readwrite();
	ob.closeFiles();
	ob.output();
}
