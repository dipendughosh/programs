#include<iostream.h>
#include<fstream.h>
#include<string.h>
#include<stdio.h>
#include<conio.h>


class findrec
{
	private:
		ifstream fin;
		int counter;
		char func[100][100];
		int ind[100];
		int top;
		int stop;
	public:
		findrec()
		{
			counter = 0;
			top=0;
			stop=0;
			for(int i = 0;i<100;i++)
			{
				func[i][0]='\0';
				ind[i]=0;
			}
		}

		void openFiles();
		void readwrite();
		void closeFiles();
		int check(char [],int,int);
		int count(char [],int,int);
		void output();

		~findrec()
		{
		}
};

void findrec::openFiles()
{
	fin.open("rec.cpp",ios::in);
}

void findrec::readwrite()
{
	int len = 0;
	char str[200];
	int i,x;

	cout<<"input file rec.cpp\n";

	while(fin)
	{
		fin.getline(str,200);
		len=strlen(str);
		
		i=0;
		for(i;i<len;i++)
		{
			if(str[i]=='\t' || str[i]==' ')
				continue;
			else
				break;
		}

		if(i<len && len!=0)
		{
			if(str[i]=='i' || str[i]=='c' || str[i]=='d' || str[i]=='f' || str[i]=='v' || str[i]=='b')
			{
				x=check(str,len,i);
				if(x==1)
				{
					str[0]='\0';
				}
				else if(x==0)
				{
					counter+=count(str,len,i);
				}
			}
			else if(str[i]=='{')
				stop++;
			else if(str[i]=='}')
				stop--;
			else
			{
				counter+=count(str,len,i);
			}
		}
	}

}

int findrec::check(char temp[],int len,int i)
{
	int flag1 =0;
	int j,c,f1,t;

	if(temp[i]=='i' && temp[++i]=='n' && temp[++i]=='t' && temp[++i]==' ')
		flag1 =1;
	else if(temp[i]=='c' && temp[++i]=='h' && temp[++i]=='a' && temp[++i]=='r' && temp[++i]==' ')
		flag1 =1;
	else if(temp[i]=='v' && temp[++i]=='o' && temp[++i]=='i' && temp[++i]=='d' && temp[++i]==' ')
		flag1 =1;
	else if(temp[i]=='b' && temp[++i]=='o' && temp[++i]=='o' && temp[++i]=='l' && temp[++i]==' ')
		flag1 =1;
	else if(temp[i]=='f' && temp[++i]=='l' && temp[++i]=='o' && temp[++i]=='a' && temp[++i]=='t' && temp[++i]==' ')
		flag1 =1;
	else if(temp[i]=='d' && temp[++i]=='o' && temp[++i]=='u' && temp[++i]=='b' && temp[++i]=='l' && temp[++i]=='e' && temp[++i]==' ')
		flag1 =1;
	else flag1=0;

	if(flag1==1)
	{
		c=0;
		f1=0;

		if(temp[len-1] != ';')
		{
			for(j=i;j<len;j++)
			{
				if(temp[j]=='(' && c<=2)
				{
					t=j;
					c++;
					f1=1;
				}
				else if(temp[j]==')' && f1==1)
				{
					c++;
					f1=0;
				}
			}

			if(c==2)
			{
				j=0;
				top++;
				while(temp[i]!='(')
					func[top][j++]=temp[i++];
				func[top][j]='\0';
			}
		}
		else
			flag1=0;
	}

	return(flag1);
}

int findrec::count(char temp[],int len,int i)
{
	int j,k,flag=0,len1;

	if(stop>0)
	{
		len1=strlen(func[top]);
		for(j=i;j<len;j++)
		{
			flag=0;
			k=1;
			if(temp[j]==func[top][k] && ((temp[j-1]<'a' || temp[j-1]>'z') && (temp[j-1]<'A' || temp[j-1]>'Z') && (temp[j-1]!=' ' || temp[j-1]!='\t')))
			{
				for(k;k<len1;k++)
				{
					if(temp[j]==func[top][k])
					{
						flag=1;
						j++;
						if(j>len)
							return(0);
					}
					else
					{
						flag=0;
						break;
					}
				}
			}
			if(flag==1)
			{
				if(temp[j]=='(')
				{
					top=0;
					break;
				}
				else
					flag=0;
			}
		}
	}

	return(flag);
}

void findrec::closeFiles()
{
	fin.close();
}

void findrec::output()
{
	cout<<"Number of Recursion functions are :- "<<counter<<"\n";
}

void main()
{
	clrscr();
	findrec ob;
	ob.openFiles();
	ob.readwrite();
	ob.closeFiles();
	ob.output();
}
