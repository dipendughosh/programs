

#include<iostream.h>
#include<fstream.h>
#include<string.h>
#include<conio.h>
#include<stdio.h>



class indentation
{
	private:
		ifstream fin;
		int stk[200],sp;
		int flag;
	public:
		indentation()
		{
			sp=0;
		}

		void openFiles();
		void readwrite();
		void closeFiles();
		void output();

		~indentation()
		{
		}
};

void indentation::openFiles()
{
	fin.open("indent.cpp",ios::in);
}

void indentation::readwrite()
{
	int i;
	int len = 0;
	int index;
	char str[200];


	cout<<"input file indent.cpp"<<endl;
	while(fin)
	{
		fin.getline(str,200);
		len=strlen(str);

		index=0;
		for(i=0;i<len;i++)
		{
			index++;
			if(str[i]=='{')
			{
				stk[sp++]=index;
			}

			else if(str[i]=='}')
			{
				if(stk[sp-1]==index)
				{
					sp--;
					flag=1;
				}
				else
				{
					flag=0;
					return;

				}
			}
		}
	}


}

void indentation::closeFiles()
{
	fin.close();
}

void indentation::output()
{
	if(flag == 0)
		cout<<"\nNot properly Indented\n";
	else
		cout<<"\nProperly Indented\n";
}

void main()
{
	clrscr();
	indentation ob;
	ob.openFiles();
	ob.readwrite();
	ob.closeFiles();
	ob.output();
}
