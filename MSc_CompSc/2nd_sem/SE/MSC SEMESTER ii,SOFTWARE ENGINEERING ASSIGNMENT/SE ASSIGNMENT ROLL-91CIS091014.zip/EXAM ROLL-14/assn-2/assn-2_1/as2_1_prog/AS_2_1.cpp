#include<iostream.h>
#include<fstream.h>
#include<math.h>
#include<string.h>
#include<conio.h>
#include<stdio.h>
#define true 1


class PGMBtoPGMA
{
	private:

		FILE *fin,*fout;
	public:
		PGMBtoPGMA()
		{
		}

		void openFiles();
		void readwrite();
		void closeFiles();
		int convert(char []);

		~PGMBtoPGMA()
		{
		}
};

void PGMBtoPGMA::openFiles()
{

	fin=fopen("C:\\images\\image1.pgm","rb");
	fout=fopen("C:\\images\\image1_ascii.pgm","w");
}

void PGMBtoPGMA::readwrite()
{
	int i = 0;
	int j = 0;
	int charCntr = 0;
	char s[2];
	char c[10];
	char h[10],w[10];
	char intn[10];
	int ht,wt,it;



	while(true)
	{
		fscanf(fin,"%s\n",c);
		if(c[0]!='#' && c[0]!=' ')
			break;
	}

	while(true)
	{
		fscanf(fin,"%s",h);
		if(h[0]!='#' && h[0]!=' ')
			break;
	}
	ht=convert(h);

	while(true)
	{
		fscanf(fin,"%s\n",w);
		if(w[0]!='#' && w[0]!=' ')
			break;
	}
	wt=convert(w);

	while(true)
	{
		fscanf(fin,"%s\n",intn);
		if(intn[0]!='#' && intn[0]!=' ')
			break;
	}
	it=convert(intn);

	fprintf(fout,"%s\n%s %s\n%s\n","P2",h,w,intn);

	for(i=0;i<ht;i++)
	{
		for(j=0;j<wt;j++)
		{
			fgets(s,2,fin);

			if(s=="\n")
			{
				fgets(s,2,fin);
			}
			charCntr++;

			if(charCntr > 16)
			{
				fprintf(fout,"%s","\n");
				charCntr=0;
			}
			if((int)s == 10 || (int)s == 32)
			{
				fputs(s,fout);
			}
			else
			{
				if((int)s[0]<0)
				{
					fprintf(fout,"%d ",(int)s[0]+it+1);
				}
				else
				{
					fprintf(fout,"%d ",(int)s[0]);
				}
			}
		}
	}

	cout<<"ascii image format created in same location as given\n";
}

int PGMBtoPGMA::convert(char temp[])
{
	int len,i,n=0,b,x=0,c;

	len=strlen(temp);

	for(i=(len-1);i>=0;i--)
	{
		b=temp[i];
		b=b-48;
		c=(pow(10,x))*b;
		n=n+c;
		x++;
	}
	return(n);
}

void PGMBtoPGMA::closeFiles()
{
	fclose(fin);
	fclose(fout);
}

void main()
{
	clrscr();
	PGMBtoPGMA ob;
	ob.openFiles();
	ob.readwrite();

	ob.closeFiles();
}
