/**
 * This sample code is made available as part of the book "Digital Image
 * Processing - An Algorithmic Introduction using Java" by Wilhelm Burger
 * and Mark J. Burge, Copyright (C) 2005-2008 Springer-Verlag Berlin, 
 * Heidelberg, New York.
 * Note that this code comes with absolutely no warranty of any kind.
 * See http://www.imagingbook.com for details and licensing conditions.
 * 
 * Date: 2010/01/27
 */

import ij.IJ;
import ij.ImagePlus;
import ij.gui.GenericDialog;
import ij.plugin.filter.PlugInFilter;
import ij.process.ImageProcessor;
import morphology.BinMorpher;
import morphology.BinMorpherDisk;
import morphology.BinMorpher.Operation;

/** This plugin implements a binary morphology filter using a disk-shaped
 * structuring element whose radius can be specified.
 * Version 2 (requires Java 5)
*/


public class Filter_BinMorph_Disk implements PlugInFilter {
	
	static double  radius = 1.0;
	static boolean showfilter = false;
	static String  opstring = null;
	

	public int setup(String arg, ImagePlus imp) {
		if (arg.equals("about")) {
			showAbout();
			return DONE;
		}
		return DOES_8G;
	}

	public void run(ImageProcessor orig) {
		if (showDialog()) { //sets RADIUS and OPSTRING			
			BinMorpher m = new BinMorpherDisk(radius);
			Operation op = Operation.valueOf(opstring);
			m.apply(orig,op);
			if (showfilter)
				m.showFilter();
		}
	}

	void showAbout() {
		String cn = getClass().getName();
		IJ.showMessage("About "+cn+" ...",
			"Binary dilation for arbitrary structuring elements."
		);
	}
    
    
	boolean showDialog() {
		GenericDialog gd = new GenericDialog("Structuring Element (Disk)");
		gd.addNumericField("Radius", 1.0, 1, 5,"pixels");
		String[] ops = BinMorpher.getOpNames();
		gd.addChoice("Operation", ops, ops[0]);
		gd.addCheckbox("Display filter", false);
		
		gd.showDialog();
		if (gd.wasCanceled()) 
			return false;
		else {
			radius = gd.getNextNumber();
			showfilter = gd.getNextBoolean();
			opstring = gd.getNextChoice();
			return true;
		}
	}

}




