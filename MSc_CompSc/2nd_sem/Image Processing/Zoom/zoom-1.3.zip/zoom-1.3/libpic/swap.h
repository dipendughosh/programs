#if !defined(SWAP_H)
#define SWAP_H

extern void swap_long(void *p);
extern void swap_short(void *p);

#endif
