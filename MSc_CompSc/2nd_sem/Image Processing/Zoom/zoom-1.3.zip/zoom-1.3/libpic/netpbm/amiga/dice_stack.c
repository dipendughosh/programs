long _stack_fudge = 16*1024;
long _stack_chunk = 32*1024;

