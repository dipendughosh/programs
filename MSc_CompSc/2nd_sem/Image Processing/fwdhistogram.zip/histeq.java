



import java.awt.*;
import java.awt.image.BufferStrategy;
import java.awt.image.BufferedImage;
import java.awt.Toolkit;

import javax.swing.*;


public class histeq extends JFrame{
	
	
	private GraphicsDevice myDevice;
	BufferedImage bimage;
	int[] frequency=new int[256];
	int[] eqfrequency=new int[256];
	BufferedImage outimage;
	
	
	public static void main(String[] args) 
    {	
		histeq myWindow = new histeq();
		myWindow.setFont(new Font("Dialog", Font.PLAIN, 30));
	       myWindow.run();
    }
	
	
 public void  run()
 {
	 
	setSize(1100, 720);
	
	 setVisible(true);
	 
    
     
 }
 public void paint(Graphics g)
 {
	 g.setColor( Color.gray );
     g.fillRect( 0, 0, 1100, 720 );

	
   ClassLoader cl = this.getClass().getClassLoader(); 
     Image oldImage= new ImageIcon( cl.getResource("images/face.gif") ).getImage(); 
     histogram(oldImage);
     g.setColor(Color.CYAN);
    
     g.drawString("After Histogram Equalization",350,70);
     histogram(oldImage);
     
     g.drawImage(outimage,350,100,null);
     
     
     //draw the histogram
    int k=20;
     
	 for(int i=0;i<=255;i++)
	 {
		 g.fillRect(k ,550-eqfrequency[i]/5 , 2, eqfrequency[i]/5);
     		 k+=4;
	 }	
	 
	 
	 //draw the axis
	 g.setColor(Color.WHITE);
	 g.drawLine(15,560, k-4, 560); //x axis
	 g.drawLine(15,560, 15, 400);  // y axis
     
 }
 
public void histogram(Image img) {
	    
	 int k=0,i,j;
	 
	//converting Image  img in Buffered type Image
	 
	 bimage = new BufferedImage(img.getWidth(null), img.getHeight(null), BufferedImage.TYPE_BYTE_GRAY);
	 Graphics g = bimage.createGraphics(); // Paint the image onto the buffered image 
	 g.drawImage(img, 0, 0, null);
	 g.dispose(); 
	 
	 
	
	 
	 
	 int width = bimage.getWidth(null); 
	 int height = bimage.getHeight(null); 
	 
	
	 
	
	 
	 
	 // create the output image
	 
	 outimage = new BufferedImage(width, height, BufferedImage.TYPE_BYTE_GRAY);
	 
	 
	 
	 
	 // initially all h value counters are set to zero
	
	 for(i=0;i<=255;i++)
		 frequency[i]=0;
	 
	// get the intensity values of the histogram image 
	 for(int  x=0; x<width; x++)
	 {
			for( int y=0; y<height; y++)
			{
				double[] pixel = new double[1];
				
				pixel= bimage.getRaster().getPixel(x, y, pixel);
				frequency[(int)pixel[0]]++;

			}
	 }
	 
	 
	 //doing histogram equalization
		
	 int sum = 0;
		for(int x = 0; x < frequency.length; x++)
		{
			sum += frequency[x];
			eqfrequency[x] = sum * 255 /(bimage.getWidth() * bimage.getHeight());
		}
		
		// create the new image with the uniform intensity values
		for(int x = 0; x < width; x++)
		{
			for(int y = 0; y < height; y++)
			{
				double[] pixel = new double[1];
				pixel = bimage.getRaster().getPixel(x,y,pixel);
				pixel[0] = eqfrequency[(int)pixel[0]];
				outimage.getRaster().setPixel(x, y, pixel);
			}
		}
	 //print the intensity values
	 for(i=0;i<=255;i++)
		 System.out.println(""+i+"    "+eqfrequency[i]);
	 
	 
	

	}
}

