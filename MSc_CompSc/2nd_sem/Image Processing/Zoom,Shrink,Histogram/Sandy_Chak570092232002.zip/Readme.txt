Hi,
 The file named "ShwBmpHs.c" has the code for the complete program.

 I have also added a few sample images with the package.

 I compiled the program using Turbo C++ ver 3.0, so I don't thing that you would have any problems with compiling & running the program. (Mind it that this program will NOT compile in UNIX/Linux, since I've used the DOS specific dos.h file here).

 Once running, you can specify the filename (image file to be opened) with relative or full path information. The image will be shown after scaling it down to the size of the screen (320x200). 

 You can zoom in/out of the image by pressing the numpad +/- keys.

 A few of the images that I have attached (eg, 51.bmp, logo.bmp) are very low in contrast. You can press the 'h' key (once u get the image on screen) to perform Histogram Equalization on the image to improve its contrast. 

 The program will then first show you the histogram of the original file. Then, it will show u the file with Histogram Eqalization applied to it. After that, it will show u the histogram of the processed file.

 Hope that you will like the program (I have added a LOT of comment entries in the code). If u have any problems or queries or suggestions please mail me at saars@vsnl.in, I'll be happy to reply to your mail.

 Have Fun & EnJoy life...........

 Sandy