Title: Image Histogram Processing
Description: This is another project I have done last month. The programme can load several image format (derived from my project of Digital Image Compression Algorithm) then it can compute 1-D histogram of the image (grey, red, green, blue channel). I also developed some simple functions e.g histogram equalisation, contrast stretch, negative, channel boost.
I hope you can find it interesting and helpful.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=4645&lngWId=2

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
