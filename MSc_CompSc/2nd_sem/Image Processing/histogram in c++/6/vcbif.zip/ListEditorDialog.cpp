#include "StdAfx.h"
#include "ListEditorDialog.h"

