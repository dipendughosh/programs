/*	PICOptionsDialog.h				6-26-2008
	This is part of the VCBif project.
	Copyright (C)2008 Steven Whitney.
	Initially published by http://25yearsofprogramming.com.
	Published under GNU GPL (General Public License) Version 3, with ABSOLUTELY NO WARRANTY.

Dialog box for setting the options when loading a .PIC file in 3D mode.

This is not yet used by the project.
	
*/
#pragma once

using namespace System;
using namespace System::ComponentModel;
using namespace System::Collections;
using namespace System::Windows::Forms;
using namespace System::Data;
using namespace System::Drawing;


namespace VCBif {

	/// <summary>
	/// Summary for PICOptionsDialog
	///
	/// WARNING: If you change the name of this class, you will need to change the
	///          'Resource File Name' property for the managed resource compiler tool
	///          associated with all .resx files this class depends on.  Otherwise,
	///          the designers will not be able to interact properly with localized
	///          resources associated with this form.
	/// </summary>
	public ref class PICOptionsDialog : public System::Windows::Forms::Form
	{
	public:
		PICOptionsDialog(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~PICOptionsDialog()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::GroupBox^  groupBox1;
	private: System::Windows::Forms::RadioButton^  areanear;
	private: System::Windows::Forms::RadioButton^  areaheight;
	private: System::Windows::Forms::RadioButton^  ovlines;
	private: System::Windows::Forms::RadioButton^  drawlines;
	private: System::Windows::Forms::RadioButton^  ovpts;
	private: System::Windows::Forms::RadioButton^  drawpts;
	private: System::Windows::Forms::RadioButton^  overhead;
	private: System::Windows::Forms::TextBox^  IniSkip;
	private: System::Windows::Forms::Label^  label1;
	private: System::Windows::Forms::Label^  label2;
	private: System::Windows::Forms::TextBox^  Skip;
	private: System::Windows::Forms::Label^  label3;
	private: System::Windows::Forms::TextBox^  VertSize;
	private: System::Windows::Forms::Label^  label4;
	private: System::Windows::Forms::Label^  label5;
	private: System::Windows::Forms::Label^  label6;
	private: System::Windows::Forms::Button^  OKbutton;
	private: System::Windows::Forms::Button^  CancelButton;
	private: System::Windows::Forms::Button^  HelpButton;


	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->groupBox1 = (gcnew System::Windows::Forms::GroupBox());
			this->overhead = (gcnew System::Windows::Forms::RadioButton());
			this->drawpts = (gcnew System::Windows::Forms::RadioButton());
			this->ovpts = (gcnew System::Windows::Forms::RadioButton());
			this->drawlines = (gcnew System::Windows::Forms::RadioButton());
			this->ovlines = (gcnew System::Windows::Forms::RadioButton());
			this->areaheight = (gcnew System::Windows::Forms::RadioButton());
			this->areanear = (gcnew System::Windows::Forms::RadioButton());
			this->IniSkip = (gcnew System::Windows::Forms::TextBox());
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->Skip = (gcnew System::Windows::Forms::TextBox());
			this->label3 = (gcnew System::Windows::Forms::Label());
			this->VertSize = (gcnew System::Windows::Forms::TextBox());
			this->label4 = (gcnew System::Windows::Forms::Label());
			this->label5 = (gcnew System::Windows::Forms::Label());
			this->label6 = (gcnew System::Windows::Forms::Label());
			this->OKbutton = (gcnew System::Windows::Forms::Button());
			this->CancelButton = (gcnew System::Windows::Forms::Button());
			this->HelpButton = (gcnew System::Windows::Forms::Button());
			this->groupBox1->SuspendLayout();
			this->SuspendLayout();
			// 
			// groupBox1
			// 
			this->groupBox1->Controls->Add(this->areanear);
			this->groupBox1->Controls->Add(this->areaheight);
			this->groupBox1->Controls->Add(this->ovlines);
			this->groupBox1->Controls->Add(this->drawlines);
			this->groupBox1->Controls->Add(this->ovpts);
			this->groupBox1->Controls->Add(this->drawpts);
			this->groupBox1->Controls->Add(this->overhead);
			this->groupBox1->Location = System::Drawing::Point(12, 12);
			this->groupBox1->Name = L"groupBox1";
			this->groupBox1->Size = System::Drawing::Size(393, 187);
			this->groupBox1->TabIndex = 0;
			this->groupBox1->TabStop = false;
			this->groupBox1->Text = L"Drawing Method:";
			// 
			// overhead
			// 
			this->overhead->AutoSize = true;
			this->overhead->Checked = true;
			this->overhead->Location = System::Drawing::Point(3, 16);
			this->overhead->Name = L"overhead";
			this->overhead->Size = System::Drawing::Size(151, 17);
			this->overhead->TabIndex = 0;
			this->overhead->TabStop = true;
			this->overhead->Text = L"&0  Overhead view (Normal)";
			this->overhead->UseVisualStyleBackColor = true;
			// 
			// drawpts
			// 
			this->drawpts->AutoSize = true;
			this->drawpts->Location = System::Drawing::Point(3, 39);
			this->drawpts->Name = L"drawpts";
			this->drawpts->Size = System::Drawing::Size(194, 17);
			this->drawpts->TabIndex = 1;
			this->drawpts->Text = L"&1  Draw points, erase between plots";
			this->drawpts->UseVisualStyleBackColor = true;
			// 
			// ovpts
			// 
			this->ovpts->AutoSize = true;
			this->ovpts->Location = System::Drawing::Point(3, 62);
			this->ovpts->Name = L"ovpts";
			this->ovpts->Size = System::Drawing::Size(154, 17);
			this->ovpts->TabIndex = 2;
			this->ovpts->Text = L"&2  Overlay points (no erase)";
			this->ovpts->UseVisualStyleBackColor = true;
			// 
			// drawlines
			// 
			this->drawlines->AutoSize = true;
			this->drawlines->Location = System::Drawing::Point(3, 85);
			this->drawlines->Name = L"drawlines";
			this->drawlines->Size = System::Drawing::Size(187, 17);
			this->drawlines->TabIndex = 3;
			this->drawlines->Text = L"&3  Draw lines, erase between plots";
			this->drawlines->UseVisualStyleBackColor = true;
			// 
			// ovlines
			// 
			this->ovlines->AutoSize = true;
			this->ovlines->Location = System::Drawing::Point(3, 108);
			this->ovlines->Name = L"ovlines";
			this->ovlines->Size = System::Drawing::Size(147, 17);
			this->ovlines->TabIndex = 4;
			this->ovlines->Text = L"&4  Overlay lines (no erase)";
			this->ovlines->UseVisualStyleBackColor = true;
			// 
			// areaheight
			// 
			this->areaheight->AutoSize = true;
			this->areaheight->Location = System::Drawing::Point(3, 131);
			this->areaheight->Name = L"areaheight";
			this->areaheight->Size = System::Drawing::Size(216, 17);
			this->areaheight->TabIndex = 5;
			this->areaheight->Text = L"&5  Fill area below curves, colors = Height";
			this->areaheight->UseVisualStyleBackColor = true;
			// 
			// areanear
			// 
			this->areanear->AutoSize = true;
			this->areanear->Location = System::Drawing::Point(3, 154);
			this->areanear->Name = L"areanear";
			this->areanear->Size = System::Drawing::Size(230, 17);
			this->areanear->TabIndex = 6;
			this->areanear->Text = L"&6  Fill area below curves, colors = Nearness";
			this->areanear->UseVisualStyleBackColor = true;
			// 
			// IniSkip
			// 
			this->IniSkip->Location = System::Drawing::Point(205, 216);
			this->IniSkip->Name = L"IniSkip";
			this->IniSkip->Size = System::Drawing::Size(100, 20);
			this->IniSkip->TabIndex = 2;
			this->IniSkip->Text = L"0";
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Location = System::Drawing::Point(12, 220);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(187, 13);
			this->label1->TabIndex = 1;
			this->label1->Text = L"&INITIAL file lines to ignore (not drawn):";
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Location = System::Drawing::Point(15, 258);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(168, 13);
			this->label2->TabIndex = 4;
			this->label2->Text = L"&Skip lines BETWEEN drawn lines:";
			// 
			// Skip
			// 
			this->Skip->Location = System::Drawing::Point(205, 254);
			this->Skip->Name = L"Skip";
			this->Skip->Size = System::Drawing::Size(100, 20);
			this->Skip->TabIndex = 5;
			this->Skip->Text = L"0";
			// 
			// label3
			// 
			this->label3->AutoSize = true;
			this->label3->Location = System::Drawing::Point(12, 299);
			this->label3->Name = L"label3";
			this->label3->Size = System::Drawing::Size(173, 13);
			this->label3->TabIndex = 7;
			this->label3->Text = L"&VERTICAL SIZE adjustment factor:";
			// 
			// VertSize
			// 
			this->VertSize->Location = System::Drawing::Point(205, 295);
			this->VertSize->Name = L"VertSize";
			this->VertSize->Size = System::Drawing::Size(100, 20);
			this->VertSize->TabIndex = 8;
			this->VertSize->Text = L"1";
			// 
			// label4
			// 
			this->label4->AutoSize = true;
			this->label4->Location = System::Drawing::Point(318, 220);
			this->label4->Name = L"label4";
			this->label4->Size = System::Drawing::Size(58, 13);
			this->label4->TabIndex = 3;
			this->label4->Text = L"Normal = 0";
			// 
			// label5
			// 
			this->label5->AutoSize = true;
			this->label5->Location = System::Drawing::Point(318, 258);
			this->label5->Name = L"label5";
			this->label5->Size = System::Drawing::Size(58, 13);
			this->label5->TabIndex = 6;
			this->label5->Text = L"Normal = 0";
			// 
			// label6
			// 
			this->label6->AutoSize = true;
			this->label6->Location = System::Drawing::Point(318, 299);
			this->label6->Name = L"label6";
			this->label6->Size = System::Drawing::Size(58, 13);
			this->label6->TabIndex = 9;
			this->label6->Text = L"Normal = 1";
			// 
			// OKbutton
			// 
			this->OKbutton->Location = System::Drawing::Point(66, 343);
			this->OKbutton->Name = L"OKbutton";
			this->OKbutton->Size = System::Drawing::Size(75, 23);
			this->OKbutton->TabIndex = 10;
			this->OKbutton->Text = L"&OK";
			this->OKbutton->UseVisualStyleBackColor = true;
			// 
			// CancelButton
			// 
			this->CancelButton->DialogResult = System::Windows::Forms::DialogResult::Cancel;
			this->CancelButton->Location = System::Drawing::Point(172, 343);
			this->CancelButton->Name = L"CancelButton";
			this->CancelButton->Size = System::Drawing::Size(75, 23);
			this->CancelButton->TabIndex = 11;
			this->CancelButton->Text = L"&Cancel";
			this->CancelButton->UseVisualStyleBackColor = true;
			// 
			// HelpButton
			// 
			this->HelpButton->Location = System::Drawing::Point(278, 343);
			this->HelpButton->Name = L"HelpButton";
			this->HelpButton->Size = System::Drawing::Size(75, 23);
			this->HelpButton->TabIndex = 12;
			this->HelpButton->Text = L"&Help";
			this->HelpButton->UseVisualStyleBackColor = true;
			this->HelpButton->Click += gcnew System::EventHandler(this, &PICOptionsDialog::HelpButton_Click);
			// 
			// PICOptionsDialog
			// 
			this->AcceptButton = this->OKbutton;
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->CancelButton = this->CancelButton;
			this->ClientSize = System::Drawing::Size(419, 399);
			this->ControlBox = false;
			this->Controls->Add(this->HelpButton);
			this->Controls->Add(this->CancelButton);
			this->Controls->Add(this->OKbutton);
			this->Controls->Add(this->label6);
			this->Controls->Add(this->label5);
			this->Controls->Add(this->label4);
			this->Controls->Add(this->VertSize);
			this->Controls->Add(this->label3);
			this->Controls->Add(this->Skip);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->label1);
			this->Controls->Add(this->IniSkip);
			this->Controls->Add(this->groupBox1);
			this->FormBorderStyle = System::Windows::Forms::FormBorderStyle::FixedDialog;
			this->MaximizeBox = false;
			this->MinimizeBox = false;
			this->Name = L"PICOptionsDialog";
			this->Text = L".PIC File Drawing Options";
			this->groupBox1->ResumeLayout(false);
			this->groupBox1->PerformLayout();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion

private: System::Void HelpButton_Click(System::Object^  sender, System::EventArgs^  e) 
{
//WinHelp(HelpFilename,HELP_PARTIALKEY,(DWORD)(LPSTR)"PIC file options"); 
}
};
}
