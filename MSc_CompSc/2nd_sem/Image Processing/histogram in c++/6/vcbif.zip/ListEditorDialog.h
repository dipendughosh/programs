/*	ListEditorDialog.h				6-26-2008
	This is part of the VCBif project.
	Copyright (C)2008 Steven Whitney.
	Initially published by http://25yearsofprogramming.com.
	Published under GNU GPL (General Public License) Version 3, with ABSOLUTELY NO WARRANTY.

Dialog box for editing the file lists (MAP files and command line arguments).
Wshowfs has a dialog with more capability (resizable), as does WTalk (custom font),
but no additional capability is needed here.  It's fine.

This is not yet used by the project.
	
*/
#pragma once

using namespace System;
using namespace System::ComponentModel;
using namespace System::Collections;
using namespace System::Windows::Forms;
using namespace System::Data;
using namespace System::Drawing;

namespace VCBif {

	/// <summary>
	/// Summary for ListEditorDialog
	///
	/// WARNING: If you change the name of this class, you will need to change the
	///          'Resource File Name' property for the managed resource compiler tool
	///          associated with all .resx files this class depends on.  Otherwise,
	///          the designers will not be able to interact properly with localized
	///          resources associated with this form.
	/// </summary>
	public ref class ListEditorDialog : public System::Windows::Forms::Form
	{
	public:
		ListEditorDialog(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~ListEditorDialog()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::TextBox^  TextBox1;
	private: System::Windows::Forms::Button^  OKbutton;
	private: System::Windows::Forms::Button^  CancelButton;
	private: System::Windows::Forms::Button^  HelpButton;

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->TextBox1 = (gcnew System::Windows::Forms::TextBox());
			this->OKbutton = (gcnew System::Windows::Forms::Button());
			this->CancelButton = (gcnew System::Windows::Forms::Button());
			this->HelpButton = (gcnew System::Windows::Forms::Button());
			this->SuspendLayout();
			// 
			// TextBox1
			// 
			this->TextBox1->Dock = System::Windows::Forms::DockStyle::Top;
			this->TextBox1->Location = System::Drawing::Point(0, 0);
			this->TextBox1->Multiline = true;
			this->TextBox1->Name = L"TextBox1";
			this->TextBox1->Size = System::Drawing::Size(445, 394);
			this->TextBox1->TabIndex = 0;
			// 
			// OKbutton
			// 
			this->OKbutton->DialogResult = System::Windows::Forms::DialogResult::OK;
			this->OKbutton->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->OKbutton->Location = System::Drawing::Point(60, 416);
			this->OKbutton->Name = L"OKbutton";
			this->OKbutton->Size = System::Drawing::Size(75, 23);
			this->OKbutton->TabIndex = 1;
			this->OKbutton->Text = L"&OK";
			this->OKbutton->UseVisualStyleBackColor = true;
			// 
			// CancelButton
			// 
			this->CancelButton->DialogResult = System::Windows::Forms::DialogResult::Cancel;
			this->CancelButton->Location = System::Drawing::Point(168, 416);
			this->CancelButton->Name = L"CancelButton";
			this->CancelButton->Size = System::Drawing::Size(75, 23);
			this->CancelButton->TabIndex = 2;
			this->CancelButton->Text = L"&Cancel";
			this->CancelButton->UseVisualStyleBackColor = true;
			// 
			// HelpButton
			// 
			this->HelpButton->Location = System::Drawing::Point(276, 416);
			this->HelpButton->Name = L"HelpButton";
			this->HelpButton->Size = System::Drawing::Size(75, 23);
			this->HelpButton->TabIndex = 3;
			this->HelpButton->Text = L"&Help";
			this->HelpButton->UseVisualStyleBackColor = true;
			this->HelpButton->Click += gcnew System::EventHandler(this, &ListEditorDialog::HelpButton_Click);
			// 
			// ListEditorDialog
			// 
			this->AcceptButton = this->OKbutton;
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->CancelButton = this->CancelButton;
			this->ClientSize = System::Drawing::Size(445, 456);
			this->ControlBox = false;
			this->Controls->Add(this->HelpButton);
			this->Controls->Add(this->CancelButton);
			this->Controls->Add(this->OKbutton);
			this->Controls->Add(this->TextBox1);
			this->FormBorderStyle = System::Windows::Forms::FormBorderStyle::FixedDialog;
			this->MaximizeBox = false;
			this->MinimizeBox = false;
			this->Name = L"ListEditorDialog";
			this->Text = L"ListEditorDialog";
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion

private: System::Void HelpButton_Click(System::Object^  sender, System::EventArgs^  e) 
{
//WinHelp(HelpFilename,HELP_PARTIALKEY,(DWORD)(LPSTR)"File List Editor"); 
}
};
}
