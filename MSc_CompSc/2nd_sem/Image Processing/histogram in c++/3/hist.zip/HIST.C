#include <stdio.h>
#include <stdlib.h>
#include <math.h>

/*----------STRUCTURES-----------*/
typedef struct {int rows; int cols; char *data;} sImage;

/*--------PROTOTYPES------------*/
long getImageInfo(FILE*, long, int);

int main(int argc, char* argv[])
{
  FILE			*histogramData, *bmpInput;
  sImage		originalImage;
  unsigned char		someChar;
  unsigned char		*pChar;
  int			r, c, i;
  int			grayValue, nColors;
  long int		iHist[256];
  float			hist[256];
  long int		totalNumberOfPixels;

  someChar = '0';
  pChar = &someChar;

  if(argc < 2)
  {
    printf("Usage: %s bmpInput.bmp\n", argv[1]);
    exit(0);
  }
  printf("Reading filename %s\n", argv[1]);

  /*-----DECLARE INPUT AND OUTPUT FILES-------*/
  bmpInput = fopen(argv[1], "rb");
  histogramData = fopen("histData.txt", "w");

  fseek(bmpInput, 0L, SEEK_END);

  /*------READ INPUT BMP DATA------*/
  originalImage.cols = (int)getImageInfo(bmpInput, 18, 4);
  originalImage.rows = (int)getImageInfo(bmpInput, 22, 4);
  nColors = getImageInfo(bmpInput, 46, 4);

  /*------INITIALIZE ARRAY------*/
  for(i=0; i<=255; i++) iHist[i] = 0;
  for(i=0; i<=255; i++) hist[i] = 0;
  totalNumberOfPixels = 0;

  fseek(bmpInput, (54 + 4*nColors), SEEK_SET);

  for(r=0; r<=originalImage.rows-1; r++)
  {
    for(c=0; c<=originalImage.cols-1; c++)
    {
      fread(pChar, sizeof(char), 1, bmpInput);
      grayValue = *pChar;
      iHist[grayValue] = iHist[grayValue] + 1;
      totalNumberOfPixels++;
    }
  }

  printf("Total # of pixels: %ld\n", totalNumberOfPixels);
  for(i=0; i<=255; i++)
  {
    hist[i] = (float)iHist[i]/(float)totalNumberOfPixels;
    fprintf(histogramData, "%d\t%f\n", i, hist[i]);
  }

}

/*----------GET IMAGE INFO SUBPROGRAM--------------*/
long getImageInfo(FILE* inputFile, long offset, int numberOfChars)
{
  unsigned char			*ptrC;
  long				value = 0L;
  unsigned char			dummy;
  int				i;

  dummy = '0';
  ptrC = &dummy;

  fseek(inputFile, offset, SEEK_SET);

  for(i=1; i<=numberOfChars; i++)
  {
    fread(ptrC, sizeof(char), 1, inputFile);
    /* calculate value based on adding bytes */
    value = (long)(value + (*ptrC)*(pow(256, (i-1))));
  }
  return(value);

} /* end of getImageInfo */