/*-------------------------------------
FILE:	BIN_2.C - WORKS!!
AUTH:	BILL GREEN
DATE:	07/16/02
DESC:	CONVERTS GRAYSCALE IMAGE TO BINARY
	BASED ON THRESHOLD VALUE
NOTE:   Will only compile with Turbo C
	because "farmalloc" is used
--------------------------------------*/

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <alloc.h>

/*-----STRUCTURES-----*/
typedef struct {int rows; int cols; unsigned char *data;} sImage;

/*----PROTOTYPES----*/
long getImageInfo(FILE*, long, int);
void copyImageInfo(FILE*, FILE*);
void copyColorTable(FILE*, FILE*, int);

int main(int argc, char *argv[])
{
  FILE			*bmpInput, *binaryOutput;
  sImage		originalImage, binaryImage;
  unsigned char		someChar;
  unsigned char		*pChar;
  unsigned long		i, vectorSize; /*----FOR IMAGES OF LARGE SIZE----*/
  int			nColors, thresholdValue;

  someChar = '0';
  pChar = &someChar;

  if(argc < 2)
  {
    printf("Usage: %s bmpInput.bmp\n", argv[1]);
    exit(0);
  }
  printf("Reading filename %s\n", argv[1]);

  /*-----OBTAIN USER THRESHOLD VALUE-----*/
  printf("Enter threshold value between 0 & 255\n");
  scanf("%d", &thresholdValue);

  /*-----DECLARE INPUT AND OUTPUT FILES----*/
  bmpInput = fopen(argv[1], "rb");
  binaryOutput = fopen("binary.bmp", "wb");

  fseek(bmpInput, 0L, SEEK_END);

  /*----READ INPUT BMP DATA----*/
  nColors = getImageInfo(bmpInput, 46, 4);
  vectorSize = (unsigned long)(getImageInfo(bmpInput, 2, 4) - (14 + 40 + 4*nColors));
  originalImage.cols = (int)getImageInfo(bmpInput, 18, 4);
  originalImage.rows = (int)getImageInfo(bmpInput, 22, 4);

  /*----ALLOCATE MEMORY----*/
  binaryImage.data = farmalloc(vectorSize * sizeof(unsigned char));
  if(binaryImage.data == NULL)
  {
    printf("Failed to malloc binaryImage.data\n");
    exit(0);
  }

  /*----COPY IMAGE INFO AND COLOR TABLE TO BINARY BMP----*/
  copyImageInfo(bmpInput, binaryOutput);
  copyColorTable(bmpInput, binaryOutput, nColors);
  fseek(bmpInput, (54 + 4*nColors), SEEK_SET);
  fseek(binaryOutput, (54 + 4*nColors), SEEK_SET);

  for(i=0; i<=vectorSize - 1; i++)
  {
    fread(pChar, sizeof(char), 1, bmpInput);
    /*---CONVERT CHAR PIXEL TO BLACK OR WHITE BASED ON THRESHOLD VALUE---*/
    if(*pChar < thresholdValue) *(binaryImage.data + i) = 0;
    else *(binaryImage.data + i) = 255;
    fwrite((binaryImage.data + i), sizeof(char), 1, binaryOutput);
  }

  fclose(bmpInput);
  fclose(binaryOutput);
  farfree(binaryImage.data);
}

/*----------GET IMAGE INFO SUBPROGRAM--------------*/
long getImageInfo(FILE* inputFile, long offset, int numberOfChars)
{
  unsigned char			*ptrC;
  long				value = 0L;
  unsigned char			dummy;
  int				i;

  dummy = '0';
  ptrC = &dummy;

  fseek(inputFile, offset, SEEK_SET);

  for(i=1; i<=numberOfChars; i++)
  {
    fread(ptrC, sizeof(char), 1, inputFile);
    /* calculate value based on adding bytes */
    value = (long)(value + (*ptrC)*(pow(256, (i-1))));
  }
  return(value);

} /* end of getImageInfo */

/*-------------COPIES HEADER AND INFO HEADER----------------*/
void copyImageInfo(FILE* inputFile, FILE* outputFile)
{
  unsigned char		*ptrC;
  unsigned char		dummy;
  int			i;

  dummy = '0';
  ptrC = &dummy;

  fseek(inputFile, 0L, SEEK_SET);
  fseek(outputFile, 0L, SEEK_SET);

  for(i=0; i<=50; i++)
  {
    fread(ptrC, sizeof(char), 1, inputFile);
    fwrite(ptrC, sizeof(char), 1, outputFile);
  }

}

/*----------------COPIES COLOR TABLE-----------------------------*/
void copyColorTable(FILE* inputFile, FILE* outputFile, int nColors)
{
  unsigned char		*ptrC;
  unsigned char		dummy;
  int			i;

  dummy = '0';
  ptrC = &dummy;

  fseek(inputFile, 54L, SEEK_SET);
  fseek(outputFile, 54L, SEEK_SET);

  for(i=0; i<=(4*nColors); i++)  /* there are (4*nColors) bytesin color table */
  {
    fread(ptrC, sizeof(char), 1, inputFile);
    fwrite(ptrC, sizeof(char), 1, outputFile);
  }

}








