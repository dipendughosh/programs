/*---------------------------------------------
FILE:	CENT.C
AUTHOR:	BILL GREEN
DATE:	07/16/02
DESC:	CALCULATES CENTROID OF BINARY IMAGE
----------------------------------------------*/

#include <stdio.h>
#include <stdlib.h>
#include <math.h>

typedef struct {float row; float col; float area;} imageCentroid;
typedef struct {int rows; int cols; unsigned char *data;} sImage;

long getImageInfo(FILE*, long, int);

int main(int argc, char* argv[])
{
  FILE			*bmpInput;
  sImage		originalImage;
  unsigned char		someChar;
  unsigned char		*pChar;
  imageCentroid		ic;
  int			r, c, nColors;

  /*-----INITIALIZE POINTER------*/
  someChar = '0';
  pChar = &someChar;

  if(argc < 2)
  {
    printf("Usage: %s bmpInput.bmp\n", argv[0]);
    exit(0);
  }
  printf("Reading filename %s\n", argv[1]);

  /*-------DECLARE INPUT FILE--------*/
  bmpInput = fopen(argv[1], "rb");
  fseek(bmpInput, 0L, SEEK_END);

  /*-----INITIALIZE VALUES-----*/
  ic.row = ic.col = ic.area = 0.0;

  /*-------GET INPUT BMP DATA---------*/
  originalImage.cols = getImageInfo(bmpInput, 18, 4);
  originalImage.rows = getImageInfo(bmpInput, 22, 4);
  nColors = getImageInfo(bmpInput, 46, 4);

  fseek(bmpInput, (54 + 4*nColors), SEEK_SET);

  for(r=0; r<=originalImage.rows-1; r++)
  {
    for(c=0; c<=originalImage.cols-1; c++)
    {
      fread(pChar, sizeof(char), 1, bmpInput);
      if(*pChar == 0.0)
      {
	/*-------------------------------------------------------
	originalImage.rows-1 term b/c BMP is stored bottom to top,
	so when centroid location value is outputted, it is NOW in
	matrix form - top left corner (0,0)
	-------------------------------------------------------*/
	ic.row = ic.row + (originalImage.rows-1) - r;
	ic.col = ic.col + c;
	ic.area = ic.area + 1.0;
      }
    }
  }

  printf("Sum of black row pixels = %f\n", ic.row);
  printf("Sum of black col pixels = %f\n", ic.col);

  ic.row = ic.row/ic.area;
  ic.col = ic.col/ic.area;

  printf("Centroid location:\n");
  printf("row = %f\n", ic.row);
  printf("column = %f\n", ic.col);
}

/*----------GET IMAGE INFO SUBPROGRAM--------------*/
long getImageInfo(FILE* inputFile, long offset, int numberOfChars)
{
  unsigned char			*ptrC;
  long				value = 0L;
  unsigned char			dummy;
  int				i;

  dummy = '0';
  ptrC = &dummy;

  fseek(inputFile, offset, SEEK_SET);

  for(i=1; i<=numberOfChars; i++)
  {
    fread(ptrC, sizeof(char), 1, inputFile);
    /* calculate value based on adding bytes */
    value = (long)(value + (*ptrC)*(pow(256, (i-1))));
  }
  return(value);

} /* end of getImageInfo */