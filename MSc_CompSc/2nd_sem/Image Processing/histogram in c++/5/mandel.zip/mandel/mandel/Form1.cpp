// *********************************************************************
// *     This software is made available only to individuals and only  *
// *     for educational purposes. Any and all commercial use is       *
// *     stricly prohibited.                                           *
// *********************************************************************
//**********************************************************************
//* Disclaimer: Any borrowed code used in this                         *
//*             program is the property of the                         *
//*             code originator. credit to them.                       *
//*                                                                    *
//*   Windows Forms/Managed C++:                                       *
//*   Unfinished                                                       *
//*   WARNING: NON-MULTI-THREADED VERSION                              *
//*                                                                    *
//*                                                                    *
//*                                                                    *  
//**********************************************************************

#include "stdafx.h"
#include "Form1.h"
namespace mandel {

		 void Form1::calculateFractal( ){
		   int x=0,y=0,icount=0;Form1::is_running=true;Form1::unEnableButtons();
		   fwdt = (xmax-xmin)/WIDTH;fhgt = (ymax-ymin)/HEIGHT;
		   progressBar1->Visible::set(true); progressBar1->Maximum = HEIGHT;
		   progressBar1->Minimum = 1; progressBar1->Value = 1; progressBar1->Step = 1;
		   for (y=0;y<HEIGHT;y++){
		    for (x=0;x<WIDTH;x++) {
		     blue = (getFractalColor(x,y) & 0x0f) << 4;
		     green =	(getFractalColor(x,y) & 0xf0) << 0;
		     red =	(getFractalColor(x,y) & 0xf00) >> 4;
		     mBmp->SetPixel(x,y,Color::FromArgb(red  , green , blue ));//if (!Form1::is_running) return;
			} progressBar1->PerformStep();
		   }progressBar1->Visible::set(false); pictureBox1->Image=mBmp;Form1::enableButtons();backBuffer=mBmp;
		  }

		 void Form1::enableButtons() {
			 Form1::btnCalculate->Enabled::set(true);
			 Form1::btnReset->Enabled::set(true);
			 Form1::btnInfo->Enabled::set(true);
			 Form1::btnExit->Enabled::set(true);
		 }
		 void Form1::unEnableButtons() {
			 Form1::btnCalculate->Enabled::set(false);
			 Form1::btnReset->Enabled::set(false);
			 Form1::btnInfo->Enabled::set(false);
			 Form1::btnExit->Enabled::set(false);
		 }

		int Form1::getFractalColor( int x, int y){
			int gfCol=0,icount=0;
			double cplx=0,cply=0,r=0,i=0,cplxrev_r=0,cplxrev_i=0;
			cplx= (( (double)x ) * fwdt) + (double)xmin;cply= (( (double)y ) * fhgt) +(double)ymin;
			cplxrev_i = 0;	cplxrev_r = 0;
			for (gfCol=0; gfCol <= ncls; gfCol++){
  		    r = (cplxrev_r * cplxrev_r) - (cplxrev_i * cplxrev_i) +cplx;
			i = 2 * (cplxrev_r * cplxrev_i) +cply;
			if (( r*r + i*i) < mctf ){cplxrev_r = r;cplxrev_i = i;}	else return gfCol;
			}
			return gfCol;
		}




		void Form1::initRect( )	{
			/* rect.left   = WIDTH+5;rect.top    = HEIGHT-15; rect.bottom = HEIGHT-1; rect.right  = WIDTH+ WEXT; hbrush = CreateSolidBrush(RGB(128,128,128));
		   FillRect(hdc,&rect,hbrush); rect.right  = WIDTH+5 ; hbrush = CreateSolidBrush(RGB(0,0,128)); FillRect(hdc,&rect,hbrush); */
		}

		void Form1::resetFrac( ){
			xmin = -2.10;xmax = 0.75;ymin = -1.50;ymax = 1.50;
			zsx=xmin;zsy=ymin;zex=xmax;	zey=ymax;
			MouseX=WIDTH/2;MouseY=HEIGHT/2;zoomcnt=0;
			displayData();
		}

		void Form1::putCursor( ){
	        Pen^  thePen = gcnew Pen( Color::White,3.0f );
			}


		void Form1::calcjset(double jcx,double jcy){
			   mrandom=rrandom->Next() % 3;
			   jdx=jx-jcx; jdy=jy-jcy;
			   if(jdx>0) theta=Math::Atan(jdy/jdx)*0.5;
			   else  if (jdx<0) theta=(Math::PI+Math::Atan(jdy/jdx))*0.5;
			   else  theta=pi*0.25;
			   r=Math::Sqrt(Math::Sqrt((jdx*jdx)+(jdy*jdy)));
			   if (mrandom<2)  r=-r;
			   jx=r*Math::Cos(theta);jy=r*Math::Sin(theta);
			   xp=(WIDTH / 2 + (jx*(WIDTH/9))+WIDTH)-24;
			   yp=(HEIGHT-HEIGHT/2) + (jy*(HEIGHT/9))+48;
			   blue = ((int)xp & 0x0f) << 4;
			   green =((int)yp & 0xf0) << 0;
			   red =((int)xp+(int)yp & 0xf00) >> 4;
		}

		void Form1::initWalk( )	{
			/*rect.left   = WIDTH+5;rect.top    = (HEIGHT/2)-24;rect.bottom = HEIGHT-52;rect.right  = (2*WIDTH)-48;	*/
		}

		void Form1::walkabout( ){
			unsigned char dir=0;
			double dx,dy,cx,cy;
			dx=(xmax-xmin)/(WIDTH-1);dy=(ymax-ymin)/(HEIGHT-1);
			cx=xmin+dx*MouseX;cy=ymin+dy*MouseY;
			JuliaSet(cx,cy);
		}

		void Form1::JuliaSet(double p, double q){
			  double    x,y,x2, y2,temp,powerof2=0;
			  double    cx, cy, dx, dy,JSetPot;
			  int      ix, iy, Recurs,z;Form1::unEnableButtons();
			  dx = (XMax - XMin) / (ResX- 1); dy = (YMax - YMin) / (ResY- 1);
			  label11->Text="Julia Walk"; label12->Text="  "+MouseX +"x"+MouseY;
			  label13->Text=" "+p; label14->Text="  "+q;
			   progressBar1->Visible::set(true); progressBar1->Maximum = ResY;
			   progressBar1->Minimum = 1; progressBar1->Value = 1; progressBar1->Step = 1;
			  for (ix = 0;ix<ResX;ix++){
				cx = XMin + ix * dx;
				for (iy= 0; iy<ResY;iy++){
				 cy = YMin + iy * dy;
				  x  = cx;x2 = x*x;y  = cy;y2 = y*y;Recurs = 0;
				  while (Recurs < Recur && x2+y2 < 20000){
				 	 temp  = p + x2 - y2; y     = q + 2 * x * y;
					 y2    = y*y; x     = temp;	 x2    = x*x; Recurs = Recurs+1;
				  }
				  if (Recurs < Recur) JSetPot = 0.5 * Math::Log(x2+y2) / Math::Pow(2, Recurs);
				  else   JSetPot = 0.0;
				  z = (int)(JSetPot * mndlDmsn);
				  blue = (Recurs & 0x0f) << 4;
				  green =	(Recurs & 0xf0) << 0;
				  red =	(Recurs & 0xf00) >> 4;
				  jBmp->SetPixel(ix  ,iy ,Color::FromArgb( red , green , blue  ));
				 }progressBar1->PerformStep();
		  } pictureBox2->Image=jBmp; progressBar1->Visible::set(false);Form1::enableButtons();
		}

		void Form1::displayData(){
			px=midx-midx;py=midy-midy;
			dxx=(xmin+(xmax-xmin)*(((double)mouse_x)-px)/(WIDTH-1));
			dyy=(ymin+(ymax-ymin)*(((double)mouse_y)-py)/(HEIGHT-1));
			label1->Text =" "+zoomcnt+"  ";
			label2->Text =" " +mousex+"x" +mousey ;
			label3->Text =" " +sx +"x"+sy;
			label4->Text =" "  + ex +"x"+ey;


			label6->Text =" "+ xmin;    label36->Text =" "+xmax;
			label7->Text =" "+ ymin;    label37->Text =" "+ymax;
			label8->Text =" "+ zsx;     label38->Text =" "+ zex;
			label9->Text =" "+ zsy;     label34->Text =" "+ zey;			
			label10->Text=" "+ dxx;     label39->Text =" "+dyy;
		}

		void Form1::showTips()	{
			MessageBox::Show(
			"Getting into the groove.." +  "\n"+
			"" +  "\n"+
			"1. Click on the Calculate Button to initiate/display a Mandelbrot set." + "\n"+
			"2. Click , drag and release the LeftMouseButton to select a Zoom Region.                          " +  "\n"+
			"3. Right Click the RightMouseButton anywhere on the Mandelbrot set to Calculate a Julia walk      " + "\n" ,
			"MandelBrot Imager/Julia Walker By RonCharles,  ron28@bredband.net"+ "\n" ,
			MessageBoxButtons::OK ,
			MessageBoxIcon::Information );

		}

		void Form1::saveMandelImageToFile(){
			saveFileDialog1->FileName="mandel.png";
			if ( saveFileDialog1->ShowDialog() != System::Windows::Forms::DialogResult::Cancel ){
			mBmp->Save(saveFileDialog1->FileName);
			}
		}

		void Form1::saveJuliaImageToFile(){
			saveFileDialog1->FileName="julia.png";
			if ( saveFileDialog1->ShowDialog() != System::Windows::Forms::DialogResult::Cancel ){
			jBmp->Save(saveFileDialog1->FileName);
			}
		}

}
