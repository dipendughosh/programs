// *********************************************************************
// *     This software is made available only to individuals and only  *
// *     for educational purposes. Any and all commercial use is       *
// *     stricly prohibited.                                           *
// *********************************************************************
//**********************************************************************
//* Disclaimer: Any borrowed code used in this                         *
//*             program is the property of the                         *
//*             code originator. credit to them.                       *
//*                                                                    *
//*   Windows Forms/Managed C++:                                       *
//*   Unfinished                                                       *
//*   WARNING: NON-MULTI-THREADED VERSION                              *
//*                                                                    *
//*                                                                    *
//*                                                                    *  
//**********************************************************************

 
#pragma once

namespace mandel {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace System::Threading;

	/// <summary>
	/// Summary for Form1
	///
	/// WARNING: If you change the name of this class, you will need to change the
	///          'Resource File Name' property for the managed resource compiler tool
	///          associated with all .resx files this class depends on.  Otherwise,
	///          the designers will not be able to interact properly with localized
	///          resources associated with this form.
	/// </summary>
	public  ref class  Form1 : public System::Windows::Forms::Form
	{
		public:
		static const double   pi= 3.1415926;
		static   int   WIDTH = 400;
		static   int   HEIGHT = 400;
		static const int   WEXT = 380;
		static const int   HEXT = 210;
		static int   mctf  =     128;//1000;
		static int   ncls  =     128;//4096;
		static int   Recur =     128;//100;
		static int   mndlDmsn  = 128;//64000;
		static const int   ID_TIMER = 1;
		static const int   dvf = 1;
    	static const double   XMin   = -1.4;
		static const double   XMax   =  1.4;
		static const double   YMin   = -1.4;
		static const double   YMax    = 1.4;
		static const int   ResX = 150;
		static const int   ResY = 150;
		static Bitmap^ mBmp = gcnew Bitmap(410,410);
		static Bitmap^ jBmp = gcnew Bitmap(150,150);
		static Bitmap^ backBuffer= gcnew Bitmap(410,410);
		static Color^ c=gcnew Color();
		static Random^ rrandom = gcnew Random( Environment::TickCount );
		static DrawItemEventArgs^ Dre;
		static Graphics^ g;
		static int max_Recurations=0,mousex=0,mousey=0,xorEx=0,xorEy=0,MouseX=0,MouseY=0,mrandom=0;
		static double xmin = -2.10, xmax = 0.75, ymin = -1.5 , ymax = 1.5;
		static double  fwdt=0, fhgt=0,mandR,mandi;
		static double midx=0,midy=0,dx=0,dy=0;
		static double dxx=0,dyy=0,px=0,py=0,zsx=0,zsy=0,zex=0,zey=0;
		static double xp=0,yp=0;
		static double jdx=0,jdy=0,r=0,theta=0,jx=0,jy=0,tempx=0,tempy=0;
		static int red=0;
		static int blue=0;
		static int green=0;
		static int sx=0,sy=0,ex=0,ey=0,zoomcnt=0;
		static bool m_show,is_running=false,is_done=false;
		static Point start = Point(1,1);
		static Point end = Point(1,1);
		static int mouse_x=0;
		static int mouse_y=0;
		static double startx=0,starty=0,endx=0,endy=0;

		static 		 Random^ random = gcnew Random( Environment::TickCount );
		
	
		private: System::Windows::Forms::SaveFileDialog^  saveFileDialog1;
		private: System::Windows::Forms::Label^  label15;
		private: System::Windows::Forms::Label^  label16;
		private: System::Windows::Forms::Label^  label17;
		private: System::Windows::Forms::Label^  label18;
		private: System::Windows::Forms::Label^  label19;
		private: System::Windows::Forms::Label^  label20;
		private: System::Windows::Forms::Label^  label21;
		private: System::Windows::Forms::Label^  label22;
		private: System::Windows::Forms::Label^  label23;
		private: System::Windows::Forms::Label^  label24;

		private: System::Windows::Forms::Label^  label26;
		private: System::Windows::Forms::Label^  label27;
		private: System::Windows::Forms::Label^  label28;
		private: System::Windows::Forms::Label^  label25;
		private: System::Windows::Forms::Label^  label29;
		private: System::Windows::Forms::Label^  label30;
		private: System::Windows::Forms::Label^  label31;
		private: System::Windows::Forms::NumericUpDown^  numericUpDown4;
		private: System::Windows::Forms::NumericUpDown^  numericUpDown3;
		private: System::Windows::Forms::NumericUpDown^  numericUpDown2;
		private: System::Windows::Forms::NumericUpDown^  numericUpDown1;
		private: System::Windows::Forms::ToolStripMenuItem^  copyMandelbrotToClipboardToolStripMenuItem;
		private: System::Windows::Forms::ToolStripMenuItem^  copyJuliaToClipboardToolStripMenuItem;
		private: System::Windows::Forms::ToolStripMenuItem^  toolStripMenuItem3;
		private: System::Windows::Forms::ToolStripButton^  toolStripButton1;
		private: System::Windows::Forms::ToolStripButton^  toolStripButton2;
		private: System::Windows::Forms::ToolStripButton^  toolStripButton3;
		private: System::Windows::Forms::ToolStripButton^  toolStripButton4;
		private: System::Windows::Forms::ToolStripSeparator^  toolStripSeparator1;
		private: System::Windows::Forms::ToolStripSeparator^  toolStripSeparator2;
		private: System::ComponentModel::BackgroundWorker^  backgroundWorker1;
		private: System::Windows::Forms::ToolStripSeparator^  toolStripSeparator3;
		private: System::Windows::Forms::PictureBox^  pictureBox3;
		private: System::Windows::Forms::PictureBox^  pictureBox4;
		private: System::Windows::Forms::NumericUpDown^  numericUpDown6;
		private: System::Windows::Forms::Label^  label33;
		private: System::Windows::Forms::NumericUpDown^  numericUpDown5;
		private: System::Windows::Forms::Label^  label32;
	private: System::Windows::Forms::CheckBox^  checkBox1;
	private: System::Windows::Forms::Label^  label40;
	private: System::Windows::Forms::Label^  label41;
	private: System::Windows::Forms::Label^  label42;
	private: System::Windows::Forms::Label^  label43;
	private: System::Windows::Forms::Label^  label44;
	private: System::Windows::Forms::Label^  label45;
	private: System::Windows::Forms::Label^  label34;
	private: System::Windows::Forms::Label^  label35;
	private: System::Windows::Forms::Label^  label36;
	private: System::Windows::Forms::Label^  label37;
	private: System::Windows::Forms::Label^  label38;
	private: System::Windows::Forms::Label^  label39;
	public:
		static Rectangle rect;
		void calculateFractal(/*HDC hdc*/);
		int getFractalColor( int x, int y);
		void initRect(void);
		void resetFrac(void);
		void putCursor( );
		void calcjset(double jcx,double jcy);
		void initWalk(void);
		void walkabout(void);
		void JuliaSet(double p, double q);
		void displayData();
		void showTips();
		void saveMandelImageToFile();
		void saveJuliaImageToFile();
        void unEnableButtons();
		void enableButtons();
		private: System::Windows::Forms::Button^  btnAbort;
		private: System::Windows::Forms::Button^  btnExit;
		private: System::Windows::Forms::Button^  btnReset;
		private: System::Windows::Forms::Button^  btnCalculate;

		private: System::Windows::Forms::Label^  label1;
		private: System::Windows::Forms::Label^  label2;
		private: System::Windows::Forms::Label^  label3;
		private: System::Windows::Forms::Label^  label4;
		private: System::Windows::Forms::Label^  label5;
		private: System::Windows::Forms::Label^  label6;
		private: System::Windows::Forms::Label^  label7;
		private: System::Windows::Forms::Label^  label8;
		private: System::Windows::Forms::Label^  label9;
		private: System::Windows::Forms::Label^  label10;
		private: System::Windows::Forms::ToolStripMenuItem^  toolStripMenuItem1;
		private: System::Windows::Forms::ToolStripMenuItem^  editToolStripMenuItem;
		private: System::Windows::Forms::ToolStripMenuItem^  helpToolStripMenuItem;
		private: System::Windows::Forms::ToolStripStatusLabel^  toolStripStatusLabel1;
		private: System::Windows::Forms::ToolStripStatusLabel^  toolStripStatusLabel2;
		private: System::Windows::Forms::ToolStripStatusLabel^  toolStripStatusLabel3;
		private: System::Windows::Forms::Timer^  timer1;
		private: System::Windows::Forms::ProgressBar^  progressBar1;
		private: System::Windows::Forms::Label^  label11;
		private: System::Windows::Forms::Label^  label12;
		private: System::Windows::Forms::Label^  label13;
private: System::Windows::Forms::Button^  btnInfo;


private: System::Windows::Forms::PictureBox^  pictureBox1;
		private: System::Windows::Forms::PictureBox^  pictureBox2;
		private: System::Windows::Forms::ContextMenuStrip^  contextMenuStrip1;
		private: System::Windows::Forms::ToolStripMenuItem^  resetToolStripMenuItem;
		private: System::Windows::Forms::ToolStripMenuItem^  exitToolStripMenuItem1;
		private: System::Windows::Forms::ToolStripMenuItem^  aboutToolStripMenuItem;
		private: System::Windows::Forms::GroupBox^  groupBox1;
		private: System::Windows::Forms::Button^  button4;
		private: System::Windows::Forms::GroupBox^  groupBox2;
		private: System::Windows::Forms::GroupBox^  groupBox3;
		private: System::Windows::Forms::ToolStripMenuItem^  toolStripMenuItem2;
		private: System::Windows::Forms::Label^  label14;
		public:

		public: Form1(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//

			//threadDelegate = gcnew ThreadStart( this,&Form1::  );
			//newThread = gcnew Thread( threadDelegate );
			//newThread->Start(); 

			resetFrac();timer1->Interval =1000;	timer1->Enabled::set(true);zoomcnt=0;
			progressBar1->Visible::set(true);Form1::is_running=false;
			toolStripStatusLabel1->Text ="wnd:"+this->Width+"x"+this->Height ;
			toolStripStatusLabel2->Text ="Mnd:"+WIDTH+"x"+HEIGHT;
			xmin = -2.10;xmax = 0.75;ymin = -1.50;ymax = 1.50;
			MouseX=WIDTH/2;MouseY=HEIGHT/2;midx=WIDTH/2;midy=HEIGHT/2;MouseX=WIDTH/2;	MouseY=HEIGHT/2;
			Form1::numericUpDown2->Value=System::Convert::ToDecimal(mctf);
			Form1::numericUpDown1->Value=System::Convert::ToDecimal(ncls);
			Form1::numericUpDown3->Value=System::Convert::ToDecimal(Recur);
			Form1::numericUpDown4->Value=System::Convert::ToDecimal(mndlDmsn);
			Form1::numericUpDown5->Value=System::Convert::ToDecimal(WIDTH);
			Form1::numericUpDown6->Value=System::Convert::ToDecimal(HEIGHT);
		
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected:~Form1()
		{
			if (components)
			{
				delete components;
			}
		}
		private: System::Windows::Forms::MenuStrip^  menuStrip1;
		protected:
		private: System::Windows::Forms::ToolStripMenuItem^  fileToolStripMenuItem;
		private: System::Windows::Forms::ToolStripMenuItem^  exitToolStripMenuItem;
		private: System::Windows::Forms::ToolStrip^  toolStrip1;
		private: System::Windows::Forms::StatusStrip^  statusStrip1;
		private: System::ComponentModel::IContainer^  components;

		private:
			/// <summary>
			/// Required designer variable.
			/// </summary>

#pragma region Windows Form Designer generated code
	/// <summary>
	/// Required method for Designer support - do not modify
	/// the contents of this method with the code editor.
	/// </summary>
	void InitializeComponent(void)
	{
		this->components = (gcnew System::ComponentModel::Container());
		System::ComponentModel::ComponentResourceManager^  resources = (gcnew System::ComponentModel::ComponentResourceManager(Form1::typeid));
		this->menuStrip1 = (gcnew System::Windows::Forms::MenuStrip());
		this->fileToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
		this->toolStripMenuItem1 = (gcnew System::Windows::Forms::ToolStripMenuItem());
		this->toolStripMenuItem3 = (gcnew System::Windows::Forms::ToolStripMenuItem());
		this->exitToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
		this->editToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
		this->copyMandelbrotToClipboardToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
		this->copyJuliaToClipboardToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
		this->helpToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
		this->aboutToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
		this->toolStrip1 = (gcnew System::Windows::Forms::ToolStrip());
		this->toolStripButton1 = (gcnew System::Windows::Forms::ToolStripButton());
		this->toolStripSeparator1 = (gcnew System::Windows::Forms::ToolStripSeparator());
		this->toolStripButton2 = (gcnew System::Windows::Forms::ToolStripButton());
		this->toolStripSeparator2 = (gcnew System::Windows::Forms::ToolStripSeparator());
		this->toolStripButton3 = (gcnew System::Windows::Forms::ToolStripButton());
		this->toolStripSeparator3 = (gcnew System::Windows::Forms::ToolStripSeparator());
		this->toolStripButton4 = (gcnew System::Windows::Forms::ToolStripButton());
		this->statusStrip1 = (gcnew System::Windows::Forms::StatusStrip());
		this->toolStripStatusLabel1 = (gcnew System::Windows::Forms::ToolStripStatusLabel());
		this->toolStripStatusLabel2 = (gcnew System::Windows::Forms::ToolStripStatusLabel());
		this->toolStripStatusLabel3 = (gcnew System::Windows::Forms::ToolStripStatusLabel());
		this->btnCalculate = (gcnew System::Windows::Forms::Button());
		this->btnExit = (gcnew System::Windows::Forms::Button());
		this->btnReset = (gcnew System::Windows::Forms::Button());
		this->label1 = (gcnew System::Windows::Forms::Label());
		this->label2 = (gcnew System::Windows::Forms::Label());
		this->label3 = (gcnew System::Windows::Forms::Label());
		this->label4 = (gcnew System::Windows::Forms::Label());
		this->label5 = (gcnew System::Windows::Forms::Label());
		this->label6 = (gcnew System::Windows::Forms::Label());
		this->label7 = (gcnew System::Windows::Forms::Label());
		this->label8 = (gcnew System::Windows::Forms::Label());
		this->label9 = (gcnew System::Windows::Forms::Label());
		this->label10 = (gcnew System::Windows::Forms::Label());
		this->timer1 = (gcnew System::Windows::Forms::Timer(this->components));
		this->progressBar1 = (gcnew System::Windows::Forms::ProgressBar());
		this->label11 = (gcnew System::Windows::Forms::Label());
		this->label12 = (gcnew System::Windows::Forms::Label());
		this->label13 = (gcnew System::Windows::Forms::Label());
		this->label14 = (gcnew System::Windows::Forms::Label());
		this->pictureBox1 = (gcnew System::Windows::Forms::PictureBox());
		this->contextMenuStrip1 = (gcnew System::Windows::Forms::ContextMenuStrip(this->components));
		this->toolStripMenuItem2 = (gcnew System::Windows::Forms::ToolStripMenuItem());
		this->resetToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
		this->exitToolStripMenuItem1 = (gcnew System::Windows::Forms::ToolStripMenuItem());
		this->pictureBox2 = (gcnew System::Windows::Forms::PictureBox());
		this->groupBox1 = (gcnew System::Windows::Forms::GroupBox());
		this->btnInfo = (gcnew System::Windows::Forms::Button());
		this->btnAbort = (gcnew System::Windows::Forms::Button());
		this->groupBox2 = (gcnew System::Windows::Forms::GroupBox());
		this->label40 = (gcnew System::Windows::Forms::Label());
		this->label41 = (gcnew System::Windows::Forms::Label());
		this->label42 = (gcnew System::Windows::Forms::Label());
		this->label43 = (gcnew System::Windows::Forms::Label());
		this->label44 = (gcnew System::Windows::Forms::Label());
		this->label45 = (gcnew System::Windows::Forms::Label());
		this->label34 = (gcnew System::Windows::Forms::Label());
		this->label35 = (gcnew System::Windows::Forms::Label());
		this->label36 = (gcnew System::Windows::Forms::Label());
		this->label37 = (gcnew System::Windows::Forms::Label());
		this->label38 = (gcnew System::Windows::Forms::Label());
		this->label39 = (gcnew System::Windows::Forms::Label());
		this->checkBox1 = (gcnew System::Windows::Forms::CheckBox());
		this->numericUpDown6 = (gcnew System::Windows::Forms::NumericUpDown());
		this->label33 = (gcnew System::Windows::Forms::Label());
		this->numericUpDown5 = (gcnew System::Windows::Forms::NumericUpDown());
		this->label32 = (gcnew System::Windows::Forms::Label());
		this->numericUpDown4 = (gcnew System::Windows::Forms::NumericUpDown());
		this->groupBox3 = (gcnew System::Windows::Forms::GroupBox());
		this->label26 = (gcnew System::Windows::Forms::Label());
		this->label27 = (gcnew System::Windows::Forms::Label());
		this->label28 = (gcnew System::Windows::Forms::Label());
		this->numericUpDown3 = (gcnew System::Windows::Forms::NumericUpDown());
		this->numericUpDown2 = (gcnew System::Windows::Forms::NumericUpDown());
		this->numericUpDown1 = (gcnew System::Windows::Forms::NumericUpDown());
		this->label25 = (gcnew System::Windows::Forms::Label());
		this->label29 = (gcnew System::Windows::Forms::Label());
		this->label30 = (gcnew System::Windows::Forms::Label());
		this->label31 = (gcnew System::Windows::Forms::Label());
		this->label21 = (gcnew System::Windows::Forms::Label());
		this->label22 = (gcnew System::Windows::Forms::Label());
		this->label23 = (gcnew System::Windows::Forms::Label());
		this->label24 = (gcnew System::Windows::Forms::Label());
		this->label15 = (gcnew System::Windows::Forms::Label());
		this->label16 = (gcnew System::Windows::Forms::Label());
		this->label17 = (gcnew System::Windows::Forms::Label());
		this->label18 = (gcnew System::Windows::Forms::Label());
		this->label19 = (gcnew System::Windows::Forms::Label());
		this->label20 = (gcnew System::Windows::Forms::Label());
		this->saveFileDialog1 = (gcnew System::Windows::Forms::SaveFileDialog());
		this->backgroundWorker1 = (gcnew System::ComponentModel::BackgroundWorker());
		this->pictureBox3 = (gcnew System::Windows::Forms::PictureBox());
		this->pictureBox4 = (gcnew System::Windows::Forms::PictureBox());
		this->menuStrip1->SuspendLayout();
		this->toolStrip1->SuspendLayout();
		this->statusStrip1->SuspendLayout();
		(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->pictureBox1))->BeginInit();
		this->contextMenuStrip1->SuspendLayout();
		(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->pictureBox2))->BeginInit();
		this->groupBox1->SuspendLayout();
		this->groupBox2->SuspendLayout();
		(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->numericUpDown6))->BeginInit();
		(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->numericUpDown5))->BeginInit();
		(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->numericUpDown4))->BeginInit();
		this->groupBox3->SuspendLayout();
		(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->numericUpDown3))->BeginInit();
		(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->numericUpDown2))->BeginInit();
		(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->numericUpDown1))->BeginInit();
		(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->pictureBox3))->BeginInit();
		(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->pictureBox4))->BeginInit();
		this->SuspendLayout();
		// 
		// menuStrip1
		// 
		this->menuStrip1->Items->AddRange(gcnew cli::array< System::Windows::Forms::ToolStripItem^  >(3) {this->fileToolStripMenuItem, 
			this->editToolStripMenuItem, this->helpToolStripMenuItem});
		this->menuStrip1->Location = System::Drawing::Point(0, 0);
		this->menuStrip1->Name = L"menuStrip1";
		this->menuStrip1->Size = System::Drawing::Size(789, 24);
		this->menuStrip1->TabIndex = 0;
		this->menuStrip1->Text = L"menuStrip1";
		// 
		// fileToolStripMenuItem
		// 
		this->fileToolStripMenuItem->DropDownItems->AddRange(gcnew cli::array< System::Windows::Forms::ToolStripItem^  >(3) {this->toolStripMenuItem1, 
			this->toolStripMenuItem3, this->exitToolStripMenuItem});
		this->fileToolStripMenuItem->Name = L"fileToolStripMenuItem";
		this->fileToolStripMenuItem->Size = System::Drawing::Size(37, 20);
		this->fileToolStripMenuItem->Text = L"File";
		// 
		// toolStripMenuItem1
		// 
		this->toolStripMenuItem1->Name = L"toolStripMenuItem1";
		this->toolStripMenuItem1->Size = System::Drawing::Size(177, 22);
		this->toolStripMenuItem1->Text = L"Save Mandelbrot..";
		this->toolStripMenuItem1->Click += gcnew System::EventHandler(this, &Form1::toolStripMenuItem1_Click);
		// 
		// toolStripMenuItem3
		// 
		this->toolStripMenuItem3->Name = L"toolStripMenuItem3";
		this->toolStripMenuItem3->Size = System::Drawing::Size(177, 22);
		this->toolStripMenuItem3->Text = L"Save Julia.. ";
		this->toolStripMenuItem3->Click += gcnew System::EventHandler(this, &Form1::toolStripMenuItem3_Click);
		// 
		// exitToolStripMenuItem
		// 
		this->exitToolStripMenuItem->Name = L"exitToolStripMenuItem";
		this->exitToolStripMenuItem->Size = System::Drawing::Size(177, 22);
		this->exitToolStripMenuItem->Text = L"Exit";
		this->exitToolStripMenuItem->Click += gcnew System::EventHandler(this, &Form1::exitToolStripMenuItem_Click);
		// 
		// editToolStripMenuItem
		// 
		this->editToolStripMenuItem->DropDownItems->AddRange(gcnew cli::array< System::Windows::Forms::ToolStripItem^  >(2) {this->copyMandelbrotToClipboardToolStripMenuItem, 
			this->copyJuliaToClipboardToolStripMenuItem});
		this->editToolStripMenuItem->Name = L"editToolStripMenuItem";
		this->editToolStripMenuItem->Size = System::Drawing::Size(39, 20);
		this->editToolStripMenuItem->Text = L"Edit";
		// 
		// copyMandelbrotToClipboardToolStripMenuItem
		// 
		this->copyMandelbrotToClipboardToolStripMenuItem->Name = L"copyMandelbrotToClipboardToolStripMenuItem";
		this->copyMandelbrotToClipboardToolStripMenuItem->Size = System::Drawing::Size(242, 22);
		this->copyMandelbrotToClipboardToolStripMenuItem->Text = L"Copy mandelbrot to clipboard";
		this->copyMandelbrotToClipboardToolStripMenuItem->Click += gcnew System::EventHandler(this, &Form1::copyMandelbrotToClipboardToolStripMenuItem_Click);
		// 
		// copyJuliaToClipboardToolStripMenuItem
		// 
		this->copyJuliaToClipboardToolStripMenuItem->Name = L"copyJuliaToClipboardToolStripMenuItem";
		this->copyJuliaToClipboardToolStripMenuItem->Size = System::Drawing::Size(242, 22);
		this->copyJuliaToClipboardToolStripMenuItem->Text = L"Copy Julia to clipboard";
		this->copyJuliaToClipboardToolStripMenuItem->Click += gcnew System::EventHandler(this, &Form1::copyJuliaToClipboardToolStripMenuItem_Click);
		// 
		// helpToolStripMenuItem
		// 
		this->helpToolStripMenuItem->DropDownItems->AddRange(gcnew cli::array< System::Windows::Forms::ToolStripItem^  >(1) {this->aboutToolStripMenuItem});
		this->helpToolStripMenuItem->Name = L"helpToolStripMenuItem";
		this->helpToolStripMenuItem->Size = System::Drawing::Size(44, 20);
		this->helpToolStripMenuItem->Text = L"Help";
		// 
		// aboutToolStripMenuItem
		// 
		this->aboutToolStripMenuItem->Name = L"aboutToolStripMenuItem";
		this->aboutToolStripMenuItem->Size = System::Drawing::Size(115, 22);
		this->aboutToolStripMenuItem->Text = L"About";
		this->aboutToolStripMenuItem->Click += gcnew System::EventHandler(this, &Form1::aboutToolStripMenuItem_Click);
		// 
		// toolStrip1
		// 
		this->toolStrip1->Items->AddRange(gcnew cli::array< System::Windows::Forms::ToolStripItem^  >(7) {this->toolStripButton1, 
			this->toolStripSeparator1, this->toolStripButton2, this->toolStripSeparator2, this->toolStripButton3, this->toolStripSeparator3, 
			this->toolStripButton4});
		this->toolStrip1->Location = System::Drawing::Point(0, 24);
		this->toolStrip1->Name = L"toolStrip1";
		this->toolStrip1->Size = System::Drawing::Size(789, 25);
		this->toolStrip1->TabIndex = 0;
		this->toolStrip1->Text = L"toolStrip1";
		// 
		// toolStripButton1
		// 
		this->toolStripButton1->DisplayStyle = System::Windows::Forms::ToolStripItemDisplayStyle::Image;
		this->toolStripButton1->Image = (cli::safe_cast<System::Drawing::Image^  >(resources->GetObject(L"toolStripButton1.Image")));
		this->toolStripButton1->ImageTransparentColor = System::Drawing::Color::Magenta;
		this->toolStripButton1->Name = L"toolStripButton1";
		this->toolStripButton1->Size = System::Drawing::Size(23, 22);
		this->toolStripButton1->Text = L"toolStripButton1";
		this->toolStripButton1->ToolTipText = L"Save Mandelbrot";
		this->toolStripButton1->Click += gcnew System::EventHandler(this, &Form1::toolStripButton1_Click);
		// 
		// toolStripSeparator1
		// 
		this->toolStripSeparator1->Name = L"toolStripSeparator1";
		this->toolStripSeparator1->Size = System::Drawing::Size(6, 25);
		// 
		// toolStripButton2
		// 
		this->toolStripButton2->DisplayStyle = System::Windows::Forms::ToolStripItemDisplayStyle::Image;
		this->toolStripButton2->Image = (cli::safe_cast<System::Drawing::Image^  >(resources->GetObject(L"toolStripButton2.Image")));
		this->toolStripButton2->ImageTransparentColor = System::Drawing::Color::Magenta;
		this->toolStripButton2->Name = L"toolStripButton2";
		this->toolStripButton2->Size = System::Drawing::Size(23, 22);
		this->toolStripButton2->Text = L"toolStripButton2";
		this->toolStripButton2->ToolTipText = L"save Julia";
		this->toolStripButton2->Click += gcnew System::EventHandler(this, &Form1::toolStripButton2_Click);
		// 
		// toolStripSeparator2
		// 
		this->toolStripSeparator2->Name = L"toolStripSeparator2";
		this->toolStripSeparator2->Size = System::Drawing::Size(6, 25);
		// 
		// toolStripButton3
		// 
		this->toolStripButton3->DisplayStyle = System::Windows::Forms::ToolStripItemDisplayStyle::Image;
		this->toolStripButton3->Image = (cli::safe_cast<System::Drawing::Image^  >(resources->GetObject(L"toolStripButton3.Image")));
		this->toolStripButton3->ImageTransparentColor = System::Drawing::Color::Magenta;
		this->toolStripButton3->Name = L"toolStripButton3";
		this->toolStripButton3->Size = System::Drawing::Size(23, 22);
		this->toolStripButton3->Text = L"Copy Mandelbrot to clipboard";
		this->toolStripButton3->Click += gcnew System::EventHandler(this, &Form1::toolStripButton3_Click);
		// 
		// toolStripSeparator3
		// 
		this->toolStripSeparator3->Name = L"toolStripSeparator3";
		this->toolStripSeparator3->Size = System::Drawing::Size(6, 25);
		// 
		// toolStripButton4
		// 
		this->toolStripButton4->DisplayStyle = System::Windows::Forms::ToolStripItemDisplayStyle::Image;
		this->toolStripButton4->Image = (cli::safe_cast<System::Drawing::Image^  >(resources->GetObject(L"toolStripButton4.Image")));
		this->toolStripButton4->ImageTransparentColor = System::Drawing::Color::Magenta;
		this->toolStripButton4->Name = L"toolStripButton4";
		this->toolStripButton4->Size = System::Drawing::Size(23, 22);
		this->toolStripButton4->Text = L"copy julia to clipboard";
		this->toolStripButton4->Click += gcnew System::EventHandler(this, &Form1::toolStripButton4_Click);
		// 
		// statusStrip1
		// 
		this->statusStrip1->Items->AddRange(gcnew cli::array< System::Windows::Forms::ToolStripItem^  >(3) {this->toolStripStatusLabel1, 
			this->toolStripStatusLabel2, this->toolStripStatusLabel3});
		this->statusStrip1->Location = System::Drawing::Point(0, 506);
		this->statusStrip1->Name = L"statusStrip1";
		this->statusStrip1->Size = System::Drawing::Size(789, 24);
		this->statusStrip1->TabIndex = 1;
		this->statusStrip1->Text = L"statusStrip1";
		// 
		// toolStripStatusLabel1
		// 
		this->toolStripStatusLabel1->BorderSides = static_cast<System::Windows::Forms::ToolStripStatusLabelBorderSides>((((System::Windows::Forms::ToolStripStatusLabelBorderSides::Left | System::Windows::Forms::ToolStripStatusLabelBorderSides::Top) 
			| System::Windows::Forms::ToolStripStatusLabelBorderSides::Right) 
			| System::Windows::Forms::ToolStripStatusLabelBorderSides::Bottom));
		this->toolStripStatusLabel1->BorderStyle = System::Windows::Forms::Border3DStyle::SunkenInner;
		this->toolStripStatusLabel1->Name = L"toolStripStatusLabel1";
		this->toolStripStatusLabel1->Size = System::Drawing::Size(122, 19);
		this->toolStripStatusLabel1->Text = L"toolStripStatusLabel1";
		// 
		// toolStripStatusLabel2
		// 
		this->toolStripStatusLabel2->BorderSides = static_cast<System::Windows::Forms::ToolStripStatusLabelBorderSides>((((System::Windows::Forms::ToolStripStatusLabelBorderSides::Left | System::Windows::Forms::ToolStripStatusLabelBorderSides::Top) 
			| System::Windows::Forms::ToolStripStatusLabelBorderSides::Right) 
			| System::Windows::Forms::ToolStripStatusLabelBorderSides::Bottom));
		this->toolStripStatusLabel2->BorderStyle = System::Windows::Forms::Border3DStyle::SunkenInner;
		this->toolStripStatusLabel2->Name = L"toolStripStatusLabel2";
		this->toolStripStatusLabel2->Size = System::Drawing::Size(122, 19);
		this->toolStripStatusLabel2->Text = L"toolStripStatusLabel2";
		// 
		// toolStripStatusLabel3
		// 
		this->toolStripStatusLabel3->BorderSides = static_cast<System::Windows::Forms::ToolStripStatusLabelBorderSides>((((System::Windows::Forms::ToolStripStatusLabelBorderSides::Left | System::Windows::Forms::ToolStripStatusLabelBorderSides::Top) 
			| System::Windows::Forms::ToolStripStatusLabelBorderSides::Right) 
			| System::Windows::Forms::ToolStripStatusLabelBorderSides::Bottom));
		this->toolStripStatusLabel3->BorderStyle = System::Windows::Forms::Border3DStyle::SunkenInner;
		this->toolStripStatusLabel3->Name = L"toolStripStatusLabel3";
		this->toolStripStatusLabel3->Size = System::Drawing::Size(122, 19);
		this->toolStripStatusLabel3->Text = L"toolStripStatusLabel3";
		// 
		// btnCalculate
		// 
		this->btnCalculate->Location = System::Drawing::Point(11, 10);
		this->btnCalculate->Name = L"btnCalculate";
		this->btnCalculate->Size = System::Drawing::Size(61, 35);
		this->btnCalculate->TabIndex = 0;
		this->btnCalculate->Text = L"Calculate";
		this->btnCalculate->UseVisualStyleBackColor = true;
		this->btnCalculate->Click += gcnew System::EventHandler(this, &Form1::button3_Click);
		// 
		// btnExit
		// 
		this->btnExit->Location = System::Drawing::Point(259, 11);
		this->btnExit->Name = L"btnExit";
		this->btnExit->Size = System::Drawing::Size(61, 35);
		this->btnExit->TabIndex = 1;
		this->btnExit->Text = L"Exit";
		this->btnExit->UseVisualStyleBackColor = true;
		this->btnExit->Click += gcnew System::EventHandler(this, &Form1::button2_Click);
		// 
		// btnReset
		// 
		this->btnReset->Location = System::Drawing::Point(134, 9);
		this->btnReset->Name = L"btnReset";
		this->btnReset->Size = System::Drawing::Size(61, 35);
		this->btnReset->TabIndex = 0;
		this->btnReset->Text = L"Reset";
		this->btnReset->UseVisualStyleBackColor = true;
		this->btnReset->Click += gcnew System::EventHandler(this, &Form1::button1_Click);
		// 
		// label1
		// 
		this->label1->BackColor = System::Drawing::Color::White;
		this->label1->BorderStyle = System::Windows::Forms::BorderStyle::Fixed3D;
		this->label1->Font = (gcnew System::Drawing::Font(L"Arial", 6.75F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
			static_cast<System::Byte>(0)));
		this->label1->Location = System::Drawing::Point(480, 308);
		this->label1->Name = L"label1";
		this->label1->Size = System::Drawing::Size(128, 13);
		this->label1->TabIndex = 5;
		this->label1->Text = L" ";
		// 
		// label2
		// 
		this->label2->BackColor = System::Drawing::Color::White;
		this->label2->BorderStyle = System::Windows::Forms::BorderStyle::Fixed3D;
		this->label2->Font = (gcnew System::Drawing::Font(L"Arial", 6.75F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
			static_cast<System::Byte>(0)));
		this->label2->Location = System::Drawing::Point(480, 324);
		this->label2->Name = L"label2";
		this->label2->Size = System::Drawing::Size(128, 13);
		this->label2->TabIndex = 6;
		this->label2->Text = L" ";
		// 
		// label3
		// 
		this->label3->BackColor = System::Drawing::Color::White;
		this->label3->BorderStyle = System::Windows::Forms::BorderStyle::Fixed3D;
		this->label3->Font = (gcnew System::Drawing::Font(L"Arial", 6.75F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
			static_cast<System::Byte>(0)));
		this->label3->Location = System::Drawing::Point(480, 341);
		this->label3->Name = L"label3";
		this->label3->Size = System::Drawing::Size(128, 13);
		this->label3->TabIndex = 7;
		this->label3->Text = L" ";
		// 
		// label4
		// 
		this->label4->BackColor = System::Drawing::Color::White;
		this->label4->BorderStyle = System::Windows::Forms::BorderStyle::Fixed3D;
		this->label4->Font = (gcnew System::Drawing::Font(L"Arial", 6.75F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
			static_cast<System::Byte>(0)));
		this->label4->Location = System::Drawing::Point(480, 357);
		this->label4->Name = L"label4";
		this->label4->Size = System::Drawing::Size(128, 13);
		this->label4->TabIndex = 8;
		this->label4->Text = L" ";
		// 
		// label5
		// 
		this->label5->BackColor = System::Drawing::Color::White;
		this->label5->BorderStyle = System::Windows::Forms::BorderStyle::Fixed3D;
		this->label5->Font = (gcnew System::Drawing::Font(L"Arial", 6.75F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
			static_cast<System::Byte>(0)));
		this->label5->Location = System::Drawing::Point(453, 281);
		this->label5->Name = L"label5";
		this->label5->Size = System::Drawing::Size(129, 17);
		this->label5->TabIndex = 9;
		this->label5->Text = L" ";
		// 
		// label6
		// 
		this->label6->BackColor = System::Drawing::Color::White;
		this->label6->BorderStyle = System::Windows::Forms::BorderStyle::Fixed3D;
		this->label6->Font = (gcnew System::Drawing::Font(L"Arial", 6.75F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
			static_cast<System::Byte>(0)));
		this->label6->Location = System::Drawing::Point(453, 200);
		this->label6->Name = L"label6";
		this->label6->Size = System::Drawing::Size(129, 17);
		this->label6->TabIndex = 10;
		this->label6->Text = L" ";
		// 
		// label7
		// 
		this->label7->BackColor = System::Drawing::Color::White;
		this->label7->BorderStyle = System::Windows::Forms::BorderStyle::Fixed3D;
		this->label7->Font = (gcnew System::Drawing::Font(L"Arial", 6.75F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
			static_cast<System::Byte>(0)));
		this->label7->Location = System::Drawing::Point(453, 217);
		this->label7->Name = L"label7";
		this->label7->Size = System::Drawing::Size(129, 13);
		this->label7->TabIndex = 11;
		this->label7->Text = L" ";
		// 
		// label8
		// 
		this->label8->BackColor = System::Drawing::Color::White;
		this->label8->BorderStyle = System::Windows::Forms::BorderStyle::Fixed3D;
		this->label8->Font = (gcnew System::Drawing::Font(L"Arial", 6.75F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
			static_cast<System::Byte>(0)));
		this->label8->Location = System::Drawing::Point(453, 231);
		this->label8->Name = L"label8";
		this->label8->Size = System::Drawing::Size(129, 16);
		this->label8->TabIndex = 12;
		this->label8->Text = L" ";
		// 
		// label9
		// 
		this->label9->BackColor = System::Drawing::Color::White;
		this->label9->BorderStyle = System::Windows::Forms::BorderStyle::Fixed3D;
		this->label9->Font = (gcnew System::Drawing::Font(L"Arial", 6.75F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
			static_cast<System::Byte>(0)));
		this->label9->Location = System::Drawing::Point(453, 249);
		this->label9->Name = L"label9";
		this->label9->Size = System::Drawing::Size(129, 16);
		this->label9->TabIndex = 13;
		this->label9->Text = L" ";
		// 
		// label10
		// 
		this->label10->BackColor = System::Drawing::Color::White;
		this->label10->BorderStyle = System::Windows::Forms::BorderStyle::Fixed3D;
		this->label10->Font = (gcnew System::Drawing::Font(L"Arial", 6.75F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
			static_cast<System::Byte>(0)));
		this->label10->Location = System::Drawing::Point(453, 265);
		this->label10->Name = L"label10";
		this->label10->Size = System::Drawing::Size(129, 16);
		this->label10->TabIndex = 14;
		this->label10->Text = L" ";
		// 
		// timer1
		// 
		this->timer1->Tick += gcnew System::EventHandler(this, &Form1::timer1_Tick);
		// 
		// progressBar1
		// 
		this->progressBar1->Location = System::Drawing::Point(418, 373);
		this->progressBar1->Name = L"progressBar1";
		this->progressBar1->Size = System::Drawing::Size(190, 11);
		this->progressBar1->TabIndex = 3;
		// 
		// label11
		// 
		this->label11->BorderStyle = System::Windows::Forms::BorderStyle::Fixed3D;
		this->label11->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 6.75F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
			static_cast<System::Byte>(0)));
		this->label11->Location = System::Drawing::Point(170, 19);
		this->label11->Name = L"label11";
		this->label11->Size = System::Drawing::Size(162, 15);
		this->label11->TabIndex = 15;
		this->label11->Text = L"Julia Walk";
		this->label11->TextAlign = System::Drawing::ContentAlignment::MiddleCenter;
		// 
		// label12
		// 
		this->label12->BackColor = System::Drawing::Color::White;
		this->label12->BorderStyle = System::Windows::Forms::BorderStyle::Fixed3D;
		this->label12->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 6.75F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
			static_cast<System::Byte>(0)));
		this->label12->Location = System::Drawing::Point(212, 37);
		this->label12->Name = L"label12";
		this->label12->Size = System::Drawing::Size(120, 20);
		this->label12->TabIndex = 16;
		this->label12->Text = L" ";
		// 
		// label13
		// 
		this->label13->BackColor = System::Drawing::Color::White;
		this->label13->BorderStyle = System::Windows::Forms::BorderStyle::Fixed3D;
		this->label13->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 6.75F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
			static_cast<System::Byte>(0)));
		this->label13->Location = System::Drawing::Point(212, 57);
		this->label13->Name = L"label13";
		this->label13->Size = System::Drawing::Size(120, 18);
		this->label13->TabIndex = 17;
		this->label13->Text = L" ";
		// 
		// label14
		// 
		this->label14->BackColor = System::Drawing::Color::White;
		this->label14->BorderStyle = System::Windows::Forms::BorderStyle::Fixed3D;
		this->label14->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 6.75F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
			static_cast<System::Byte>(0)));
		this->label14->Location = System::Drawing::Point(212, 75);
		this->label14->Name = L"label14";
		this->label14->Size = System::Drawing::Size(120, 17);
		this->label14->TabIndex = 18;
		this->label14->Text = L" ";
		// 
		// pictureBox1
		// 
		this->pictureBox1->BackColor = System::Drawing::Color::Black;
		this->pictureBox1->Cursor = System::Windows::Forms::Cursors::Cross;
		this->pictureBox1->Image = (cli::safe_cast<System::Drawing::Image^  >(resources->GetObject(L"pictureBox1.Image")));
		this->pictureBox1->Location = System::Drawing::Point(10, 13);
		this->pictureBox1->Name = L"pictureBox1";
		this->pictureBox1->Size = System::Drawing::Size(402, 402);
		this->pictureBox1->TabIndex = 19;
		this->pictureBox1->TabStop = false;
		this->pictureBox1->MouseMove += gcnew System::Windows::Forms::MouseEventHandler(this, &Form1::pictureBox1_MouseMove);
		this->pictureBox1->MouseDown += gcnew System::Windows::Forms::MouseEventHandler(this, &Form1::pictureBox1_MouseDown);
		this->pictureBox1->Paint += gcnew System::Windows::Forms::PaintEventHandler(this, &Form1::pictureBox1_Paint);
		this->pictureBox1->MouseUp += gcnew System::Windows::Forms::MouseEventHandler(this, &Form1::pictureBox1_MouseUp);
		// 
		// contextMenuStrip1
		// 
		this->contextMenuStrip1->Items->AddRange(gcnew cli::array< System::Windows::Forms::ToolStripItem^  >(3) {this->toolStripMenuItem2, 
			this->resetToolStripMenuItem, this->exitToolStripMenuItem1});
		this->contextMenuStrip1->Name = L"contextMenuStrip1";
		this->contextMenuStrip1->Size = System::Drawing::Size(111, 70);
		this->contextMenuStrip1->Opening += gcnew System::ComponentModel::CancelEventHandler(this, &Form1::contextMenuStrip1_Opening);
		// 
		// toolStripMenuItem2
		// 
		this->toolStripMenuItem2->Name = L"toolStripMenuItem2";
		this->toolStripMenuItem2->Size = System::Drawing::Size(110, 22);
		this->toolStripMenuItem2->Text = L"Info";
		this->toolStripMenuItem2->Click += gcnew System::EventHandler(this, &Form1::toolStripMenuItem2_Click);
		// 
		// resetToolStripMenuItem
		// 
		this->resetToolStripMenuItem->Name = L"resetToolStripMenuItem";
		this->resetToolStripMenuItem->Size = System::Drawing::Size(110, 22);
		this->resetToolStripMenuItem->Text = L"Reset";
		// 
		// exitToolStripMenuItem1
		// 
		this->exitToolStripMenuItem1->Name = L"exitToolStripMenuItem1";
		this->exitToolStripMenuItem1->Size = System::Drawing::Size(110, 22);
		this->exitToolStripMenuItem1->Text = L"Exit";
		this->exitToolStripMenuItem1->Click += gcnew System::EventHandler(this, &Form1::exitToolStripMenuItem1_Click);
		// 
		// pictureBox2
		// 
		this->pictureBox2->BackColor = System::Drawing::Color::Black;
		this->pictureBox2->Image = (cli::safe_cast<System::Drawing::Image^  >(resources->GetObject(L"pictureBox2.Image")));
		this->pictureBox2->Location = System::Drawing::Point(6, 17);
		this->pictureBox2->Name = L"pictureBox2";
		this->pictureBox2->Size = System::Drawing::Size(158, 153);
		this->pictureBox2->TabIndex = 20;
		this->pictureBox2->TabStop = false;
		// 
		// groupBox1
		// 
		this->groupBox1->Controls->Add(this->btnExit);
		this->groupBox1->Controls->Add(this->btnCalculate);
		this->groupBox1->Controls->Add(this->btnInfo);
		this->groupBox1->Controls->Add(this->btnAbort);
		this->groupBox1->Controls->Add(this->btnReset);
		this->groupBox1->Location = System::Drawing::Point(418, 388);
		this->groupBox1->Name = L"groupBox1";
		this->groupBox1->Size = System::Drawing::Size(336, 50);
		this->groupBox1->TabIndex = 21;
		this->groupBox1->TabStop = false;
		// 
		// btnInfo
		// 
		this->btnInfo->Location = System::Drawing::Point(197, 10);
		this->btnInfo->Name = L"btnInfo";
		this->btnInfo->Size = System::Drawing::Size(61, 35);
		this->btnInfo->TabIndex = 2;
		this->btnInfo->Text = L"Info";
		this->btnInfo->UseVisualStyleBackColor = true;
		this->btnInfo->Click += gcnew System::EventHandler(this, &Form1::button4_Click);
		// 
		// btnAbort
		// 
		this->btnAbort->Location = System::Drawing::Point(73, 9);
		this->btnAbort->Name = L"btnAbort";
		this->btnAbort->Size = System::Drawing::Size(61, 35);
		this->btnAbort->TabIndex = 3;
		this->btnAbort->Text = L"Abort";
		this->btnAbort->UseVisualStyleBackColor = true;
		this->btnAbort->Click += gcnew System::EventHandler(this, &Form1::btnAbort_Click);
		// 
		// groupBox2
		// 
		this->groupBox2->Controls->Add(this->label40);
		this->groupBox2->Controls->Add(this->label41);
		this->groupBox2->Controls->Add(this->label42);
		this->groupBox2->Controls->Add(this->label43);
		this->groupBox2->Controls->Add(this->label44);
		this->groupBox2->Controls->Add(this->label45);
		this->groupBox2->Controls->Add(this->label34);
		this->groupBox2->Controls->Add(this->label35);
		this->groupBox2->Controls->Add(this->label36);
		this->groupBox2->Controls->Add(this->label37);
		this->groupBox2->Controls->Add(this->label38);
		this->groupBox2->Controls->Add(this->label39);
		this->groupBox2->Controls->Add(this->checkBox1);
		this->groupBox2->Controls->Add(this->numericUpDown6);
		this->groupBox2->Controls->Add(this->label33);
		this->groupBox2->Controls->Add(this->numericUpDown5);
		this->groupBox2->Controls->Add(this->label32);
		this->groupBox2->Controls->Add(this->numericUpDown4);
		this->groupBox2->Controls->Add(this->groupBox3);
		this->groupBox2->Controls->Add(this->numericUpDown3);
		this->groupBox2->Controls->Add(this->numericUpDown2);
		this->groupBox2->Controls->Add(this->numericUpDown1);
		this->groupBox2->Controls->Add(this->progressBar1);
		this->groupBox2->Controls->Add(this->groupBox1);
		this->groupBox2->Controls->Add(this->pictureBox1);
		this->groupBox2->Controls->Add(this->label25);
		this->groupBox2->Controls->Add(this->label29);
		this->groupBox2->Controls->Add(this->label30);
		this->groupBox2->Controls->Add(this->label31);
		this->groupBox2->Controls->Add(this->label21);
		this->groupBox2->Controls->Add(this->label22);
		this->groupBox2->Controls->Add(this->label23);
		this->groupBox2->Controls->Add(this->label24);
		this->groupBox2->Controls->Add(this->label15);
		this->groupBox2->Controls->Add(this->label8);
		this->groupBox2->Controls->Add(this->label16);
		this->groupBox2->Controls->Add(this->label1);
		this->groupBox2->Controls->Add(this->label17);
		this->groupBox2->Controls->Add(this->label2);
		this->groupBox2->Controls->Add(this->label18);
		this->groupBox2->Controls->Add(this->label5);
		this->groupBox2->Controls->Add(this->label19);
		this->groupBox2->Controls->Add(this->label20);
		this->groupBox2->Controls->Add(this->label6);
		this->groupBox2->Controls->Add(this->label7);
		this->groupBox2->Controls->Add(this->label3);
		this->groupBox2->Controls->Add(this->label4);
		this->groupBox2->Controls->Add(this->label9);
		this->groupBox2->Controls->Add(this->label10);
		this->groupBox2->Location = System::Drawing::Point(12, 52);
		this->groupBox2->Name = L"groupBox2";
		this->groupBox2->Size = System::Drawing::Size(771, 450);
		this->groupBox2->TabIndex = 22;
		this->groupBox2->TabStop = false;
		this->groupBox2->Text = L"Mandelbrot Set";
		// 
		// label40
		// 
		this->label40->BorderStyle = System::Windows::Forms::BorderStyle::Fixed3D;
		this->label40->Font = (gcnew System::Drawing::Font(L"Arial", 6.75F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
			static_cast<System::Byte>(0)));
		this->label40->Location = System::Drawing::Point(591, 231);
		this->label40->Name = L"label40";
		this->label40->Size = System::Drawing::Size(39, 16);
		this->label40->TabIndex = 56;
		this->label40->Text = L"zex";
		// 
		// label41
		// 
		this->label41->BorderStyle = System::Windows::Forms::BorderStyle::Fixed3D;
		this->label41->Font = (gcnew System::Drawing::Font(L"Arial", 6.75F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
			static_cast<System::Byte>(0)));
		this->label41->Location = System::Drawing::Point(591, 281);
		this->label41->Name = L"label41";
		this->label41->Size = System::Drawing::Size(39, 17);
		this->label41->TabIndex = 53;
		this->label41->Text = L" ";
		// 
		// label42
		// 
		this->label42->BorderStyle = System::Windows::Forms::BorderStyle::Fixed3D;
		this->label42->Font = (gcnew System::Drawing::Font(L"Arial", 6.75F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
			static_cast<System::Byte>(0)));
		this->label42->Location = System::Drawing::Point(591, 200);
		this->label42->Name = L"label42";
		this->label42->Size = System::Drawing::Size(39, 17);
		this->label42->TabIndex = 54;
		this->label42->Text = L"xmax";
		// 
		// label43
		// 
		this->label43->BorderStyle = System::Windows::Forms::BorderStyle::Fixed3D;
		this->label43->Font = (gcnew System::Drawing::Font(L"Arial", 6.75F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
			static_cast<System::Byte>(0)));
		this->label43->Location = System::Drawing::Point(591, 217);
		this->label43->Name = L"label43";
		this->label43->Size = System::Drawing::Size(39, 13);
		this->label43->TabIndex = 55;
		this->label43->Text = L"ymax";
		// 
		// label44
		// 
		this->label44->BorderStyle = System::Windows::Forms::BorderStyle::Fixed3D;
		this->label44->Font = (gcnew System::Drawing::Font(L"Arial", 6.75F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
			static_cast<System::Byte>(0)));
		this->label44->Location = System::Drawing::Point(591, 249);
		this->label44->Name = L"label44";
		this->label44->Size = System::Drawing::Size(39, 16);
		this->label44->TabIndex = 57;
		this->label44->Text = L"zey";
		// 
		// label45
		// 
		this->label45->BorderStyle = System::Windows::Forms::BorderStyle::Fixed3D;
		this->label45->Font = (gcnew System::Drawing::Font(L"Arial", 6.75F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
			static_cast<System::Byte>(0)));
		this->label45->Location = System::Drawing::Point(591, 265);
		this->label45->Name = L"label45";
		this->label45->Size = System::Drawing::Size(39, 16);
		this->label45->TabIndex = 58;
		this->label45->Text = L"dy";
		// 
		// label34
		// 
		this->label34->BackColor = System::Drawing::Color::White;
		this->label34->BorderStyle = System::Windows::Forms::BorderStyle::Fixed3D;
		this->label34->Font = (gcnew System::Drawing::Font(L"Arial", 6.75F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
			static_cast<System::Byte>(0)));
		this->label34->Location = System::Drawing::Point(636, 231);
		this->label34->Name = L"label34";
		this->label34->Size = System::Drawing::Size(118, 16);
		this->label34->TabIndex = 50;
		this->label34->Text = L" ";
		// 
		// label35
		// 
		this->label35->BackColor = System::Drawing::Color::White;
		this->label35->BorderStyle = System::Windows::Forms::BorderStyle::Fixed3D;
		this->label35->Font = (gcnew System::Drawing::Font(L"Arial", 6.75F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
			static_cast<System::Byte>(0)));
		this->label35->Location = System::Drawing::Point(636, 281);
		this->label35->Name = L"label35";
		this->label35->Size = System::Drawing::Size(118, 17);
		this->label35->TabIndex = 47;
		this->label35->Text = L" ";
		// 
		// label36
		// 
		this->label36->BackColor = System::Drawing::Color::White;
		this->label36->BorderStyle = System::Windows::Forms::BorderStyle::Fixed3D;
		this->label36->Font = (gcnew System::Drawing::Font(L"Arial", 6.75F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
			static_cast<System::Byte>(0)));
		this->label36->Location = System::Drawing::Point(636, 200);
		this->label36->Name = L"label36";
		this->label36->Size = System::Drawing::Size(118, 17);
		this->label36->TabIndex = 48;
		this->label36->Text = L" ";
		// 
		// label37
		// 
		this->label37->BackColor = System::Drawing::Color::White;
		this->label37->BorderStyle = System::Windows::Forms::BorderStyle::Fixed3D;
		this->label37->Font = (gcnew System::Drawing::Font(L"Arial", 6.75F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
			static_cast<System::Byte>(0)));
		this->label37->Location = System::Drawing::Point(636, 217);
		this->label37->Name = L"label37";
		this->label37->Size = System::Drawing::Size(118, 13);
		this->label37->TabIndex = 49;
		this->label37->Text = L" ";
		// 
		// label38
		// 
		this->label38->BackColor = System::Drawing::Color::White;
		this->label38->BorderStyle = System::Windows::Forms::BorderStyle::Fixed3D;
		this->label38->Font = (gcnew System::Drawing::Font(L"Arial", 6.75F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
			static_cast<System::Byte>(0)));
		this->label38->Location = System::Drawing::Point(636, 249);
		this->label38->Name = L"label38";
		this->label38->Size = System::Drawing::Size(118, 16);
		this->label38->TabIndex = 51;
		this->label38->Text = L" ";
		// 
		// label39
		// 
		this->label39->BackColor = System::Drawing::Color::White;
		this->label39->BorderStyle = System::Windows::Forms::BorderStyle::Fixed3D;
		this->label39->Font = (gcnew System::Drawing::Font(L"Arial", 6.75F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
			static_cast<System::Byte>(0)));
		this->label39->Location = System::Drawing::Point(636, 265);
		this->label39->Name = L"label39";
		this->label39->Size = System::Drawing::Size(118, 16);
		this->label39->TabIndex = 52;
		this->label39->Text = L" ";
		// 
		// checkBox1
		// 
		this->checkBox1->Checked = true;
		this->checkBox1->CheckState = System::Windows::Forms::CheckState::Checked;
		this->checkBox1->Enabled = false;
		this->checkBox1->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 6.75F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
			static_cast<System::Byte>(0)));
		this->checkBox1->Location = System::Drawing::Point(247, 421);
		this->checkBox1->Name = L"checkBox1";
		this->checkBox1->Size = System::Drawing::Size(81, 20);
		this->checkBox1->TabIndex = 46;
		this->checkBox1->Text = L"Symmetric";
		this->checkBox1->UseVisualStyleBackColor = true;
		this->checkBox1->CheckedChanged += gcnew System::EventHandler(this, &Form1::checkBox1_CheckedChanged);
		// 
		// numericUpDown6
		// 
		this->numericUpDown6->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
			static_cast<System::Byte>(0)));
		this->numericUpDown6->Location = System::Drawing::Point(180, 421);
		this->numericUpDown6->Maximum = System::Decimal(gcnew cli::array< System::Int32 >(4) {400, 0, 0, 0});
		this->numericUpDown6->Minimum = System::Decimal(gcnew cli::array< System::Int32 >(4) {10, 0, 0, 0});
		this->numericUpDown6->Name = L"numericUpDown6";
		this->numericUpDown6->Size = System::Drawing::Size(50, 20);
		this->numericUpDown6->TabIndex = 45;
		this->numericUpDown6->Value = System::Decimal(gcnew cli::array< System::Int32 >(4) {400, 0, 0, 0});
		this->numericUpDown6->ValueChanged += gcnew System::EventHandler(this, &Form1::numericUpDown6_ValueChanged);
		// 
		// label33
		// 
		this->label33->BorderStyle = System::Windows::Forms::BorderStyle::Fixed3D;
		this->label33->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
			static_cast<System::Byte>(0)));
		this->label33->Location = System::Drawing::Point(126, 421);
		this->label33->Name = L"label33";
		this->label33->Size = System::Drawing::Size(48, 20);
		this->label33->TabIndex = 44;
		this->label33->Text = L"height";
		// 
		// numericUpDown5
		// 
		this->numericUpDown5->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
			static_cast<System::Byte>(0)));
		this->numericUpDown5->Location = System::Drawing::Point(68, 421);
		this->numericUpDown5->Maximum = System::Decimal(gcnew cli::array< System::Int32 >(4) {400, 0, 0, 0});
		this->numericUpDown5->Minimum = System::Decimal(gcnew cli::array< System::Int32 >(4) {10, 0, 0, 0});
		this->numericUpDown5->Name = L"numericUpDown5";
		this->numericUpDown5->Size = System::Drawing::Size(50, 20);
		this->numericUpDown5->TabIndex = 43;
		this->numericUpDown5->Value = System::Decimal(gcnew cli::array< System::Int32 >(4) {400, 0, 0, 0});
		this->numericUpDown5->ValueChanged += gcnew System::EventHandler(this, &Form1::numericUpDown5_ValueChanged);
		// 
		// label32
		// 
		this->label32->BorderStyle = System::Windows::Forms::BorderStyle::Fixed3D;
		this->label32->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
			static_cast<System::Byte>(0)));
		this->label32->Location = System::Drawing::Point(14, 421);
		this->label32->Name = L"label32";
		this->label32->Size = System::Drawing::Size(48, 20);
		this->label32->TabIndex = 42;
		this->label32->Text = L"width";
		// 
		// numericUpDown4
		// 
		this->numericUpDown4->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
			static_cast<System::Byte>(0)));
		this->numericUpDown4->Increment = System::Decimal(gcnew cli::array< System::Int32 >(4) {500, 0, 0, 0});
		this->numericUpDown4->Location = System::Drawing::Point(682, 320);
		this->numericUpDown4->Maximum = System::Decimal(gcnew cli::array< System::Int32 >(4) {65536, 0, 0, 0});
		this->numericUpDown4->Name = L"numericUpDown4";
		this->numericUpDown4->Size = System::Drawing::Size(72, 20);
		this->numericUpDown4->TabIndex = 41;
		this->numericUpDown4->Value = System::Decimal(gcnew cli::array< System::Int32 >(4) {64000, 0, 0, 0});
		this->numericUpDown4->ValueChanged += gcnew System::EventHandler(this, &Form1::numericUpDown4_ValueChanged);
		// 
		// groupBox3
		// 
		this->groupBox3->Controls->Add(this->label26);
		this->groupBox3->Controls->Add(this->label27);
		this->groupBox3->Controls->Add(this->pictureBox2);
		this->groupBox3->Controls->Add(this->label28);
		this->groupBox3->Controls->Add(this->label11);
		this->groupBox3->Controls->Add(this->label12);
		this->groupBox3->Controls->Add(this->label13);
		this->groupBox3->Controls->Add(this->label14);
		this->groupBox3->Location = System::Drawing::Point(418, 13);
		this->groupBox3->Name = L"groupBox3";
		this->groupBox3->Size = System::Drawing::Size(338, 180);
		this->groupBox3->TabIndex = 23;
		this->groupBox3->TabStop = false;
		this->groupBox3->Text = L"Julia Set ";
		// 
		// label26
		// 
		this->label26->BorderStyle = System::Windows::Forms::BorderStyle::Fixed3D;
		this->label26->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 6.75F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
			static_cast<System::Byte>(0)));
		this->label26->Location = System::Drawing::Point(170, 37);
		this->label26->Name = L"label26";
		this->label26->Size = System::Drawing::Size(39, 20);
		this->label26->TabIndex = 20;
		this->label26->Text = L"cx cy";
		// 
		// label27
		// 
		this->label27->BorderStyle = System::Windows::Forms::BorderStyle::Fixed3D;
		this->label27->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 6.75F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
			static_cast<System::Byte>(0)));
		this->label27->Location = System::Drawing::Point(170, 57);
		this->label27->Name = L"label27";
		this->label27->Size = System::Drawing::Size(39, 18);
		this->label27->TabIndex = 21;
		this->label27->Text = L"rx";
		// 
		// label28
		// 
		this->label28->BorderStyle = System::Windows::Forms::BorderStyle::Fixed3D;
		this->label28->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 6.75F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
			static_cast<System::Byte>(0)));
		this->label28->Location = System::Drawing::Point(170, 75);
		this->label28->Name = L"label28";
		this->label28->Size = System::Drawing::Size(39, 17);
		this->label28->TabIndex = 22;
		this->label28->Text = L"iy";
		// 
		// numericUpDown3
		// 
		this->numericUpDown3->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
			static_cast<System::Byte>(0)));
		this->numericUpDown3->Location = System::Drawing::Point(682, 299);
		this->numericUpDown3->Maximum = System::Decimal(gcnew cli::array< System::Int32 >(4) {16384, 0, 0, 0});
		this->numericUpDown3->Name = L"numericUpDown3";
		this->numericUpDown3->Size = System::Drawing::Size(72, 20);
		this->numericUpDown3->TabIndex = 40;
		this->numericUpDown3->Value = System::Decimal(gcnew cli::array< System::Int32 >(4) {40, 0, 0, 0});
		this->numericUpDown3->ValueChanged += gcnew System::EventHandler(this, &Form1::numericUpDown3_ValueChanged);
		// 
		// numericUpDown2
		// 
		this->numericUpDown2->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
			static_cast<System::Byte>(0)));
		this->numericUpDown2->Location = System::Drawing::Point(682, 341);
		this->numericUpDown2->Maximum = System::Decimal(gcnew cli::array< System::Int32 >(4) {16384, 0, 0, 0});
		this->numericUpDown2->Name = L"numericUpDown2";
		this->numericUpDown2->Size = System::Drawing::Size(72, 20);
		this->numericUpDown2->TabIndex = 39;
		this->numericUpDown2->Value = System::Decimal(gcnew cli::array< System::Int32 >(4) {100, 0, 0, 0});
		this->numericUpDown2->ValueChanged += gcnew System::EventHandler(this, &Form1::numericUpDown2_ValueChanged);
		// 
		// numericUpDown1
		// 
		this->numericUpDown1->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
			static_cast<System::Byte>(0)));
		this->numericUpDown1->Location = System::Drawing::Point(682, 363);
		this->numericUpDown1->Maximum = System::Decimal(gcnew cli::array< System::Int32 >(4) {262144, 0, 0, 0});
		this->numericUpDown1->Name = L"numericUpDown1";
		this->numericUpDown1->Size = System::Drawing::Size(72, 20);
		this->numericUpDown1->TabIndex = 38;
		this->numericUpDown1->Value = System::Decimal(gcnew cli::array< System::Int32 >(4) {256, 0, 0, 0});
		this->numericUpDown1->ValueChanged += gcnew System::EventHandler(this, &Form1::numericUpDown1_ValueChanged);
		// 
		// label25
		// 
		this->label25->BorderStyle = System::Windows::Forms::BorderStyle::Fixed3D;
		this->label25->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
			static_cast<System::Byte>(0)));
		this->label25->Location = System::Drawing::Point(628, 366);
		this->label25->Name = L"label25";
		this->label25->Size = System::Drawing::Size(48, 17);
		this->label25->TabIndex = 34;
		this->label25->Text = L"ncls";
		// 
		// label29
		// 
		this->label29->BorderStyle = System::Windows::Forms::BorderStyle::Fixed3D;
		this->label29->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
			static_cast<System::Byte>(0)));
		this->label29->Location = System::Drawing::Point(628, 341);
		this->label29->Name = L"label29";
		this->label29->Size = System::Drawing::Size(48, 20);
		this->label29->TabIndex = 35;
		this->label29->Text = L"mctf";
		// 
		// label30
		// 
		this->label30->BorderStyle = System::Windows::Forms::BorderStyle::Fixed3D;
		this->label30->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
			static_cast<System::Byte>(0)));
		this->label30->Location = System::Drawing::Point(628, 300);
		this->label30->Name = L"label30";
		this->label30->Size = System::Drawing::Size(48, 20);
		this->label30->TabIndex = 36;
		this->label30->Text = L"recur";
		// 
		// label31
		// 
		this->label31->BorderStyle = System::Windows::Forms::BorderStyle::Fixed3D;
		this->label31->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
			static_cast<System::Byte>(0)));
		this->label31->Location = System::Drawing::Point(628, 320);
		this->label31->Name = L"label31";
		this->label31->Size = System::Drawing::Size(48, 20);
		this->label31->TabIndex = 37;
		this->label31->Text = L"mndscl";
		// 
		// label21
		// 
		this->label21->BorderStyle = System::Windows::Forms::BorderStyle::Fixed3D;
		this->label21->Font = (gcnew System::Drawing::Font(L"Arial", 6.75F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
			static_cast<System::Byte>(0)));
		this->label21->Location = System::Drawing::Point(418, 307);
		this->label21->Name = L"label21";
		this->label21->Size = System::Drawing::Size(48, 13);
		this->label21->TabIndex = 30;
		this->label21->Text = L"zop";
		// 
		// label22
		// 
		this->label22->BorderStyle = System::Windows::Forms::BorderStyle::Fixed3D;
		this->label22->Font = (gcnew System::Drawing::Font(L"Arial", 6.75F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
			static_cast<System::Byte>(0)));
		this->label22->Location = System::Drawing::Point(418, 324);
		this->label22->Name = L"label22";
		this->label22->Size = System::Drawing::Size(48, 13);
		this->label22->TabIndex = 31;
		this->label22->Text = L" mx my";
		// 
		// label23
		// 
		this->label23->BorderStyle = System::Windows::Forms::BorderStyle::Fixed3D;
		this->label23->Font = (gcnew System::Drawing::Font(L"Arial", 6.75F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
			static_cast<System::Byte>(0)));
		this->label23->Location = System::Drawing::Point(418, 341);
		this->label23->Name = L"label23";
		this->label23->Size = System::Drawing::Size(48, 13);
		this->label23->TabIndex = 32;
		this->label23->Text = L" sx sy";
		// 
		// label24
		// 
		this->label24->BorderStyle = System::Windows::Forms::BorderStyle::Fixed3D;
		this->label24->Font = (gcnew System::Drawing::Font(L"Arial", 6.75F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
			static_cast<System::Byte>(0)));
		this->label24->Location = System::Drawing::Point(418, 357);
		this->label24->Name = L"label24";
		this->label24->Size = System::Drawing::Size(48, 13);
		this->label24->TabIndex = 33;
		this->label24->Text = L" ex ey";
		// 
		// label15
		// 
		this->label15->BorderStyle = System::Windows::Forms::BorderStyle::Fixed3D;
		this->label15->Font = (gcnew System::Drawing::Font(L"Arial", 6.75F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
			static_cast<System::Byte>(0)));
		this->label15->Location = System::Drawing::Point(418, 231);
		this->label15->Name = L"label15";
		this->label15->Size = System::Drawing::Size(29, 16);
		this->label15->TabIndex = 27;
		this->label15->Text = L"zsx";
		// 
		// label16
		// 
		this->label16->BorderStyle = System::Windows::Forms::BorderStyle::Fixed3D;
		this->label16->Font = (gcnew System::Drawing::Font(L"Arial", 6.75F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
			static_cast<System::Byte>(0)));
		this->label16->Location = System::Drawing::Point(418, 281);
		this->label16->Name = L"label16";
		this->label16->Size = System::Drawing::Size(29, 17);
		this->label16->TabIndex = 24;
		// 
		// label17
		// 
		this->label17->BorderStyle = System::Windows::Forms::BorderStyle::Fixed3D;
		this->label17->Font = (gcnew System::Drawing::Font(L"Arial", 6.75F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
			static_cast<System::Byte>(0)));
		this->label17->Location = System::Drawing::Point(418, 200);
		this->label17->Name = L"label17";
		this->label17->Size = System::Drawing::Size(29, 17);
		this->label17->TabIndex = 25;
		this->label17->Text = L"xmin";
		// 
		// label18
		// 
		this->label18->BorderStyle = System::Windows::Forms::BorderStyle::Fixed3D;
		this->label18->Font = (gcnew System::Drawing::Font(L"Arial", 6.75F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
			static_cast<System::Byte>(0)));
		this->label18->Location = System::Drawing::Point(418, 217);
		this->label18->Name = L"label18";
		this->label18->Size = System::Drawing::Size(29, 13);
		this->label18->TabIndex = 26;
		this->label18->Text = L"ymin";
		// 
		// label19
		// 
		this->label19->BorderStyle = System::Windows::Forms::BorderStyle::Fixed3D;
		this->label19->Font = (gcnew System::Drawing::Font(L"Arial", 6.75F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
			static_cast<System::Byte>(0)));
		this->label19->Location = System::Drawing::Point(418, 249);
		this->label19->Name = L"label19";
		this->label19->Size = System::Drawing::Size(29, 16);
		this->label19->TabIndex = 28;
		this->label19->Text = L"zsy";
		// 
		// label20
		// 
		this->label20->BorderStyle = System::Windows::Forms::BorderStyle::Fixed3D;
		this->label20->Font = (gcnew System::Drawing::Font(L"Arial", 6.75F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
			static_cast<System::Byte>(0)));
		this->label20->Location = System::Drawing::Point(418, 265);
		this->label20->Name = L"label20";
		this->label20->Size = System::Drawing::Size(29, 16);
		this->label20->TabIndex = 29;
		this->label20->Text = L"dx";
		// 
		// saveFileDialog1
		// 
		this->saveFileDialog1->DefaultExt = L"*.png";
		this->saveFileDialog1->InitialDirectory = L"c:\\";
		// 
		// pictureBox3
		// 
		this->pictureBox3->Image = (cli::safe_cast<System::Drawing::Image^  >(resources->GetObject(L"pictureBox3.Image")));
		this->pictureBox3->Location = System::Drawing::Point(208, 566);
		this->pictureBox3->Name = L"pictureBox3";
		this->pictureBox3->Size = System::Drawing::Size(160, 139);
		this->pictureBox3->TabIndex = 23;
		this->pictureBox3->TabStop = false;
		this->pictureBox3->Visible = false;
		// 
		// pictureBox4
		// 
		this->pictureBox4->Image = (cli::safe_cast<System::Drawing::Image^  >(resources->GetObject(L"pictureBox4.Image")));
		this->pictureBox4->Location = System::Drawing::Point(41, 576);
		this->pictureBox4->Name = L"pictureBox4";
		this->pictureBox4->Size = System::Drawing::Size(100, 50);
		this->pictureBox4->TabIndex = 42;
		this->pictureBox4->TabStop = false;
		this->pictureBox4->Visible = false;
		// 
		// Form1
		// 
		this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
		this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
		this->BackgroundImageLayout = System::Windows::Forms::ImageLayout::None;
		this->ClientSize = System::Drawing::Size(789, 530);
		this->Controls->Add(this->pictureBox4);
		this->Controls->Add(this->pictureBox3);
		this->Controls->Add(this->groupBox2);
		this->Controls->Add(this->statusStrip1);
		this->Controls->Add(this->toolStrip1);
		this->Controls->Add(this->menuStrip1);
		this->FormBorderStyle = System::Windows::Forms::FormBorderStyle::Fixed3D;
		this->MainMenuStrip = this->menuStrip1;
		this->MaximizeBox = false;
		this->MinimizeBox = false;
		this->Name = L"Form1";
		this->StartPosition = System::Windows::Forms::FormStartPosition::CenterScreen;
		this->Text = L"MandelBrot Imager/Julia Walker By TopCoder";
		this->Load += gcnew System::EventHandler(this, &Form1::Form1_Load);
		this->MouseUp += gcnew System::Windows::Forms::MouseEventHandler(this, &Form1::Form1_MouseUp);
		this->MouseDown += gcnew System::Windows::Forms::MouseEventHandler(this, &Form1::Form1_MouseDown);
		this->MouseMove += gcnew System::Windows::Forms::MouseEventHandler(this, &Form1::form1_MouseMove);
		this->KeyDown += gcnew System::Windows::Forms::KeyEventHandler(this, &Form1::Form1_KeyDown);
		this->menuStrip1->ResumeLayout(false);
		this->menuStrip1->PerformLayout();
		this->toolStrip1->ResumeLayout(false);
		this->toolStrip1->PerformLayout();
		this->statusStrip1->ResumeLayout(false);
		this->statusStrip1->PerformLayout();
		(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->pictureBox1))->EndInit();
		this->contextMenuStrip1->ResumeLayout(false);
		(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->pictureBox2))->EndInit();
		this->groupBox1->ResumeLayout(false);
		this->groupBox2->ResumeLayout(false);
		(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->numericUpDown6))->EndInit();
		(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->numericUpDown5))->EndInit();
		(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->numericUpDown4))->EndInit();
		this->groupBox3->ResumeLayout(false);
		(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->numericUpDown3))->EndInit();
		(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->numericUpDown2))->EndInit();
		(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->numericUpDown1))->EndInit();
		(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->pictureBox3))->EndInit();
		(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->pictureBox4))->EndInit();
		this->ResumeLayout(false);
		this->PerformLayout();

	}

#pragma endregion


		private: System::Void pictureBox1_MouseMove(System::Object^  sender, System::Windows::Forms::MouseEventArgs^  e) {
				mouse_x=e->X;  mouse_y=e->Y;
				if (mouse_x>=0 && mouse_x<=WIDTH && mouse_y>=0 && mouse_y<=HEIGHT){
					if (mouse_x>= sx && mouse_y >= sy ){
						ex = mouse_x; ey = mouse_y;	dx=zex-zsx;	dy=zey-zsy;
						if (e->Button==System::Windows::Forms::MouseButtons::Left){
						rect.Width=e->X- sx;  rect.Height=e->Y- sy;
						pictureBox1->Invalidate( rect );label1->Text=e->X+"x"+e->Y;
					 }
				   }

				if ( m_show ){}
				mousex=mouse_x;	mousey=mouse_y;	displayData(); 
				if (e->Button==System::Windows::Forms::MouseButtons::Left) 
				{
				   if (zoomcnt<1)pictureBox1->Image=pictureBox3->Image; 
				   else pictureBox1->Image=backBuffer;
				}
				}
		     }

             private: System::Void pictureBox1_MouseDown(System::Object^  sender, System::Windows::Forms::MouseEventArgs^  e) {
				switch ( e->Button ){
				case System::Windows::Forms::MouseButtons::Left:
				   if (mouse_x>=0 && mouse_x<=WIDTH && mouse_y>=0 && mouse_y<=HEIGHT){
						m_show = true;
						sx = mouse_x; sy = mouse_y;ex = mouse_x;ey = mouse_y;
						rect.X=sx; rect.Y=sy;xorEx= sx+100;	xorEy= sy+100;
						endx=0;	endy=0;	startx=mouse_x;	starty=mouse_y;
						zsx=(xmin+(xmax-xmin)*((mousex)-px)/(WIDTH-1));
						zsy=(ymin+(ymax-ymin)*((mousey)-py)/(HEIGHT-1));
						zex=(xmin+(xmax-xmin)*((mousex)-px)/(WIDTH-1));
						zey=(ymin+(ymax-ymin)*((mousey)-py)/(HEIGHT-1));
						tempx=xmin;tempy=ymin;xmin=zsx;	ymin=zsy;displayData();
					}
					break;
					case System::Windows::Forms::MouseButtons::Right:
					if (mouse_x<WIDTH && mouse_y<HEIGHT){
						initWalk(); MouseX=mouse_x; MouseY=mouse_y; putCursor();
					}
					break;
				}
		     }


			private: System::Void pictureBox1_MouseUp(System::Object^  sender, System::Windows::Forms::MouseEventArgs^  e) {
				switch ( e->Button ){
				case System::Windows::Forms::MouseButtons::Left:
				if ((mouse_x>=0) &&( mouse_x<=WIDTH) && (mouse_y>=0) && (mouse_y<=HEIGHT) && (ex-sx>2) && (ey-sy>2)){
					m_show = false;zoomcnt++;
					endx=mouse_x;endy=mouse_y;ex =mousex; ey =mousey;
					rect.Width=(ex-sx); rect.Height=(ey-sy);
					if (endx >startx+5 && endy >starty +5){
					 initWalk(); MouseX=WIDTH/2; MouseY=HEIGHT/2;dx=zex-zsx;dy=zey-zsy;
					 if (mouse_x>= sx && mouse_y >= sy ){
					 zex=(xmin+(xmax-xmin)*((mousex)-px)/(WIDTH-1));
					 zey=(ymin+(ymax-ymin)*((mousey)-py)/(HEIGHT-1));
					 xmax=zex; ymax=zey; dx=zex-zsx;dy=zey-zsy;
					 displayData(); calculateFractal(/*hdc*/); putCursor(); walkabout();
					}
				  } //else{pictureBox1->Invalidate( rect );}
				}

				break;
				case System::Windows::Forms::MouseButtons::Right:
				walkabout();
				break;
				}
			}

	    private: System::Void exitToolStripMenuItem_Click(System::Object^  sender, System::EventArgs^  e) {
				 this->Close();
			 }
        private: System::Void Form1_Load(System::Object^  sender, System::EventArgs^  e) {
		 }


         private: System::Void button2_Click(System::Object^  sender, System::EventArgs^  e) {
			 this->Close();
		 }
		 private: System::Void button3_Click(System::Object^  sender, System::EventArgs^  e) {         
					  initWalk();displayData();calculateFractal();putCursor();walkabout();
		 }

         private: System::Void form1_MouseMove(System::Object^  sender, System::Windows::Forms::MouseEventArgs^  e) {
    	 }
         private: System::Void Form1_KeyDown(System::Object^  sender, System::Windows::Forms::KeyEventArgs^  e) {
		 }
         private: System::Void Form1_MouseDown(System::Object^  sender, System::Windows::Forms::MouseEventArgs^  e){
		 }
         private: System::Void Form1_MouseUp(System::Object^  sender, System::Windows::Forms::MouseEventArgs^  e) {
		 }
		private: System::Void timer1_Tick(System::Object^  sender, System::EventArgs^  e){
        	 DateTime dt = DateTime::Now;
			 toolStripStatusLabel3->Text =dt+"";
		 }
		private: System::Void button1_Click(System::Object^  sender, System::EventArgs^  e) {
    		 resetFrac();//calculateFractal();putCursor(); walkabout();  displayData();
			 //pictureBox1->Image = System::Drawing::Image::FromFile("mandel.png"); pictureBox2->Image = System::Drawing::Image::FromFile("julia.png");//pictureBox1->Update();
			  pictureBox1->Image=pictureBox3->Image;
			   pictureBox2->Image=pictureBox4->Image;
		 }


			private: System::Void pictureBox1_Paint(System::Object^  sender, System::Windows::Forms::PaintEventArgs^  e) {
						double PenWidth = 2;
						if (m_show) e->Graphics->DrawRectangle( gcnew Pen( Color::White,PenWidth ), rect );
					 }
			private: System::Void contextMenuStrip1_Opening(System::Object^  sender, System::ComponentModel::CancelEventArgs^  e) {
					 }
			private: System::Void exitToolStripMenuItem1_Click(System::Object^  sender, System::EventArgs^  e) {
						 this->Close();
					 }
			private: System::Void aboutToolStripMenuItem_Click(System::Object^  sender, System::EventArgs^  e) {
                         showTips();
 					 }
			private: System::Void button4_Click(System::Object^  sender, System::EventArgs^  e) {
                       showTips();
					 }
			private: System::Void toolStripMenuItem2_Click(System::Object^  sender, System::EventArgs^  e) {
					 }

		   private: System::Void backgroundWorker1_DoWork(System::Object^  sender, System::ComponentModel::DoWorkEventArgs^  e) {
 					 }
			private: System::Void backgroundWorker1_RunWorkerCompleted(System::Object^  sender, System::ComponentModel::RunWorkerCompletedEventArgs^  e) {


					 }
			private: System::Void backgroundWorker1_ProgressChanged(System::Object^  sender, System::ComponentModel::ProgressChangedEventArgs^  e) {

			 }

			private: System::Void toolStripMenuItem1_Click(System::Object^  sender, System::EventArgs^  e) {
						 saveMandelImageToFile();
			}

			private: System::Void toolStripMenuItem3_Click(System::Object^  sender, System::EventArgs^  e) {
						saveJuliaImageToFile();
			}
			private: System::Void numericUpDown1_ValueChanged(System::Object^  sender, System::EventArgs^  e) {
				ncls=System::Convert::ToInt32(numericUpDown1->Value);
			}
			private: System::Void numericUpDown2_ValueChanged(System::Object^  sender, System::EventArgs^  e) {
				mctf = System::Convert::ToInt32(numericUpDown2->Value);
			}
			private: System::Void numericUpDown3_ValueChanged(System::Object^  sender, System::EventArgs^  e) {
				Recur   = System::Convert::ToInt32(numericUpDown3->Value);
			}
			private: System::Void numericUpDown4_ValueChanged(System::Object^  sender, System::EventArgs^  e) {
				mndlDmsn   = System::Convert::ToInt32(numericUpDown4->Value);
			}
			private: System::Void copyMandelbrotToClipboardToolStripMenuItem_Click(System::Object^  sender, System::EventArgs^  e) {
				Clipboard::SetImage(mBmp);
			}
			private: System::Void copyJuliaToClipboardToolStripMenuItem_Click(System::Object^  sender, System::EventArgs^  e) {
				Clipboard::SetImage(jBmp);
			}
			private: System::Void toolStripButton1_Click(System::Object^  sender, System::EventArgs^  e) {
			saveMandelImageToFile();
			}

			private: System::Void toolStripButton2_Click(System::Object^  sender, System::EventArgs^  e) {
			saveJuliaImageToFile();
			}

			private: System::Void toolStripButton3_Click(System::Object^  sender, System::EventArgs^  e) {
			Clipboard::SetImage(mBmp);
			}
			private: System::Void toolStripButton4_Click(System::Object^  sender, System::EventArgs^  e) {
			Clipboard::SetImage(jBmp);
			}
            private: System::Void btnAbort_Click(System::Object^  sender, System::EventArgs^  e) {
             
		    }
			private: System::Void numericUpDown5_ValueChanged(System::Object^  sender, System::EventArgs^  e) {
						 WIDTH   = System::Convert::ToInt32(numericUpDown5->Value);
					 }
			private: System::Void numericUpDown6_ValueChanged(System::Object^  sender, System::EventArgs^  e) {
						 HEIGHT = System::Convert::ToInt32(numericUpDown6->Value);
					 }
            private: System::Void checkBox1_CheckedChanged(System::Object^  sender, System::EventArgs^  e) {

			} 
    };//class

}//namespace

