// mandel.cpp : main project file.

// *********************************************************************
// *     This software is made available only to individuals and only  *
// *     for educational purposes. Any and all commercial use is       *
// *     stricly prohibited.                                           *
// *********************************************************************
//**********************************************************************
//* Disclaimer: Any borrowed code used in this                         *
//*             program is the property of the                         *
//*             code originator. credit to them.                       *
//*                                                                    *
//*   Windows Forms/Managed C++:                                       *
//*   Unfinished                                                       *
//*   WARNING: NON-MULTI-THREADED VERSION                              *
//*                                                                    *
//*                                                                    *
//*                                                                    *  
//**********************************************************************

#include "stdafx.h"
#include "Form1.h"

using namespace mandel;

[STAThreadAttribute]
int main(array<System::String ^> ^args)
{


	// Enabling Windows XP visual effects before any controls are created
	Application::EnableVisualStyles();
	Application::SetCompatibleTextRenderingDefault(false); 

	// Create the main window and run it
	Application::Run(gcnew Form1());
	 
	return 0;
}
