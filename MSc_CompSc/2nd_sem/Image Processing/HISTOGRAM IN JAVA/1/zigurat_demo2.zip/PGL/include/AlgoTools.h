#ifndef ALGOTOOLS_H
	#define ALGOTOOLS_H

#include "PathHull.h"
#include "DPHull.h"

#endif
