function taust(asi1, col1)
{ asi1.bgColor = col1; }