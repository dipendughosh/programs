-- Jason Nemeth

-- Readme.txt
-- Structural Version Complete 5/8/05
-- RTL Version Complete 5/15/05


This model was created using the Symphony EDA Sonata version 2.3.10.
The model compiled on ran under Windows XP SP2.  Each model contained
in this package has a proper header file containing its completion
date as well as basic information about its operation and Inputs/
Outputs where not clear.  TextIO was used to create a results file
documenting the input into the system, as well as the resulting
output.  The results are stored in the model directory in "results.txt".

The report for this project was generated using Apple Pages under Mac
OS X 10.4 Tiger.  Tables were created using MS Excel 2004, and all graphics
were generated using OmniGraffle Standard, both for OS X.